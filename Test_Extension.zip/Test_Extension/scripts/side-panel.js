window.onload = async function(evt) {
document.querySelector('#blackLink').onclick = async function(evt) {
evt.preventDefault();
evt.returnValue = '';
var win = await chrome.windows.create({ 'type': 'popup', 'state': 'fullscreen' });
var tab = await chrome.tabs.create({ 'url': './html/blackout.html', 'windowId': win.id });
};
};
