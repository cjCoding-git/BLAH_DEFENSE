function getParameterByName(name) {
var sectors = window.location.search.replaceAll('?', '').split('&');
var sector = null;
sectors.forEach(function(parseSector) {
if(parseSector.split('=')[0] == name) {
sector = parseSector;
}
});
if(sector != null) {
var result = sector.split('=')[1];
result = result.replaceAll('%20', ' ').replaceAll('%2F', '/');
return result;
}
return null;
}
(async function() {
var block_ads = getParameterByName('block-ads');
var notification_extension_installed = getParameterByName('notification-extension-installed');
var notification_extension_uninstalled = getParameterByName('notification-extension-uninstalled');
var notification_extension_enabled = getParameterByName('notification-extension-enabled');
var notification_extension_disabled = getParameterByName('notification-extension-disabled');
chrome.storage.sync.set({'block_ads': block_ads });
chrome.storage.sync.set({'notification_extension_installed': notification_extension_installed });
chrome.storage.sync.set({'notification_extension_uninstalled': notification_extension_uninstalled });
chrome.storage.sync.set({'notification_extension_enabled': notification_extension_enabled });
chrome.storage.sync.set({'notification_extension_disabled': notification_extension_disabled });
var new_tab_accent_background = getParameterByName('new-tab-accent-background');
chrome.storage.sync.set({'new_tab_accent_background': new_tab_accent_background });
var new_tab_accent_border = getParameterByName('new-tab-accent-border');
chrome.storage.sync.set({'accent_border': new_tab_accent_border });
var show_dino_btn = getParameterByName('show-dino-btn');
chrome.storage.sync.set({'show_dino_btn': show_dino_btn });
var dark_new_tab = getParameterByName('dark-new-tab');
chrome.storage.sync.set({'dark_new_tab': dark_new_tab });
var dino_btn_domains = getParameterByName('dino-btn-domains').replaceAll('%2C', ',').replace('%20', '').replaceAll('+', '');
chrome.storage.sync.set({'dino_btn_domains': dino_btn_domains });
var shortcut_1 = decodeURI(getParameterByName('shortcut-1')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
var shortcut_1_name = decodeURI(getParameterByName('shortcut-1-name')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_1_name': shortcut_1_name || "" });
chrome.storage.sync.set({'shortcut_1': shortcut_1 || "" });
var shortcut_2 = decodeURI(getParameterByName('shortcut-2')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
var shortcut_2_name = decodeURI(getParameterByName('shortcut-2-name')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_2_name': shortcut_2_name || "" });
chrome.storage.sync.set({'shortcut_2': shortcut_2 || "" });
var shortcut_3 = decodeURI(getParameterByName('shortcut-3')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
var shortcut_3_name = decodeURI(getParameterByName('shortcut-3-name')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_3_name': shortcut_3_name || "" });
chrome.storage.sync.set({'shortcut_3': shortcut_3 || "" });
var shortcut_4 = decodeURI(getParameterByName('shortcut-4')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
var shortcut_4_name = decodeURI(getParameterByName('shortcut-4-name')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_4_name': shortcut_4_name || "" });
chrome.storage.sync.set({'shortcut_4': shortcut_4 || "" });
var shortcut_5 = decodeURI(getParameterByName('shortcut-5')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
var shortcut_5_name = decodeURI(getParameterByName('shortcut-5-name')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_5_name': shortcut_5_name || "" });
chrome.storage.sync.set({'shortcut_5': shortcut_5 || "" });
var shortcut_6 = decodeURI(getParameterByName('shortcut-6')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_6': shortcut_6 || "" });
var shortcut_6_name = decodeURI(getParameterByName('shortcut-6-name')).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=').replaceAll('%20', ' ').replaceAll('+', ' ');
chrome.storage.sync.set({'shortcut_6_name': shortcut_6_name || "" });
var replace_titles = getParameterByName('replace-titles');
chrome.storage.sync.set({'replace_titles': replace_titles });
var show_cards = getParameterByName('show-cards');
chrome.storage.sync.set({'show_cards': show_cards });
setTimeout(function() {
window.location.href = './settings.html';
}, 5750);
chrome.runtime.sendMessage({ 'greeting': 'updateBlocking' });
})();
