if(window.location.href == 'https://login.playcanvas.com/?came_from=https%3A%2F%2Fplaycanvas.com%2Feditor%2Fscene%2F1648062%2Flaunch') {
	window.location.href = window.location.href + "%3Fhi%3Dtrue";
}
if(window.location.href == 'https://login.playcanvas.com/?came_from=https%3A%2F%2Fplaycanvas.com%2Feditor%2Fscene%2F1648062%2Flaunch%3Fhi%3Dtrue') {
	var loaded = false;
	window.onload = function() {
		loaded = true;
		document.querySelector('input[name="username_or_email"]').setAttribute('value', 'admin@cjcoding.com');
		document.querySelector('input[name="password"]').setAttribute('value', 'cjcoding');
		document.querySelector('button[type="submit"]').innerText = "Click Here To Start Game...";
		try {
			document.querySelector('.g-recaptcha-response').onchange = function() {
				document.querySelector('button[type="submit"]').click();
			};
		} catch(err) {
			setTimeout(function() {
				document.querySelector('button[type="submit"]').click();
			}, 3500);
		}
	};
	setTimeout(function() {
		if(loaded == false) {
			loaded = true;
			document.querySelector('input[name="username_or_email"]').setAttribute('value', 'admin@cjcoding.com');
			document.querySelector('input[name="password"]').setAttribute('value', 'cjcoding');
			document.querySelector('button[type="submit"]').innerText = "Click Here To Start Game...";
			try {
				document.querySelector('.g-recaptcha-response').onchange = function() {
					document.querySelector('button[type="submit"]').click();
				};
			} catch(err) {}
		}
	}, 1000);
}
if(window.location.href == 'https://playcanvas.com/editor/scene/1648062/launch?hi=true') {
	window.location.href = 'https://launch.playcanvas.com/1648062';
}

window.addEventListener('load', function() {
	console.log(window.location.href.substring(0, 'https://files.cjcoding.com'.length));
	if(window.location.href.substring(0, 'https://files.cjcoding.com'.length) == 'https://files.cjcoding.com') {
		window.location.hash = '#cjcodingExtensionActive=true';
	}
}, false);