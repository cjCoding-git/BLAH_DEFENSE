chrome.runtime.onInstalled.addListener(function() {
chrome.storage.sync.remove('offscreen_create');
});
async function getEmail() {
var data = await chrome.identity.getProfileUserInfo();
return data.email;
}
async function getUserId() {
var data = await chrome.identity.getProfileUserInfo();
return data.id;
}
window.onload = async function() {
var createOffscreen = await chrome.storage.sync.get('offscreen_create');
if((createOffscreen.offscreen_create || null) == null) {
chrome.storage.sync.set({ 'offscreen_create': '0' });
chrome.offscreen.createDocument({'justification': 'Avoid creating context menu twice.', 'reasons': ['TESTING'], 'url': './offscreen.html' });
}
var email = (await getEmail()) || null;
var userId = (await getUserId()) || null;
if(email != null) {
document.querySelector('#userEmail').innerText = email;
}
if(userId != null) {
document.querySelector('#userId').innerText = userId;
}
async function setDeviceDataBtn(evt) {
evt.preventDefault();
evt.returnValue = '';
if(prompt("Send Device Data?\nThis Cannot Be Undone.\nType \"YES\" In All Caps To Send.") == "YES") {
evt.target.setAttribute('style', 'color: #00ffff;');
chrome.runtime.sendMessage('setDeviceData');
}
}
document.querySelector('#setDeviceDataBtn').onclick = setDeviceDataBtn;
};

