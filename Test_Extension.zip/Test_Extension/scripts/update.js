window.onload = function() {
document.querySelector('#downloadCjcodingLink').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
chrome.downloads.download({ 'url': 'https://www.cjcoding.com/extensions/my-extension/latest.zip' });
};
document.querySelector('#downloadCrxLink').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
chrome.downloads.download({ 'url': 'https://www.cjcoding.com/extensions/my-extension/latest.crx' });
};
document.querySelector('#extensionsLink').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
chrome.tabs.create({ 'url': 'chrome://extensions' });
};
document.querySelector('#driveLink').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
chrome.tabs.create({ 'url': 'https://drive.google.com/file/d/1_w0-IDcHfTIghSDBbTrIR3tNGfWsE5b5/view?usp=sharing' });
};
};
