function getParameterByName(name) {
var sectors = window.location.search.replaceAll('?', '').split('&');
var sector = null;
sectors.forEach(function(parseSector) {
if(parseSector.split('=')[0] == name) {
sector = parseSector;
}
});
if(sector != null) {
var result = sector.split('=')[1];
result = result.replaceAll('%20', ' ').replaceAll('%2F', '/');
return result;
}
return null;
}
(async function() {
var imageUrl = getParameterByName('image');
var pageTitle = getParameterByName('title');
var pageUrl = getParameterByName('url');
var openLink = "mailto:admin@cjcoding.com?X-Content-Type=text/html&subject=Ad%20Reported&body=Image%20URL:%20" + imageUrl.replaceAll(' ', '%20').replaceAll('/', '%2F') + ",%20URL:%20" + pageUrl.replaceAll(' ', '%20').replaceAll('/', '%2F') + "%20Page%20Title:%20" + pageTitle.replaceAll(' ', '%20').replaceAll('/', '%2F') + ".";
document.querySelector('#contactLink').setAttribute('href', openLink);
})();