(async function() {
window.onerror = function(err) {
console.debug(err);
};
var adblockedurl = chrome.runtime.getURL('/images/adblocked.png');
var block_ads_obj = await chrome.storage.sync.get('block_ads');
async function updateAds() {
var block_ads_value = block_ads_obj.block_ads;
if(block_ads_value == 'on') {
if(window.location.host.indexOf('cjcoding.com') == -1) {
var ads = [];
var iframeElmts = document.querySelectorAll('iframe');
if(iframeElmts != []) {
iframeElmts.forEach(function(frameElmt) {
if((frameElmt.id || "").indexOf('google_ads') != -1 || (frameElmt.getAttribute('href') || "").indexOf('ads.pubmatic') != -1) {
ads[ads.length] = frameElmt;
console.debug("Ad Frame: " + frameElmt.outerHTML + ".");
}
});
}
if(ads != []) {
parseAds(ads);
}
}
}
}
async function parseAds(adlist) {
if(adlist != []) {
adlist.forEach(async function(ad) {
var elmt = document.createElement('img');
elmt.setAttribute('src', adblockedurl);
ad.replaceWith(elmt);
});
}
}
window.addEventListener('load', function() {
updateAds();
}, false);
setInterval(updateAds, 100);
})();
