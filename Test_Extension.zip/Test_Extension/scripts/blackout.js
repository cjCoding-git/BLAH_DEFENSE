async function exitPopup(evt) {
window.close();
}
window.onload = async function() {
setTimeout(async function() {
document.keydown = exitPopup;
document.onmousemove = exitPopup;
document.onmousedown = exitPopup;
}, 5750);
};
