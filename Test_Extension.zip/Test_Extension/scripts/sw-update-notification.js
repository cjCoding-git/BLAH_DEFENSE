async function sendExtensionUpdateNotification(title, message, callback, storageFlag) {
chrome.notifications.getPermissionLevel(async function(level) {
if(level == "granted") {
chrome.notifications.getAll(async function(notificationData) {
var notificationCount = Object.entries(notificationData).length;
var id = "NOTIFICATION_ID_NOT_SET_SAFELY";
id = "NOTIFICATION_" + notificationCount.toString() + "_SAFE_KEY_" + (Math.floor(Math.random() * 9999).toString());
var allowNotifyObj = await chrome.storage.sync.get(storageFlag);
var allowNotifyValue = Object.entries(allowNotifyObj || { storageFlag: 'no' })[0][1];
if(allowNotifyValue == 'on') {
chrome.notifications.create(id, { "type": "basic", "iconUrl": "/images/icon-32.png", "title": "My Extension - " + title, "message": message, "buttons": [{ "title": "More Information..." }] });
chrome.notifications.onButtonClicked.addListener(async function(notificationId, buttonIndex) {
if(buttonIndex == 0 && notificationId == id) {
callback();
}
});
}
});
}
});
}
chrome.management.onInstalled.addListener(async function(info) {
var extensionName = info.name;
var extensionVersion = info.version;
sendExtensionUpdateNotification("Extension Installed", extensionName + " v. " + extensionVersion + " was installed.", async function() {
chrome.notifications.getPermissionLevel(async function(level) {
if(level == "granted") {
chrome.notifications.getAll(function(notificationData) {
var notificationCount = Object.entries(notificationData).length;
var id = "NOTIFICATION_ID_NOT_SET_SAFELY";
id = "NOTIFICATION_" + notificationCount.toString() + "_SAFE_KEY_" + (Math.floor(Math.random() * 9999).toString());
chrome.notifications.create(id, { "type": "basic", "iconUrl": "/images/icon-32.png", "title": "My Extension - " + "Extension Info", "message": "Name: " + extensionName + "\nVersion: " + extensionVersion + "\nDescription: " + info.description + "\nID: " + info.id + "\nInstall Type: " + info.installType + "\nType: " + info.type + "\nMay Disable: " + info.mayDisable.toString() + "\n",  });
});
}
});
}, 'notification_extension_installed');
});
chrome.management.onUninstalled.addListener(async function(info) {
var extensionName = info.name;
var extensionVersion = info.version;
sendExtensionUpdateNotification("Extension Unstalled", extensionName + " v. " + extensionVersion + " was uninstalled.", async function() {
chrome.notifications.getPermissionLevel(async function(level) {
if(level == "granted") {
chrome.notifications.getAll(function(notificationData) {
var notificationCount = Object.entries(notificationData).length;
var id = "NOTIFICATION_ID_NOT_SET_SAFELY";
id = "NOTIFICATION_" + notificationCount.toString() + "_SAFE_KEY_" + (Math.floor(Math.random() * 9999).toString());
chrome.notifications.create(id, { "type": "basic", "iconUrl": "/images/icon-32.png", "title": "My Extension - " + "Extension Info", "message": "Name: " + extensionName + "\nVersion: " + extensionVersion + "\nDescription: " + info.description + "\nID: " + info.id + "\nInstall Type: " + info.installType + "\nType: " + info.type + "\nMay Disable: " + info.mayDisable.toString() + "\n",  });
});
}
});
}, 'notification_extension_uninstalled');
});
chrome.management.onEnabled.addListener(async function(info) {
var extensionName = info.name;
var extensionVersion = info.version;
sendExtensionUpdateNotification("Extension Enabled", extensionName + " v. " + extensionVersion + " was enabled.", async function() {
chrome.notifications.getPermissionLevel(async function(level) {
if(level == "granted") {
chrome.notifications.getAll(function(notificationData) {
var notificationCount = Object.entries(notificationData).length;
var id = "NOTIFICATION_ID_NOT_SET_SAFELY";
id = "NOTIFICATION_" + notificationCount.toString() + "_SAFE_KEY_" + (Math.floor(Math.random() * 9999).toString());
chrome.notifications.create(id, { "type": "basic", "iconUrl": "/images/icon-32.png", "title": "My Extension - " + "Extension Info", "message": "Name: " + extensionName + "\nVersion: " + extensionVersion + "\nDescription: " + info.description + "\nID: " + info.id + "\nInstall Type: " + info.installType + "\nType: " + info.type + "\nMay Disable: " + info.mayDisable.toString() + "\n",  });
});
}
});
}, 'notification_extension_enabled');
});
chrome.management.onDisabled.addListener(async function(info) {
var extensionName = info.name;
var extensionVersion = info.version;
sendExtensionUpdateNotification("Extension Disabled", extensionName + " v. " + extensionVersion + " was disabled.", async function() {
chrome.notifications.getPermissionLevel(async function(level) {
if(level == "granted") {
chrome.notifications.getAll(function(notificationData) {
var notificationCount = Object.entries(notificationData).length;
var id = "NOTIFICATION_ID_NOT_SET_SAFELY";
id = "NOTIFICATION_" + notificationCount.toString() + "_SAFE_KEY_" + (Math.floor(Math.random() * 9999).toString());
chrome.notifications.create(id, { "type": "basic", "iconUrl": "/images/icon-32.png", "title": "My Extension - " + "Extension Info", "message": "Name: " + extensionName + "\nVersion: " + extensionVersion + "\nDescription: " + info.description + "\nID: " + info.id + "\nInstall Type: " + info.installType + "\nType: " + info.type + "\nMay Disable: " + info.mayDisable.toString() + "\n",  });
});
}
});
}, 'notification_extension_disabled');
});