function sliderIsOn(slider) {
return slider.children[0].checked;
}
