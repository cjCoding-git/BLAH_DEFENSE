window.onload = function() {
var pagename = window.location.search.replaceAll("?", '').split("&")[0].split("=")[1].replaceAll('%20', ' ');
var pageurl = window.location.search.replaceAll("?", '').split("&")[1].split("=")[1].replaceAll("%2F", '/');
document.querySelector('#pagename').innerHTML = pagename;
document.querySelector('#pageurl').innerHTML = pageurl;
document.querySelector('#responsego').onclick = function(evt) {
window.location.href = pageurl;
};
document.querySelector('#responseno').onclick = async function(evt) {
const tabs = await chrome.tabs.query({ 'active': true, 'title': "Redirecting... - My Extension" });
const tab = tabs[0];
const tabId = tab.id;
chrome.tabs.remove(tabId);
};
};
