window.onload = async function () {
if(window.location.hostname == 'drive.google.com') {
var blockedUsersObjs = [];
var users = [];
var usersNames = [];
document.querySelectorAll('.Si0NV').forEach(async function(obj) {
usersNames.push(obj.innerHTML);users.push(obj); });
var blockedUsers = ['Stillwater Area Public Schools'];
usersNames.forEach(async function(user) {
if(blockedUsers.indexOf(user) != -1) {
blockedUsersObjs.push(usersNames[users.indexOf(user)]);
}
});
blockedUsersObjs.forEach(async function(obj) {
obj.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.remove();
});
}
if(window.location.href.indexOf('myaccount.google.com/profile-picture') != -1) {
document.querySelector('.bwApif-Sx9Kwc').setAttribute('style', 'display: block;');
document.querySelector('.bwApif-wzTsW').setAttribute('style', 'opacity: 1;');
document.querySelector('button[aria-label="Close profile picture"').onclick = function() {
window.location.href = 'https://www.google.com';
};
window.onclick = function() {
setTimeout(function() {
document.querySelector('.bwApif-Sx9Kwc').setAttribute('style', 'display: block;');
document.querySelector('.bwApif-wzTsW').setAttribute('style', 'opacity: 1;');
document.querySelector('button[aria-label="Close profile picture"]').onclick = function() {
window.location.href = 'https://www.google.com';
};
}, 1000);
};
}
};
chrome.runtime.onMessage.addListener(async function(message, sender, sendResponse) {
if(message.greeting == 'revokeDriveAccess') {
window.onbeforeunload = function() {
chrome.tabs.sendMessage(message.data, 'revoked');
};
}
});