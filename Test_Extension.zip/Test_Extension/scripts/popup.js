import './utils.js';
document.querySelector('#focusCjcoding').addEventListener('click', async function(evt) {
evt.preventDefault();
evt.returnValue = '';
var cjcodingTabs = await chrome.tabs.query({
url: [
"https://cjcoding.com/*",
"https://*.cjcoding.com/*"
]
});
if(cjcodingTabs[0] != null) {
var tab = cjcodingTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
} else {
chrome.tabs.create({'url': 'https://cjcoding.com/?s=true'}, function(tab) {});
cjcodingTabs = await chrome.tabs.query({
url: [
"https://cjcoding.com/*",
"https://*.cjcoding.com/*"
]
});
var tab = cjcodingTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
}
}, false);
document.oncontextmenu = function(evt) {
evt.preventDefault();
evt.returnValue = '';
};
document.querySelector('#showCookies').onclick = showCookies;
async function showCookies(evt) {
var cookieTabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/cookiepage.html')
]
});
if(cookieTabs[0] != null) {
var tab = cookieTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
} else {
chrome.tabs.create({'url': chrome.runtime.getURL('/html/cookiepage.html')}, function(tab) {});
cookieTabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/cookiepage.html')
]
});
var tab = cookieTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
}
}
const updateTip = async () => {
const response = await fetch('https://extension-tips.glitch.me/tips.json');
const tips = await response.json();
const randomIndex = Math.floor(Math.random() * tips.length);
return chrome.storage.local.set({ tip: tips[randomIndex] });
};
async function updateTipBtn() {
updateTip();
const tabs = await chrome.tabs.query({'url': 'https://www.cjcoding.com/search_results.php?*'});
console.log(tabs);
tabs.forEach(function(tab) {
chrome.tabs.reload(tab.id);
chrome.tabs.update(tab.id, { active: true });
chrome.windows.update(tab.windowId, { focused: true });
});
setTimeout(function() {
chrome.tabs.query({'url': 'https://www.cjcoding.com/search_results.php?*'}, function(tabs) {
console.log(tabs);
tabs.forEach(function(tab) {
chrome.tabs.sendMessage(tab.id, {'greeting': 'opentip'});
});
});
}, 2500);
}
document.querySelector('#updateTipBtn').onclick = updateTipBtn;
document.querySelector('#settingsBtn').onclick = showSettings;
async function showSettings(evt) {
var settingsTabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/settings.html')
]
});
if(settingsTabs[0] != null) {
var tab = settingsTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
} else {
chrome.tabs.create({'url': chrome.runtime.getURL('/html/settings.html')}, function(tab) {});
settingsTabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/settings.html')
]
});
var tab = settingsTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
}
}
document.querySelector('#installPageBtn').onclick = showInstallPage;
async function showInstallPage(evt) {
var tabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/install.html')
]
});
if(tabs[0] != null) {
var tab = tabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
} else {
chrome.tabs.create({'url': chrome.runtime.getURL('/html/install.html')}, function(tab) {});
tabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/install.html')
]
});
var tab = tabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
}
}
async function loginButtonClick() {
chrome.runtime.sendMessage('login');
}
document.querySelector('#loginButton').onclick = loginButtonClick;
async function rantAboutEggsBtnClick() {
chrome.runtime.sendMessage("rantAboutEggs");
}
document.querySelector('#rantAboutEggsButton').onclick = rantAboutEggsBtnClick;
async function stopTalkingBtnClick() {
chrome.runtime.sendMessage('stopTalkingAll');
}
document.querySelector('#stopTalkingBtn').onclick = stopTalkingBtnClick;
async function getTopSites() {
document.querySelector('#topSitesBtn').remove();
document.querySelector('#topSites').setAttribute('style', 'display: block;');
document.querySelector('#topSitesHeader').setAttribute('style', 'display: block;');
var topSites = await chrome.topSites.get();
topSites.forEach(async function(topSite) {
var aelmt = document.createElement('a');
aelmt.innerText = topSite.title;
aelmt.setAttribute('target', '_blank');
aelmt.setAttribute('href', topSite.url);
var lielmt = document.createElement('li');
lielmt.appendChild(aelmt);
document.querySelector('#topSites').appendChild(lielmt);
});
}
document.querySelector('#topSitesBtn').onclick = getTopSites;
var commands = await chrome.commands.getAll();
let missingShortcuts = [];
for(let {name, shortcut} of commands) {
if(shortcut === '') {
missingShortcuts.push(name);
}
}
if(missingShortcuts.length > 0) {
document.querySelector('#missingCommands').setAttribute('style', 'display: block;color: red;cursor: pointer;font-size: 14pt;');
document.querySelector('#missingCommands').onclick = async function() {
chrome.tabs.create({ 'url': 'chrome://extensions/shortcuts' }, function(tab) {});
};
}
document.querySelector('#recordBtn').onclick = async function() {
var wins = await chrome.windows.getAll();
var win = null;
wins.forEach(async function(w) {
if(win == null) {
win = w;
}
});
var tabs = await chrome.tabs.query({ 'active': true, 'windowId': win.id });
var tab = tabs[0];
var streamId = await chrome.tabCapture.getMediaStreamId();
var fileName = prompt("Enter File Name: ") + ".webm";
chrome.scripting.executeScript({ 'target': { 'tabId': tab.id }, 'func': async function() { document.documentElement.setAttribute('charlieextensionrecording',  'true'); } });
window.open((chrome.runtime.getURL('/html/popup.html') + '?streamId=' + streamId + '&tabId=' + tab.id + '&fileName=' + fileName), '_blank', "popup=1,width=1050, height=700");
};
var wins = await chrome.windows.getAll();
var win = null;
wins.forEach(async function(w) {
if(win == null) {
win = w;
}
});
if(window.location.search || "".length > 0) {
var mediaRecorder = null;
var tab = { 'id': parseInt(window.location.search.split('&')[1].split('=')[1]), 'streamId': window.location.search.replaceAll('?', '').split('&')[0].split('=')[1], 'fileName': window.location.search.split('&')[2].split('=')[1] };
var fileName = tab.fileName;
var streamId = tab.streamId;
document.body.innerHTML = "<h1>Record</h1>\n<button id=\"stopRecordBtn\">Stop Recording...</button>\n<br />\n<p id=\"time\">0 Seconds</p>\n<br /><p>Please Click The Stop Recording Button On This Page When Done.\n<br />\nIf You Are Adding More To A Video, Please Do Not Start Recording What You Want To Be Seen Until The Preview Appears.</p>\n<br />\n<video id=\"showingVid\" muted autoplay loop width=\"1000\" height=\"350\"></video>";
async function recordData(stream, existingBlob, existingTime) {
var recordedData = [];
if(existingTime != null) {
setTimeout(function() {
document.querySelector('#showingVid').srcObject = stream;
}, 20000);
} else {
document.querySelector('#showingVid').srcObject = stream;
}
mediaRecorder = new MediaRecorder(stream, { 'mimeType': "video/webm" });
mediaRecorder.ondataavailable = function(event) {
recordedData.push(event.data);
};
mediaRecorder.start();
var time = 0;
if(existingTime != null) {
time = existingTime;
}
var intId = setInterval(function() {
time = time + 1;
document.querySelector('#time').innerHTML = time + " Seconds";
}, 1000);
async function createFileFormCurrentRecordedData() {
var tracks = stream.getTracks();
tracks.forEach(async function(track) {
track.stop()
});
document.querySelector('#showingVid').srcObject = null;
clearInterval(intId);
var blob = new Blob(recordedData, { 'type': "video/webm" });
if(existingBlob != null) {
blob = new Blob([existingBlob, blob], { 'type': "video/webm" });
}
var file = new File([blob], fileName, { 'type': "video/webm" });
var url = window.URL.createObjectURL(file);
var elmt = document.createElement('a');
elmt.setAttribute('download', fileName);
elmt.setAttribute('href', url);
document.body.innerHTML = "<h1>Preview And Download</h1>\n<video src=\"\" id=\"previewVid\" width=\"1000\" height=\"500\" loop></video>\n<button id=\"continueBtn\">Download & Exit...</button><button id=\"addBtn\">Add More...</button><button id=\"exitBtn\">Cancel...</button>";
document.querySelector('#previewVid').src = url;
document.querySelector('#previewVid').play();
document.querySelector('#continueBtn').onclick = async function() {
elmt.click();
document.body.innerHTML = "<h1>Download</h1>\n<p>Please Wait...</p>";
setTimeout(async function() {
var downloads = await chrome.downloads.search({});
var download = null;
downloads.forEach(function(down) {
if(download == null && down.filename.indexOf(fileName) != -1) {
download = down;
}
});
window.open("file:///" + download.filename, '_blank');
setTimeout(function() {
window.close();
}, 5750);
}, 7500);
};
document.querySelector('#exitBtn').onclick = async function() {
window.close();
};
document.querySelector('#addBtn').onclick = async function() {
document.body.innerHTML = "<h1>Record</h1>\n<button id=\"stopRecordBtn\">Stop Recording...</button>\n<br />\n<p id=\"time\">0 Seconds</p>\n<br /><p>Please Click The Stop Recording Button On This Page When Done.\n<br />\nIf You Are Adding More To A Video, Please Do Not Start Recording What You Want To Be Seen Until The Preview Appears.</p>\n<br />\n<video id=\"showingVid\" muted autoplay loop width=\"1000\" height=\"350\"></video>";
document.querySelector('#stopRecordBtn').onclick = async function() {
chrome.scripting.executeScript({ 'target': { 'tabId': tab.id }, 'func': async function() { document.documentElement.setAttribute('charlieextensionrecording', 'false'); } });
mediaRecorder.stop();
};
recordData(await navigator.mediaDevices.getDisplayMedia({ 'audio': true, 'video': true }), blob, time);
};
}
mediaRecorder.onstop = createFileFormCurrentRecordedData;
var isRecordingTab = await chrome.scripting.executeScript({ 'target': { 'tabId': tab.id }, 'func': function() { return document.documentElement.getAttribute('charlieextensionrecording') || 'false'; } });
if(isRecordingTab == 'false') {
mediaRecorder.stop();
}
}
recordData(await navigator.mediaDevices.getDisplayMedia({ 'audio': true, 'video': true }), null, null);
document.querySelector('#stopRecordBtn').onclick = async function() {
chrome.scripting.executeScript({ 'target': { 'tabId': tab.id }, 'func': async function() { document.documentElement.setAttribute('charlieextensionrecording', 'false'); } });
mediaRecorder.stop();
};
}