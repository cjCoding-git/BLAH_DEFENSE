import './utils.js';
import './sw-omnibox.js';
import './sw-tips.js';
import './runner.js';
import './blocker.js';
import './context-menu.js';
import './sw-update-notification.js';
var settingsTabs;
chrome.commands.onCommand.addListener(async function(ccommand) {
if(ccommand == 'settings-page') {
settingsTabs = await chrome.tabs.query({ 'url': [ chrome.runtime.getURL('/html/settings.html') ] });
if(settingsTabs[0] != null) {
var tab = settingsTabs[0];
chrome.tabs.update(tab.id, { active: true });
chrome.windows.update(tab.windowId, { focused: true });
} else {
chrome.tabs.create({'url': chrome.runtime.getURL('/html/settings.html')}, function(tab) {});
settingsTabs = await chrome.tabs.query({ 'url': [ chrome.runtime.getURL('/html/settings.html') ] });
var tab = settingsTabs[0];
chrome.tabs.update(tab.id, { active: true });
chrome.windows.update(tab.windowId, { focused: true });
}
}
});
async function getMissingShortcuts(sender) {
var commands = await chrome.commands.getAll();
let missingShortcuts = [];
for(let {name, shortcut} of commands) {
if(shortcut === '') {
missingShortcuts.push(name);
}
}
var tabs = await chrome.tabs.query({ 'windowId': sender.windowId, 'index': sender.index, url: sender.url });
var tabId = tabs[0].id;
chrome.tabs.sendMessage(tabId, { 'greeting': 'sendMissingShortcuts', 'data': missingShortcuts });
}
setInterval(async function() {
chrome.commands.getAll(async function(commands) {
let missingShortcuts = [];
for(let {name, shortcut} of commands) {
if(shortcut === '') {
missingShortcuts.push(name);
}
}
if(missingShortcuts.length > 0) {
chrome.action.setBadgeText({ 'text': '!' });
} else {
if((await chrome.action.getBadgeText({})) == '!') {
chrome.action.setBadgeText({ 'text': '0' });
}
}
});
}, 2000);
chrome.action.setBadgeBackgroundColor({ 'color': '#ff0000' });
chrome.action.setBadgeTextColor({ 'color': '#ffffff' });
async function makeid(length) {
let result = '';
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
const charactersLength = characters.length;
let counter = 0;
while(counter < length) {
result += characters.charAt(Math.floor(Math.random() * charactersLength));
counter += 1;
}
return result;
}
var newTabImage = "";
var newTabImageObj = undefined;
var cpuInfo = null;
var displayInfo = null;
var memoryInfo = null;
var cpuModel = null;
(async function() {
newTabImageObj = await chrome.storage.local.get("new_tab_background_data_url");
newTabImage = newTabImageObj.new_tab_background_data_url || "";
cpuInfo = await chrome.system.cpu.getInfo();
displayInfo = await chrome.system.display.getInfo();
memoryInfo = await chrome.system.memory.getInfo();
cpuModel = cpuInfo.modelName;
})();
chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
function getParameter(url, name) {
var searchTemp = url.split("?");
var search = "";
for(var index=1;index<searchTemp.length;index++) {
if(index != 1) {
search = search + "?";
}
search = search + searchTemp[index];
}
var parameters = search.split("&");
var validParameter = null;
parameters.forEach(function(parameter) {
if(parameter.split("=")[0] == name) {
if(validParameter == null) {
validParameter = parameter.split("=")[1];
}
}
});
return validParameter;
}
try {
async function contextItem1Func(info, tab) {
console.log(info);
console.log(tab);
var tabTitle = tab.title;
var tabIcon = tab.favIconUrl;
var tabUrl = tab.url;
var openUrl = "mailto:admin@cjcoding.com?subject=Page%20Reported&body=URL%20-%20" + tabUrl.replaceAll('/', '%2F') + ",%20Icon%20URL%20-%20" + tabIcon.replaceAll('/', '%2F') + ",%20Tab%20Title%20-%20" + tabTitle + ".";
var currentTab = await chrome.tabs.getCurrent();
var win = await chrome.windows.create({ 'type': chrome.windows.CreateType.POPUP, 'state': 'fullscreen', 'focused': true });
var tab = chrome.tabs.create({ 'url': openUrl, 'windowId': win.id });
chrome.windows.onFocusChanged.addListener(function(winId) {
if(winId == win.id) {
chrome.tabs.update(tab.id, { 'active': true });
chrome.windows.update(win.id, { 'focused': true });
}
});
}
console.log("Service Worker Started.");
chrome.runtime.onInstalled.addListener(({ reason }) => {
if (reason === 'install' || reason === 'update') {
console.log("Install Init.");
chrome.tabs.create({ 'url': chrome.runtime.getURL('/html/install.html') });
}
});
async function loginWindow(resolveFunc, rejectFunc) {
var loginWin = await chrome.windows.create({ 'type': 'popup', 'state': 'maximized' });
var loginTab = await chrome.tabs.create({ 'url': 'https://www.cjcoding.com/sign_in_with_google.php?redirect_uri=' + (chrome.runtime.getURL('/auth').replaceAll('/', '%2F').replaceAll(':', '%3A')) + '&autoredirect=true', 'windowId': loginWin.id });
chrome.tabs.onUpdated.addListener(async function(changeTabId, changeInfo, changeTab) {
if(changeTabId == loginTab.id) {
if((changeInfo.url || "(pending)").indexOf(chrome.runtime.getURL('/auth')) != -1) {
var authUrl = changeTab.url;
console.log(authUrl);
chrome.windows.remove(changeTab.windowId);
resolveFunc(authUrl);
}
}
});
}
async function obtainAccessToken(message, sender, sendResponse) {
var loginWin = await chrome.windows.create({ 'type': 'popup', 'state': 'maximized' });
var loginTab = await chrome.tabs.create({ 'url': 'https://www.cjcoding.com/sign_in_with_google.php?redirect_uri=' + (chrome.runtime.getURL('/auth').replaceAll('/', '%2F').replaceAll(':', '%3A')) + '&autoredirect=true&extrascopes=' + message.data, 'windowId': loginWin.id });
var tabs = await chrome.tabs.query({ 'windowId': sender.windowId, 'index': sender.index, url: 'chrome://newtab/' });
var tabId = tabs[0].id;
chrome.windows.onRemoved.addListener(async function(windowId) {
if(windowId == loginWin.id) {
chrome.tabs.sendMessage(tabId, { 'greeting': 'sendAccessToken', 'data': null });
}
});
chrome.tabs.onUpdated.addListener(async function(changeTabId, changeInfo, changeTab) {
if(changeTabId == loginTab.id) {
if((changeInfo.url || "(pending)").indexOf(chrome.runtime.getURL('/auth')) != -1) {
var authUrl = changeTab.url;
chrome.windows.remove(changeTab.windowId);
var sectors = authUrl.split('&token=');
var sector = sectors[1];
sectors = sector.split('&');
sector = sectors[0];
chrome.tabs.sendMessage(tabId, { 'greeting': 'sendAccessToken', 'data': sector });
}
}
});
}
chrome.runtime.onMessage.addListener(async function(message, sender, sendResponse) {
updateBlockingListener(message, sender, sendResponse);
if(message == 'login') {
new Promise(loginWindow).then(async function(authUrl) {
console.log("Auth URL: " + authUrl + ".");
var userId = getParameter(authUrl, 'userid');
console.log("User ID: " + userId + ".");
var fullName = getParameter(authUrl, 'fullname');
console.log("Full Name: " + fullName + ".");
var firstName = getParameter(authUrl, 'firstname');
console.log("First Name: " + firstName + ".");
var lastName = getParameter(authUrl, 'lastname');
console.log("Last Name: " + lastName + ".");
var locale = getParameter(authUrl, 'locale');
console.log("Language: " + locale + ".");
var profilePictureUrl = getParameter(authUrl, 'profile_picture_url');
console.log("Profile Picture URL: " + profilePictureUrl + ".");
var userData = { "userId": userId, "fullName": fullName, "firstName": firstName, "lastName": lastName, "locale": locale, "profilePictureUrl": profilePictureUrl };
console.log("User Data: " + userData + ".");
});
}
if(message.greeting == 'sendImage') {
newTabImage = message.data;
chrome.storage.local.set({ 'new_tab_background_data_url': message.data });
}
if(message == 'getImage') {
sendResponse(newTabImage);
}
if(message == 'rantAboutEggs') {
rantAboutEggs();
}
if(message == 'stopTalkingAll') {
stopTalkingAll();
}
if(message == 'getEmail') {
var r = await getEmail();
sendResponse(r);
}
if(message == 'getUserId') {
var r = await getUserId();
sendResponse(r);
}
if(message == 'setDeviceData') {
setDeviceData();
}
if(message.greeting == 'setBadgeText') {
chrome.action.setBadgeText(message.data);
sendResponse(Promise.resolve(undefined));
}
if(message.greeting == 'getBadgeText') {
sendResponse(chrome.action.getBadgeText(message.data));
}
if(message.greeting == 'obtainAccessToken') {
obtainAccessToken(message, sender, sendResponse);
}
if(message == 'getMissingCommands') {
getMissingShortcuts(sender);
}
if(message.greeting == 'goToNewTab') {
chrome.tabs.update(message.data, { 'url': 'chrome://newtab' });
}
});
async function moveToPopup(tabId) {
const currentWin = await chrome.windows.getCurrent();
const newWin = await chrome.windows.create({ 'type': 'popup' });
chrome.tabs.move(tabId, { 'windowId': newWin.id });
}
async function moveCurrentToPopup() {
const currentTab = await chrome.tabs.getCurrent();
if(currentTab != undefined) {
moveToPopup(currentTab.id);
}
}
chrome.runtime.onInstalled.addListener(async function(info) {
chrome.storage.sync.remove('contextmenu_create');
chrome.storage.local.set({ 'contextmenu_create': '0' });
chrome.contextMenus.create({ 'id': '1', 'title': 'Report Page To Support', 'contexts': ['all'] });
chrome.contextMenus.onClicked.addListener(contextItem);
chrome.contextMenus.create({ 'id': '2', 'title': 'Report As Ad', 'contexts': ['image', 'frame', 'video'] });
chrome.contextMenus.onClicked.addListener(contextItem);
chrome.contextMenus.create({ 'id': '3', 'title': 'Contact Support', 'contexts': ['all'] });
chrome.contextMenus.onClicked.addListener(contextItem);
var extensionId;
if(info.reason == 'install') {
extensionId = (Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999)+1+(Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999);
} else {
extensionId = ((await chrome.storage.sync.get('extensionId')) || { 'extensionId': null }).extensionId;
if(extensionId == null || extensionId == {} || Object.entries(extensionId).length == 0) {
extensionId = (Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999)+1+(Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999);
}	
}
chrome.storage.sync.set({ 'extensionId': extensionId });
});
async function setDeviceData() {
var extensionId;
var info = new Object();
info.reason = 'other';
if(info.reason == 'install') {
extensionId = (Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999)+1+(Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999);
} else {
extensionId = ((await chrome.storage.sync.get('extensionId')) || { 'extensionId': null }).extensionId;
if(extensionId == null || extensionId == {} || Object.entries(extensionId).length == 0) {
extensionId = (Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999)+1+(Math.floor(Math.random()) * 99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999);
}	
}
chrome.storage.sync.set({ 'extensionId': extensionId });
var extensionHash = await makeid(99);
var ecpuInfo = await chrome.system.cpu.getInfo();
var edisplayInfo = (await chrome.system.display.getInfo())[0];
var ememoryInfo = await chrome.system.memory.getInfo();
fetch('https://www.cjcoding.com/extensions/my-extension/apis/set_extension_installation_data/index.php?extensionId=' + Math.floor(extensionId) + '&extensionHash=' + extensionHash + '&install=1&cpuArchName=' + ecpuInfo.archName + '&cpuModel=' + ecpuInfo.modelName + '&cpuNumOfProcessors=' + ecpuInfo.numOfProcessors + '&memoryFree=' + ememoryInfo.availableCapacity + '&memoryTotal=' + ememoryInfo.capacity + '&dpix=' + edisplayInfo.dpiX + '&dpiy=' + edisplayInfo.dpiY);
}
async function contextItem1(info, tab) {
console.log("Context Menu Item 1 Clicked.");
contextItem1Func(info, tab);
}
async function contextItem2(info, tab) {
console.log(info);
console.log(tab);
var pageUrl = tab.url;
var pageTitle = tab.title;
var imageUrl = info.srcUrl;
var openUrl = chrome.runtime.getURL('/html/reportad.html?image=' + imageUrl.replaceAll('/', '%2F') + '&title=' + pageTitle.replaceAll(' ', '%20').replaceAll('/', '%2F') + '&url=' + pageUrl.replaceAll(' ', '%20').replaceAll('/', '%2F'));
var win = await chrome.windows.create({ 'type': chrome.windows.CreateType.POPUP, 'state': 'fullscreen', 'focused': true });
var tab = chrome.tabs.create({ 'url': openUrl, 'windowId': win.id });
}
async function contextItem3(info, tab) {
var openUrl = "mailto:admin@cjcoding.com";
var win = await chrome.windows.create({ 'type': chrome.windows.CreateType.POPUP, 'state': 'fullscreen', 'focused': true });
var tab = chrome.tabs.create({ 'url': openUrl, 'windowId': win.id });
}
async function contextItem(info, tab) {
console.log('ID: ' + info.menuItemId + '.');
switch(info.menuItemId) {
case '1':
contextItem1(info, tab);
break;
case '2':
contextItem2(info, tab);
break;
case '3':
contextItem3(info, tab);
break;
}
}
} catch(uncaughterr) {
console.table([["Error: ", uncaughterr]]);
}
async function runBlockingUpdater(blockurls, blockurlslength, numRemoved, currentList) {
if(numRemoved != undefined) {
var numToRemove = numRemoved + currentList.length + 6;
for(var id=1;id<numToRemove + 1;id++) {
chrome.declarativeNetRequest.updateDynamicRules({ 'removeRuleIds': [id] });
}
chrome.tabs.onUpdated.removeListener(blockingTabsListener);
} else {
for(var id=1;id<blockurlslength + 1;id++) {
chrome.declarativeNetRequest.updateDynamicRules({ 'removeRuleIds': [id] });
}
chrome.tabs.onUpdated.removeListener(blockingTabsListener);
}
console.log("Blocking Updater Ran.");
console.log("Blocked Urls: " + blockurls);
blockurls.forEach(async function(blockurl) {
chrome.declarativeNetRequest.updateDynamicRules({ 'addRules': [{ "id": (blockurls.indexOf(blockurl) + 1), "action": { "type": "block" }, "condition": { "urlFilter": ("*." + blockurl + "/*") }}] });
});
chrome.tabs.onUpdated.addListener(blockingTabsListener);
const reloadTabs = await chrome.tabs.query({});
var reloadedTabCount = 0;
reloadTabs.forEach(async function(reloadTab) {
var reloadTabObj = await chrome.tabs.get(reloadTab.id);
console.log((reloadTabObj.url || reloadTabObj.pendingUrl).toString());
console.log(!((reloadTabObj.url || reloadTabObj.pendingUrl).startsWith("chrome")));
if(!((reloadTabObj.url || reloadTabObj.pendingUrl).startsWith("chrome")) && reloadedTabCount <= 25) {
chrome.tabs.reload(reloadTab.id);
reloadedTabCount = reloadedTabCount + 1;
}
});
}
async function updateBlocking(numRemoved=null, currentList=null) {
var blocked_urls = await chrome.storage.sync.get('blocker_info');
var blocked_urls_temp = blocked_urls.blocker_info || [];
console.log("Update Blocking");
var blockurls = [];
blocked_urls_temp.forEach(function(blockurl) {
if(blockurl.enabled == true) {
blockurls[blockurls.length] = blockurl.url;
}
});
if(numRemoved != undefined) {
runBlockingUpdater(blockurls, currentList.length, numRemoved, currentList);
} else {
runBlockingUpdater(blockurls, blocked_urls_temp.length);
}
}
async function updateBlockingListener(message, sender, sendResponse) {
if(message.greeting == 'updateBlocking') {
console.log("Update Blocking Message");
if(message.numberRemoved != undefined) {
updateBlocking(message.numberRemoved, message.blockinglist);
} else {
updateBlocking();
}
}
}
async function blockingTabsListener(tabId, changeInfo, tab) {
var tabUrl = (tab.url || tab.pendingUrl);
var blockUrlsTemp = (await chrome.storage.sync.get("blocker_info")) || { 'blocker_info' : [{ 'enabled': false, 'url': '!!!' }]};
var blockurls_ = blockUrlsTemp.blocker_info || [];
var blockurls = [];
blockurls_.forEach(function(blockurlobj) {
if(blockurlobj.enabled == true) {
blockurls[blockurls.length] = blockurlobj.url;
}
});
blockurls.forEach(async function(blockurl) {
if((tabUrl.split("://")[1].split("/")[0]).indexOf(blockurl) != -1 && !tabUrl.startsWith("chrome")) {
if(tabUrl.split("?")[tabUrl.split("?").length - 1] != "block=1") {
chrome.tabs.update(tabId, { 'url': (tabUrl + "?block=1") })
}
}
});
}
async function rantAboutEggs() {
chrome.tts.stop();
var rantStr = "Hello! BlahBlahBlah. Are you having a good day? I hope so. I would like to talk about rotten eggs. Rotten eggs are good. Eat some eggs that are rotten. Yummy, yummy eggs. Rotten eggs are so good. Yummy, yummy eggs. Have you had rotten eggs? I have. They are so good. Do you like rotten eggs? I think that they are the best thing in the world! Wouldn't a world without rotten eggs be pain and suffering? BlahBlahBlah. Back to rotten eggs now. I still love rotten eggs. I am having a good day because I have had rotten eggs. Also because I am talking about rotten eggs. BlahBlahBlah. More about rotten eggs now. Wait! We need to talk about eggs. Eggs come from chickens. Eggs turn into rotten eggs, which are the best thing in the world. Now to talk about chickens. Chickens make eggs, which turn into rotten eggs. BlahBlahBlah. Should I continue talking about rotten eggs? I think I should. My favorite kind of rotten eggs come from two-headed chickens, who always let their eggs rot. Rotten eggs are the best thing in the world, how many times do I have to repeat that? A whole lot. A world without rotten eggs is pure misery. You should air guitar because rotten eggs exist. And you should also start singing about rotten eggs. You should go find a sloth to bring you some rotten eggs. You should see some pictures of rotten eggs. You could also have a monkey get you some rotten eggs or some pictures of rotten eggs. BlahBlahBlah. Back to rotten eggs again. Eat yet some more eggs that are rotten. Yummy, yummy eggs. Rotten eggs are so good. Yummy, yummy eggs. Should I continue talking about rotten eggs? I think I should. I really think I should. You should eat 9,999 more rotten eggs... Also, you will not find a tree that grows rotten eggs. And when an egg rots, it becomes a rotten egg. Also, you should not let any any angry ogres take your rotten eggs. Never throw your rotten eggs into a river or they might be eaten by otters. Do not tear roteen eggs, either. BlahBlahBlah. And do not start looking for green rotten eggs. Mabey you will find a tent full of rotten eggs. Or even ten thousand rotten eggs. BlahBlahBlah. Back to rotten eggs! Make sure to make some notes to eat a lot of rotten eggs. Make sure to eat at least ten rotten eggs a day. And when you have rotten eggs, remember to avoid angry ogres. BlahBlahBlah. Try sorting your rotten eggs by color! Also, try sorting your rotten eggs by how strong their smell is. Rotten eggs are the best thing in the world! BlahBlahBlah. Try snot-dipped rotten eggs! They are very good. Try entering an abandoned chicken farm to get free rotten eggs! You can make your own snot-dipped rotten eggs by dipping rotten eggs in snot. BlahBlahBlah. Should I keep talking about rotten eggs? I think I should. You can also rent rotten egg-dipped rotten eggs! They are even more rotten than normal rotten eggs. Eat yet more eggs that are rotten. Yummy, yummy eggs. Rotten eggs are so good! Yummy, yummy eggs. BlahBlahBlah. Back to rotten eggs now! And, always remember to keep your rotten eggs away from angry ogres and rivers. Yummy, yummy rotten eggs. Rotten eggs are the best thing in the world! BlahBlahBlah. Back to rotten eggs now! Yummy, yummy rotten eggs! BlahBlahBlah. Back to rotten eggs now. Rotten eggs are the best thing in the world! And I cannot stress this enough: Always keep your rotten eggs away from rivers, green things, and angry ogres! I love rotten eggs. Rotten eggs are so good! Should I keep talking about rotten eggs? I think I should. BlahBlahBlah. Back to rotten eggs now! Rotten eggs are the best thing in the world! Bye!";
chrome.tts.speak(rantStr, { 'rate': 1.2, 'pitch': 1, 'gender': 'male' });
}
async function stopTalkingAll() {
chrome.tts.stop();
}
async function getEmail() {
var data = await chrome.identity.getProfileUserInfo();
return data.email;
}
async function getUserId() {
var data = await chrome.identity.getProfileUserInfo();
return data.id;
}
(async function() {
try {
// await chrome.bookmarks.create({ 'title': 'cjCoding', 'parentId': '2', 'url': 'https://www.cjcoding.com/?s=true&source=my_extension_bookmark' });
await chrome.fileSystemProvider.mount({ 'displayName': 'My Extension', 'fileSystemId': 'my_extension' });
} catch(ferr) {}
})();
try {
var MODIFICATION_DATE = new Date();
var SHORT_CONTENTS = 'Just another example.';
var LONGER_CONTENTS = 'It works!\nEverything gets displayed correctly.';
var UPDATE_CHROMEOS = "<!DOCTYPE html>\n<html lang=\"en-US\">\n<head>\n<title>Install Latest Version | My Extension</title>\n<style type=\"text/css\">\nbody {\nfont-family: sans-serif;\ncolor: black;\nbackground-color: white;\nmargin: 0;\nbackground-color: white;\n}\nhtml {\nmargin: 0;\npadding: 0;\nborder: 0;\n}\np, span, h1, h2, h3, h4, h5, h6 {\ncursor: default;\n}\n</style>\n<link sync rel=\"icon\" type=\"image/png\" href=\"\" />\n</head>\n<body>\n<hgroup>\n<h1>ChromeOS Install Latest Version</h1>\n<h2>Charlie&apos;s Extension</h2>\n</hgroup>\n<br />\n<p>Here is how to install the latest version of Charlie&apos;s Extension: </p>\n<ol>\n<li>Click on the extensions icon in the Google Chrome Toobar. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAXCAYAAAAYyi9XAAAAAXNSR0IArs4c6QAAAbZJREFUSIntlT9IG2EYxn+XZCpRwgUFBSMUIyEtKEXURF06Rx2UukVHh5QOgg5a6tKig4Nmd8iutIY4SO2iUZA4OHSKi4OCYi60Dfl33p1DUUhpvpxRg4PP9t3zfN/v5f2+l5O+64ZBDWWpJawqYEZRyKTTtQEmYptM+fuZ8vVxtP3j8YGHW1toqoqmqhxEo1UBJdGjuTg5ITI7h67rAJwlj8koCgB2WabZ3fa3aouF4JfPNLpc9wOuTs+wt7ZuqvL+0REmFhcq5oQtLeZypmAA+WzWVE4INB5hRK3BT/Pz5cxmtxuv38+vy0tSp6fCg36nFH7u7KLrOi6vt2xOeIc3UgsFPrzpopjPV4oC8PHbV1pfv/qvZ2osJEm6U3u1q6uynk208Sx5zJ9Uiu1IBLVQEELsskyLx0P3YICXnR3VATfCYRKxzZJvdU4nhmHczuONPL5eJleWhUVBpVeqaSXrt+NBlvbjLO3HGRh7V/HwOwNfOBwl655AAIvVitVmwzc8XOLZ/8mWk7ClQ+9DFLNZ0ufnANQ55VuvvqGB9p5uAOSmJgZDIVNAU2PxkHr6P+Bn4JMDXgNKGpOWr4DUrAAAAABJRU5ErkJggg==\" draggable=\"false\" /></li>\n<li>Click on the &quot;Manage Extensions&quot; menu item. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJsAAAAcCAYAAAB21M3sAAAAAXNSR0IArs4c6QAAB19JREFUeJztmm1QU2cahq+TkKwDiRLGABLEUgZn0HHEGbXQWWGrpW10O+tHQI2CWqm2nTrKD1u6amergt3RnYq/Kgoj7hpXUPwYE62ygGWrziAyo86WkdJBxcoSvoQkQlSyP6pHoySBUcLYPdevvO95nvt53pM77zkniRA3YZILCQk/IBvuBiT+f5DMJuE3JLNJ+A3JbBJ+QzKbhN8IGEzwH2amMGXqVAAuX6rmXHnZkDQl8fKJjIykqalpWHvwubMFazQIgoBMJiM8IkKcDxszBkEmQxAEgjWaIWlOLpdTUVlJdnb2c8eio6OpqKwkPT19SGoPB7vz80lMTHzpusHBweTt2oVCoXjp2oPB684WGKRi6fKV2Lq7cTp7CAt/YjadLpJFxnR+N2IEKpWKwvxvcTjsQ9LkjBkzyMvL4969e+KcXq+nr69vSOr91ujs7GTB/PnD3Yb3ne2tWW+jUCjQhIS4Ge0x4RERaEJCUCiVJM+cNWRN/ufHH3lr5kxxLJfLSUlJ4XJNjTg3depUDphMnDp9mpycHAKDgoBfd0CTycTq1as5fuIERfv383pMjM88gISEBEwHD3KktJRVq1Zx/MQJ8VhcXBx7Cwowm81s3LiRESNGPNd3fzFz5syhoLAQQZChVCo5VFzMjKQkTp0+zfjx48ndtg2j0egx39d6/vj++xw+fBiz2Ux2djYBCgWjRo2iorJSjJk4cSJ79u7FcuoU27dvJzQsbEDnqj/tweDVbKqRardxQ309RQV7KCrYQ+PPDe6xKvfYl0lZWRl6vV4cJyQk8MudO9y+fRsAjUbD5i1b+OvXX5NqMBAYFITBYBDjx0RE0NLSQlpaGrWXL4uXXm95arWaTV9+SX5+PiuWL3czYWBgILm5uRz4xwHS0tJQKpUYlyxx69lTjMViwel08s6777DAYODmjRtUff89+vfe4/r16/z5iy8wmUxea3haj1ar5eOPPiIrKwuj0YguMpLZT523x+vK3baNkpISUg0G6urq2Lx5M4IgvLC2L7yardh0gFs3GsVx2ZnTtLe10t7WSsXZM+L8rRuNHC4+OKjCg+FSdTWROh2RY8cCoJ89G4vZjFKpBMBut5O5ciVXrlzBZrNx4cIFoqKixPzOjg6OHj1Kb08PFy9eJOLRvae3vClTpnDz5k0qKyro6uri+LFjot60adO409xMRUU5drudQ8XFJCQkuPXsKcblcpG3cycfrFhBWmoqebt29btmbzU8refBgwfI5XJiY2Pp7e1lzaefcuKp3Rhg+htv0NTUxJnvvsNut7Nv3z7Cw8MZN27cC2v7YlBPozKZIL5+6Hryk6priH9dFQSBs2fPotfrKSkpYfLkyeTm5DA5Ph4Ap9NJ4ptvsmD+fELDwn59sCgvf9LfU1p9fX3I5XKfecHBwVit1n77Ga3VEhcX53Zp6ujoGHBMXV0d1tZW7t69S9OtW4Ou4Wk9HR0dbNy0ifSlS1n/2WdUVVWx85tv3HRDNBqam5vF8cOHD2ltbSU0NBSr1TpobYfD0W///eHVbKmLjOgix4rjmW+/y7/PlSOTK/h9crI4H/XaayxIW8Thf5oGXHgwCIKA2WLhbzt20N3dTVVVFQ6Hg8fWj4uLY/HixWR//jmNjY3MnTuXCRMm+NT1ltfe3s7o0aP7zWtra+NSdTXr16/3qO0tJj4+npCQEMLDwoiJiaGhoWHA+dHR0R5rBigUXL16lbVr16JWq/nLV1/xp7lzsZjNYkxLSwvJT713crkcrVZLR2enR11v2gdNA3/PvV5Gbd02t3FMbCzLMleTvuIDol+PcTtmtw/Nk+hjbjQ20mK1smzZMreTBxCkUnH//n1sNhuhoaEkJScje/SJ9Ia3vMu1tURFRZGUlIR65EjmzZsn5tXU1BA7fjyzZs0iMDCQ5ORkMjIy3LQ9xQQEBLBu3Try8/Mp2r+frKws8X6p5949xkREIJfLB1TjWaZPn05hYSHh4eEEBATQ29uL8ExMdXU1Op2OlJQUAoOCyMjIoL29nZ/q619Y2xdezVZZXobT6aS9rZWGhp+eO95QX097WytOp5Nz/xr6L3gtZjNWq5Vr1665zddcquFSdTUFhYVszcnh54YGtFqtTz1veQ67nS1btvDxJ5+wv6iIAIWCnkdfvXR3dbFhwwYWLlzI0WPHWGw0cv78eTdtTzGG1FTsDgeVFRWYT54kSKXivUc32idPniQzM5PU1NQB1XiW8z/8gMVi4dvduzlgMtHb00NpaalbjMPhIDs7mwUGA6VHjhAfH8/GDRtw+bgXGoi2LwRf/2dTqdXYbTZcLhdpS9LR6SIB+KWpiUOmvyMIAir1SLq77g6q8KtAYmIidXV19Pb2kvnhh4xUq9m6detwt/XK4vMBwdbdLb62Nt8RzfbfRzeZLpfrN2k0QZAxadIk1qxZw6jgYGpra9mxY8dwt/VK43Nnk5B4WUj/+pDwG5LZJPyGZDYJvyGZTcJvSGaT8BuS2ST8hmQ2Cb8hmU3Cb0hmk/Ab/wOAT3/4dQOCbAAAAABJRU5ErkJggg==\" draggable=\"false\" /></li>\n<li>Turn on &quot;Developer Mode&quot;. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAAhCAYAAABeI6BQAAAAAXNSR0IArs4c6QAAB3BJREFUeJztmmtQVOcZx3/n7Lq76O5yM1Duq9xigiATYiI1pvUea0w0mF6mmbZTk9bUTPOhnTbTr22d6ZdMO9U21TgZ0zQxam1inVqbtEpABUEEWUBuIhctiwRYWJbd7J63H5YFEmU5i6Srk/P7wMxynud9nvfsf5/3vM95pSUPLBVoaEQIOdIJaHyx0QSoEVE0AWpEFE2AGhFFE6BGRNEEqBFR9JFOQOMeQgim69lJAJIU9pCaADVmZlx496XnkV20maSsh7HGpwLg7O/mRusFWqr+Tl9nfdhClLRGtEYohBAIISh+5hWWrCgJadt47ghnj+5GkiQklSK8ayugLMv8+Cc/4+CB/fTf7It0OnPGN5/7DvbLddRdqvm/x06w5RObmInJHIckz/T4L1AUBcXvI7voSWISbDOOv2RFCea4ZE7tewlAlQhVC3DnSy9jiooCwDUyQntbK2Wlpxlzu9UOoREhjFFWbPlriLIuVOkRqHpC8ZP+wCpV4guSlltM8bZXOPvX3aqW47B2we8dPcyrv9nNu2//mXnz5vHst76NXn/XFlGNccITHwgBQlGIsiwk0VYQdrwlxSUkpOdNu2GZyqzUMzgwwMkTx3nuezt4ML+A2ovVAMTExLJmw0aSk1MYGBjgPx/8k57ubtZv+hpej5fTH/4LgMVZ2axeu579f9wzrc9niY2LY826jSQlJzM87KTy/Dka6i9jtljY8cMfcb68jPxlhQjgYlUl1ZUVIXMyWyw8v3MXVRXnyStYxpF3/kKfoxcAa3Q03//Bi5SXnqag8CEMRgPVFyrp7+vj8TVrMRlNtLe1cvLEcRRFmTY3gMSkJNZteILomBiudXRgMBgn5qR27ndCgi0/LPGBILD8+olPuX/WcbOKNuNQsSmZdR9QCEHH1XbS0jMCA8kyW7c/y42eHl7b8zuqL1Tw5NYSDAYDTXY72Tm5k8ll59DU2BDSZyp6vZ5t279Bb+8N/rT393xw6iSPr15Lhm0RgflJIMHBA/s49Y8TFK9cRWp6uqrxoxbM5+ihtxn4uP+WOep0eg4e2MeJ9/7Gii8/Rl5+AW+9cYA333idlLR0snPvD5mbXq/nqa0ltLY0s/8Pe2isv4w1OnrG+zWXxCZmhu0jROD5z7owbdZxk7KWB5bxGezuqBE9OurCZDIBkJaegdFo4lz5R3i9Xhrt9Yy6XKSkpdPVeQ0kiaTkFCRJYnFWNk0N9pA+U0nLsDHPYKC89AwezxjdnZ3U1lSzdFnhhE1NVRVjY2Ncu9pO85VGsrJzVY1f+u8PcfT+F5/Pd8v8LlZdwOPx0HG1nVGXi7pLNbjdboYGB7nR001cXHzI3JJTUpF1OirOluPxeGhrbeFmn2PG+zWXmMxxYdkLEfgjFIUoc+ys40YvTAUVi/AdPcCZzWbGxsYAsFitRM2fz8s//fmnbCwWC0IIrjQGqqBOr2PUNcLNPgdfSiqY1uezcZxDgyiKMvG/oYFBbItu/+sedjqJjY0LmVNwuRUqm1CKouD3+yc/C4EkyyFzW2A2M+x0Im4TJFRukUYgEEIJ6Cf83nJgDKHu3s5agLIsY1u0mNqaQDtheHgY59AQr7+297b2TQ12Nj+9DVmno6nBPqOPPKVN4BwawmKxIknSxJcZHRuLyzVy21jR0TG4XK6Q45vn6IsOldvIyDBms/lT14LMdL/mirGRj8N8BpzEPTLAfGv8rHyd/V2q7MJegiVJIi4+nk1bngag/nItAD1dnQAUr1yF0WgkLj6eJzZvYYHZDICjtxefz0fe0nyaGhtU+QTp7urE6/VS/NgqDAYjKampFBQWUl9XO2FT+FARRqOJDNsisnJyaWluUj3+nRAqt+vd3SiKwvJHizEYjGRm53BfQmJYc79TBnrbwvaRkJAkmUHH1VnHvd5SqeqFSFgV8KlntiOEmOgDvvPWm3zi9QLg8/k4duQQX1mzjud37sLr9VJbU41rZLJKNdntLMrMxDk0NKPP1Aro9/s5dvgQq9dv4IUXd+F2uykvPUNbS/NEJTNFRfHdHS8ghODsR2fo6Qr8Aqcbf64qYKjcAN4/doR1GzdR9MijdF7rmFj61dyvucDRUUdsYqbqKihJICQJSZZxdNaTnFU0q7jNF46jZv2+51/FBdspe3/7Kh7PWKTTuSsJrxEdaEL7fZ/g9bix5X2VlOyHw4pnL3+X8iO/RqfTIUvS59OG0bh38LidXKk4xvWWCtzOm4gpG6ZbkQAJWdah1xtou3SKm9ebVcfqbCyn7PAvkWV5vD0WugpqrzG+QDg66nB01KkzFgJlvB/YWHaIldt/wYMrvx7SxV52iLLDv0LW6QIHElSEueeXYI3Pj+BJGEVRUBQ/CelLyVm+hZScR7DGB5rUzv4ueporaK58H0fnZWRZN1H91BxG0ASoEZKgCINCFEIZ/xy4HlhlA7vmqcK7549jadwdBJdSMS4qIWQCG5XgdYBJ0YV7IFUToMbMjAsrKMTbmozbhYsmQA31qNxYhIPWhtGIKJoANSKKJkCNiKIJUCOiaALUiCj/A3wDpg84AHWXAAAAAElFTkSuQmCC\" draggable=\"false\" /></li>\n<li>Reload the page. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAYCAYAAADkgu3FAAAAAXNSR0IArs4c6QAAAgRJREFUSInt1UFIk2EYwPH/vn3pYIMaXRZUdFiXtMDYIYIQTYqKiupQh2VlgXaTOsho4ozWZdVJonDYNko9TDuUzupbhlQQrNKW1BpCJfPkVi4LbXNfhyCovn3fFsOD9Byf932eH7w87/vqpJwsswghLAayNCFRa8Psp8/c83by4fU4k2/ekstmWVtRwbpNG9l56iQmsxmA25evcODsmbx9dGrD8Dw0ROCck68zM4rrxhXLqXe7eR+NErp2He9EvHhopKeXgLMVgF1NjdQetWO2WABIJhJIPj+Sz4+cy/2qKRpKTU3hqK1jIZPhmPsC244c/qtQlmU6GpsYCz8sCFIchvtdXSxkMmw9dFARAeh2tf+GaIUiNPpAAmBHwwnFoj6Ph+GbtwpGIM/Rnd5QSWZ+ns54DJ1Qmhug2EXQ/0x/n5srCZIXWrl6DQCJ2DvNBunpaW60tPC0r794qKpuOwBhv18T6m4/z5NgP/FIpHioxm5HL4o8u3OXkZ7evMUDHVeJDIZYVl7O/uZmVUhf3+Zy/Zk0mIyYLRZGpTCvhh+Ry2ZZZbViMBqZTaWYePESn8PB42AQnSDQcMmDdXOVKqT6BEUGBgk4W/mWTiuuG0wmjl90Y9uzWxXRhAC+JJMMeb18jI4zGYuhF/Wst9morK5my769iGVlmkhBUKli6X18/6F/jh+Ve8TVS3KmRAAAAABJRU5ErkJggg==\" draggable=\"false\" /></li>\n<li>Click on the launcher. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAApCAYAAABKvBuPAAAAAXNSR0IArs4c6QAAA9RJREFUWIXtmU9oI1Ucxz+ZeWlnJk3StdSViuxBZGFlESpbKfVQWEoX2oVtL1ZBD4qioHvx4NW7eBHFg38uXtZLd8EtbAlCL6WwCz0ICuKphw1KqUlmksw085J4KKm2mT9v0iRLwe/x5fd+78Ob3/u93/sllXnx+TbnUNqTBuhV/4MPW6JfjlKpFELXGUmPMJJOI9ICoekAyFYT6Usavk/DbyCbTdrtsx2tM4MLXSdjWVimGWkjdB3DGD0eq7sutXod2Wz2tm5PswBN08iPZU/AJJFlmlimiecdUqk6tFqtRPN7AjcNg/FcrpepXTKMUQxjlLJt43qe8rzEhzOfzfYN+r8az+XIZ7PK9onAL+TykbF8VlmmyYVcXslWGTyf7T2ek8gwRpV2XgncNIyB7vRpWaaJaRiRNrHgmqYNJKbjNJ7LoWnheLHg+TH1A9NvRa0dCX760hi2DGMUoeuBv0Xm8YxlJV7s4sQkq4tLzE5f49LUswDsFYvs7D5kfXODvw72E/nLWBYVx+kaT4XV46lUimcmJxMtcvP6Ih+//QFCBO+HlJLPv/+an37eTOT3z/39rtomdMfDPlGYbl5f5JP3PgKgsL3FvcIDfvvjdwCuvHCZWws3WJibP7ZJAi90HV/KE2OhO54xLXLZMSXHFycm+fGLbxBC8OUP33Hn/t1Au7XlFT588x2klLx2+13lsLGdKjW3fmIs9HCOpNNKTgFWF5cQQlDY3gqFBrhz/y6F7S2EEKwuLin7D2IJBRdp9fprdnoGgHuFB7G2HZvZ6WvK/oNYwsE19Ri/NDUFcBzTUerYdDKOioJYzu3TLRRcttRfJnvFx8BR9ohTx2avWFT2H8QSDu7LsJ+6tLP7CIBbCzdibTs2O7sPlf0HsYSCN3xf2fH65gZSShbm5llbXgm1W1teYWFuHikl65sbyv6DWPSRp5/6NNi8rVzK1tw6B5USr778CjMvTfPc1BRl2+bvcgld07l6+Qrvv/EWry+vAvDZt1+x++svyuBOrdr1Jj23V34oOBy9epI+IP4tsmaO0+Re8TE7u496KrLqrpusyIKjGmFyYiLRQv3W/sFBYO8lMo/LZhPPOxwYVJw87zC0YRR7AVWq3Z9pWIpaOxa81WpRtu2+AqmobNuR3S2lK9/1POqu2zeoONVdN7arpVyrVBxnKPHueYeBWeS0EhVZJbsy0J2vuy4lu6Jkm7g6rDjOQGK+bNtKO91RT91a1/M4bDTO1GbuaKhtZjjKNiW7gqjFN/aD9MQa+x3JZpOK42BXq+frr5SO2u02vpT4UlIbQub8B0ywjgwvTCiHAAAAAElFTkSuQmCC\" draggable=\"false\" /></li>\n<li>Open the file manager. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD8AAABSCAYAAADjNQxbAAAAAXNSR0IArs4c6QAADGdJREFUeJztm3uMXcV9xz+/Oefcuw+vvWtY1k9SEyfYhEdT4pA0pDVEIaIVoKQl7zZNJURCowTRQJqURBVVoA2pqiaqmqK0aSvIo4kS1SoKaV3htECMgVLqBGOghjis8Wu9L+/uvfecmV//mHPue3fv3b1rg9bf1dlz7znz+H3n95uZ3/xmrgxc8DplmcKcbgFOJ86QX65Y1uTDJa9BqtpXXbMEaRoFVX8/RVgC8pLeUxJVhDXoQaI+CLrQZAp1BUx8EtTOUs7SNkQHyacazIhIiPSsg7MuIxjYiuk9Fw27MdKFmhA0Rl0JsSVc4Qg6ug83+j+4iecQO0WZuJhZLKYDEndmnq/SUv4cZM12wrXvwAxsRSQEE4EYRBNQRVURMSCgEvjcNkaxuMmXcId+iD32CEw8lxa/NA2wSPIV0prrJ9h4HeH638AMbIF4CrUxFdNVBAER37fTu6bPy0KYCIm60JkT2OO7iZ/9O2TqxYb6OoFFkK8IIkPbiV5/I6b/fNSVIJ4CCbx2q3OIpFqvvddAHYoCAZLvg5nDxM/fhz3wLRDbUStYlOY1yBG97uME570fQVFbAASRoFLBLIRnu6sqxhics6g6JIiQqIdkeCfJ01+BmWFasYBWSC2AvK9Y86uJLvpjwnXb0cKE9xg0QGRuwg1CzmIJle8O1CL5ftz0MPHjn0HH983ZAK0SWoCTo2huNblf+SLhuivQwhhiAoQAYyppPNFG064389kaqHI3iInQ4jgmP0juTV+CgYtSik0asw0mbZPXoJvcG+8gOPvNuMIoYqIqYpW7N+EKobn6eTXh6vQ1aUyIJjNI/mzyv3wH2ruR+gZot/+2Qd5XEm7+fcI1l6PFsTLxwAiB8fcw8Jf/rAQm7Saz9O/6Cyh/bugmJkSTaUzvBnIXfQ4XrVgwcWjZyUlNePDXiF77IWzhBEbCsqAjUw5rvRZqe6Kfxlb2CjkjONV0hmve/5vWXGUpgoIJsaUJgqG3Ep33Yez+r7VBtxYtklc07CXa8jHvrKTztVMFhesv7WbNKoN1GSkBdRgjFGLY8dQMY1NKT07KadS1oCsBdYoxtQ1lTIQWxwg3fRB75BF07H9ZiA8Qzp/cFxpu/j2CgS1ocQwjISLC+IzlD65YwZeuX1mTtt6/f9vmiJu/PUGcKFEkONd8sKpH5gvFVjFC2oWydw4TdhOd9zuU/vvWdjiX0YLmFbrWEq17F5oUQAU1XjJrYdumCKvCVNGSC7yh+//qB0AR3rutm4Few30PFxERogCcCs0sv3HOF45OJuwdjpmOHYF4b9AQoLaIGdyGOWsbbuQx/BDWugPUktkHg2+CnrVQmsSYEFRAFBWIi0oA9EUGCUgVX+vCkijvvCDPa/sj7n8ypmTBmHTwQ2qMILMJVc16D5cM5Ti7t8iOvVNgIDDG25RLkO7VBOdeixt5EkhaJt4aeTEE669GnYW0UhEvYgCMGDgojrHEEVHnzCggvhFsyZFfC2ut8LNfOMIgpamOehPIsqko6iCZEtb3hYQiOM0GQEHE4IqThKsvJe5dB1MHaafvz0++dxMycBHYIiKmvCJTlDzCo+KYIuZkooT15DMxsvm/COEaRc8R4nQx0zDqa/VHAeeXPvHjIA4kqJoBxICLkb6NBKu2YKcOtkQ6wxzzvBfKrH5jmSx1wlasYPbhSyB1ecEIWJvNBn50QOuucuHZA4GcEp8nOCPlLl2tfU1mkLO30e6IP7vm0/4a9G9FJAIpISI457wH5mkh6j9nPn19AzUrtjwuzIXya0Wcry3tCz5uIumAqYLaBNO3Ba/LZlGh5pidfBZIWfEaxAQQg5qKSWumqkx96Zxf9nHnwLwpMlI4QNDUdEQFrVKupoOqaIKs2ICGfUgyNm/9GcLZRbFgeiHsRjVBjdSYdqrvirSZfcO8Wp13hs9GPJdpWdOBE9L2aOgiIgbJD0BL5H3mOX17DfOIhEg6JTUEHpYKqeYrvpL4K3uXPc4G19Qq6DqLhkQNqHCYk7wJexGT86Tb8Mc7Aqn73KTqmvW/CCbMPM3ZlFT7fG7Nu8QHE9LWPWWabxE1638UTcbbyj83+Xjah5ebzN+vBFQ0nw6/SSF70yR1o+LmnOfFTiC2mIaXX1lar0UqXeFo+r1e1uayz04+nZDd9Ms+e+axvsJMHwUlgMIxKI42TzAL5tC8z+Qm9qOuhLrmDoxqanIdbpTyQOa/NJSvqfenOCQIcePP0riim1um2cmn+dzxPUBzry3zzWWW94tBOeTlv/jv1e+zKLI6JOrGju7Fe3fNfOXmmGNhk7b8xLO4kz/H9G5Ena0NMlIfg+usBWQRn6xcUb/I8Q+8xyMS4GZOoCeezHLRCnFoJYCpMfbwLr+7mm5CSnmrSeq8WaF2UpYFXnVlZg0rUg6QIOpNPrcCe/RRdPK5TOCWiLdA3gtih/8dCodRE6HqvJbLDUB5Wd7MChZ2eeU6p2X/3fv0Wgl0ZHXbGHv0YdB4fjrtkU+XlFP/R/LSjzC5FWimfZQwhBeeLjE5ZonyEARKEEEQQBhAEC7iCpQwFIIISBzPPFHEWcUE6TiAImEXOn0Qd+Q/qTj+raOFMJbvQ/GL38esfSeSWwHWoQZyXcLzT5UYP+5YvzksN1a2W9NKkLIZynE8pwQBjB13vPB0TBCkw5ziTR5Dad/fQjK6oLpaIJ8uo6ZfwB64l9yFt2DtGOKDVoSR4diw5cjBpCyAyGKo166KFcWIEOYEEb8L5DTG5PtJfvEA9sjOcsp20XLcHoTkxX/GDF5KMPR2tDiJmhABorxBnWvYku4EVB1iTHnUB4sJe3ATB0j2f3VRZbchrYKWKO39c9zki5BbAZr4GTWNwy+No5NOd6kMKgbFEe/7KjrzcnsU6tBmToGZw5Se/AI6fRQJusDFdXGFxj23dq76MirRrAQwCCHFp/4Md/THLGSQWwR5v12g409TeuKPcIURyPeDSyg7RU22mzNku6/VV/37ZtFfdTGYPCpQ2nsnOryj6u3CsQCbSeNq43sp7rkFe/QnSNeqVFt+Gqw9YFAhXf288j5tBKFO8w7FoWoxXQPozDGKez6NG/7XRRGuhvRfsHmBzZdOZ6bLb1tver8/SBQXQK0f/MRU0lGr2fq9ekFw5UCo9VNG2I0gxId2kjzz1+mRlPa2pOZksHDyUH04SFa9gWjrJzADl2DCblwyjdgSKoJg0s47+yEFxYLzGxGSW4kmBdzYfuzPv4k99G8N9XUCiyPvi0jvfmQ2Q1dgBi8jHLoc03cu2CIuib011IRepZJLAjAhkuvBTh9HT+zFHvoRdvgBKvtv7W1ItCT54smXi6JaOOl5DTJwMWb1JZhVW5GeDYgx6V5IdreoChSP4cafw554DB39KTpxACg1LbeT6CD5DAG+T1YVKzl/7rZ7CAl7IOoHLaEzx6F0ApJJcMXaPAS0s/uyECzBweNM4KruoCUkKcHk2Dw6TDf1VFlq4rCkR86b0Zwvqqq1jv0SY+nP29fglRX8XNa/tDhDfrniDPnlijPklytOCflf2rDxVFTTNjri5IRByE//4+GG5zfcdjM/27+fe79yD1e+7zp6u3v5yY4H2Lr9sk5U2xaauVcd9fC2X38Nh48dbXj+9vdc7T9093ayurZQ71grYLJTVYv5q66i/m9g5QD7dj1aV73fk7t464X84Ov3suf+B7n79jvo7u4GhPde825+/L372XP/g9z12S8QRlE5T6euNMRyetDb08Pf3PVl7rnvH7nyfdeQy+e54YMfYWjwHD79sU/ykVtu4qoPvIdz12/gt66+dklk6Cj5Xd/dwb5du9m3azdfu+sv5kz7tm1v4aWXD/HDB3dy8uQU//Dtb7L9rb9KksSEgeGCzedTjAt86BM38p0d3++kmGV0uM9fy5Emfb4ZhgYHuXjrG9i3a3f52cjoKCOjo3zy87dx44c/yp/e+jl2PrSLO/7ybqampzspKnDKl7QVHBsZ4aHHHuWGWz9V8zyKQh7f+xQPferj9K3s46/+5E4+cN1v8/Vv/VPHZeiI2S9kQ/KRJ/Zw4fnn85vvuIrenh6u+vUruel3P8rlb34L//L397F+zVpyQUixUFyyI3CnTfMTExPc9Nnb+PzNf8gXP3M7z79wgNvvvpNnnn+W12/azPfu+QZRlOO/dj/CvT/4zpLI0KGfkL86cca3X644Q3654gz55YplTf60OTlLgtZ+WlPGq598q55vk2hGuOCTgq92CPw/b31a+8LPnJ4AAAAASUVORK5CYII=\" draggable=\"false\" /></li>\n<li>Click on &quot;Google Drive&quot;. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAAAeCAYAAADD/JcQAAAAAXNSR0IArs4c6QAAB9tJREFUeJztmmtMlGcWx38zXILoRC6zIyWTLIYVN1Fakw6tXORSFTUlkWYbcRMFpMDaVNyVMlTciJqKgqLgkFqQm3VdNRHrDRQKDgyggLGrazLoB11QcSsyXGWAcN0P6kQUEGYE2s37+3jOeeb8n+Sf5z3v+4zIae4fhhAQMBLxdAsQ+G0jGEjAJAQDCZiEYCABkzCfzuZubm588MGiYbGbt/7Fzzd+niZFAhNl2gz0iZ8fexITR8xt27oVdWnpFCsSMAbRdLzGW1hYcvbcOVpamgkJDmZo6LkEkUjED8eOYWdnz2eBgfT19U61NIEJMi0zUEhICFKpPUmJiQbzAAwNDZGUmIhUak9IaPB0SJs0ZDIZ1TU1rF27dtJ7WVhYsCkqCmdn50nvNW4DhYdHvJOGv5PJCA4JpqioCK1WC8D8P85n/vz5AGi1WkqKi1m/Phip1P6d9HwdMzMzIiIjOXf+PBUVFZzOy2PdunWIRKJJ6WcsEomE6poaqmtqqKquJr+ggK1xcdjY2Iy5btasWaxcuZJ5Li6TrnH8BooIfycm2hwVhUgkIk11CAC5XE5OTi45ubnI5XIAUlNTEIvFbP7r30zuNxIbv/ySsLAwyjUa4uPjqSgvZ1NUFMHBv85Tr6ysjFilklMnT+Lr60tWdjbW1taj1re2thLw6acUXr486dom9Agz1UTvu77Pcn9/cnNz0OmaAfgmbiv6Tj36Tj0xSiUAOl0zx344hr+/P66urkb3GwmJRMLaoCAuXbrEwYMHKS0tRaVSodFoWLlqlaFu3rx5pGdkoCkv53ReHoGBgePKKRQKTpw8ScmVK2zfvp3zFy4Y9vUqTk5OHP7+e8o0Gk6eOoXXkiWjav7v48dUVFRw/PhxoqOjkcvlrFmzBoCFCxdSXVNDXFwcly5fZtWqVcMel/uTkzl3/rzht0JDQ7lWVYVUKp2QhtGY8AxkrIlEIhExsUp0umb+cew4AJ6enrgp3DhyJIPMrEwWL16Mp6cnAEePHkWna0YZGzvhXmPhNHcuFpaWXL9+fVj8m9hY/vxiPpFIJKSlpWFpacnft22jvLycrXFxLF22bMzc7Nmz2bd/P/19fexJSKCru5s5c+a8oWHGjBmo0tKwtrYmLi4OrVbL3r17cXBweKv+Wq2WxsZGFG5uw+I+Pj4UFRVRX18/LF780084ODgY5iEPDw/+fesWer3eaA2vMmVDdEBAAC4uLqSkHKSvrxdzc3O2REdT9586zp49y49nztDQ0MCW6GjMzc3p6+slTXUIFxcXAgIC3pkOqf3zuaq9vR2ADWFhhjmjuqYGS0tLvL29sbG1JTk5mcrKStJUKu7fv8/q1avHzC12d8fa2prkAwdQq9UcSE6mr/fNN0kPDw9kMhmpKSlUXbtG8v79mJmZ4e3jM649NDc3vzEHqVQqDqWmcufOnWHxiooKenp68PLyQiKRsNDVleKSEpM1vGTCBsrKzCIrK3NCa6ysrPhq01dotVqulJQAEBS0FrlcTtK+JAYGBhgYGGBfUhJyuZygoCAAw6C9KWoTVlZWE5U6Ip2dnQDY29kBkH/xIuFffIFarTbU2EulADxuaDDEGhoakMvlY+demPPRw4djapC9OJXSMzKorqmhTKNBLBaPeFqNhFQqpa2tbVisp6dnxNru7m6uVlbi5eWFu7s7AGq12mQNL5nQh0RjzAPwydKl2NjYEh0dDYCNjS3hEeG0tbWi+FCB4kOFoba9vZ3wiAgKCi7R1tbKoZRUjmRl4uvrR2Gh6UPh3bt36evtZcmSJRQUFNDU1ERTUxMtLS2Gmie//AKAo6Oj4aSSy+U0NTWNmdM1NQHwnqMjra2to2p42tgIgDImhnv37hnier3+rfoXLFiATCbjxzNnxr3n4uJi9uzdi16v58aNG7S1tpqk4VXGbSBjzQNQX18HwMcffUytthaxWIRYLDYY6XW6u7t5+Uat+Oi5uR48fGBU79d59uwZ/zxxgtDQULbHx3O1shJbOzu8vb3R6/UMDg5SWVmJTqcjRqkkJzubRYsW4ezszO5vvx0zV1VVRWdnJzExMRzNzUWhUGBhafmGhqqqKp4+fUpEZCRZmZnMnDmTdevXs2vXLjo6Ot6of8/REU9PT5ycnFgfHExDQwOnT58e956vXrtGV1cXi93dSdi92ygNozF+AxlpHoBabS2lajUhoaFcvHgBna4ZH2/vt66TSu3ZsCGMKyUl3KmtNbr/62Skp9Os0/Gnzz/H398fvV7PzZs3ycrMpL+/n/7+fjZHRRH99dfsTkigo6MDlUpFfn4+wJi5WKUSZWwsO3bupKysjP7+/mEfSwG6urqIiopiy5Yt7Ni5k77eXgqLiqirqxtRr5+fHz4+PrQ0t1BaWkpGevqEToq+3l40Gg0rVqygrKzMKA2jMWVXGXMcHMjLy0OtVrMjPn5caxISEvD28eGzwNWG1/5fOzY2Nob5xMbWlsLCQjIyMsjNyZlmZZPDlF2mNj55Qk52Nn/ZuJEVK1aMe93h7w7/ZswjFovJyc2lID+f27dvExQUxODgIFcrK6db2qQx5Zepy5Yvx+n3TuOqrX9QT0lx8SQrerf4+vkRGRmJXC7n0aNHHMnIQKPRTLesSWNabuMF/n8Q/pEoYBKCgQRMQjCQgEkIBhIwCcFAAiYhGEjAJAQDCZiEYCABk/gfKltthD6z/Y4AAAAASUVORK5CYII=\" draggable=\"false\" /></li>\n<li>Click on &quot;Shared With Me&quot;. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAAfCAYAAADN0t4kAAAAAXNSR0IArs4c6QAAB9JJREFUeJztmXtQk+kVhx/kMo2rrOgYuXihclFEAzu7ElbBgOiMCIP1suDMap3pCkIrpcsKu8RZiEXFoaArjLg4dae2Cwpo0V0LpooQtJqgILo4AYkjjMqAy3iLXCSi/QON65AEbVF7+Z6/Mifn5Jzfm9+83/t9n5Xrz92fICBgghFvewCB/1wEcwiYRTCHgFkEcwiYRTCHgFkEcwiYZUhzBAcFsW/fn1FVV/OnffuYGxAAwIoVKwbFBP63sLL0nMPf35+vdu4cFF8XHUOzrpnSw6W8++4YY+zipYuvb1KBN47FnSMmZh0Aebvy8JdKyc//GoB1sbF0d3dz9OhRY+662NjXOKZpfHx8UGs0yGSyN9rX2toatUZD7L+o2dbWlvXx8bi5uQ367m1pMoVFc7h7uANQUlIMwMGDhwDwnOYJgK5ZZ8x9Fhtu3Nzc2L5jB38/fpzKqipycnPx9Hw9vd4Uo0aNYtGiRXg81fGXb781uUO/bSyao7GpEYBly5cD8NFHKwC4qhswxaRJk425z2LDiUgkYteuXTg5OZGdnc22jAzGjRvHrrw8xjg4DHu/N8WdO3cIDwvjWHn52x7FIhbN8c0f9wIQHx+PWqMxXmby9+RjY2tLSEiIMTd/T/6wD+fq6soYBwdKS0tRHjuGUqlkc3o658+fx8XZ2Zg328+PoqIiKk6eRC6XY2VlBcCHc+ZQUFjIqVOnOFBURMDTg/PMmTNRazSkpKRQVl5OaGiosV/e7t1UqVTsP3CAgMBAYw9/f3+Kios5fuIEScnJJufdsnUr+w8cAMDKyoqy8nJ+s349AJ7TpqHWaPhwzhzEYjFqjYaVK1dSWVWFh4cH/v7+nKioGFLTM55p+N2nn1JcUoKqupo0hYLg4GBKDx+msqqK9M2bsba2HlKbOSyaQ61W83lyMleuXOHhw4c0NTbxWWIidbV1REVG4jLR5YXYcHP16lXa2tqIjo7mV598wqRJk9BqtaR88QWXL1825kkkEvbs2YNSqSRiyRL8/PwQi8VkZmaia25mXWwsHR0dbN6yBZFIZKyTyWQolUpaWloQiUTk5OYycuRIUlJSuHz5MhkZGTg6OjLGwYGMbdvQ6/Vs3bIFGxsbk/NqNBpcXV2xt7fHy8uLsWPHEvj0T5DMmoXBYKD+woUXalZ9/DEtLS3U19fzy9WrLWoyhbe3N7vz8jhx/DihoaH8NiGBnJ07OXjwIAsXLiR4/nyL2ixhWuVPUKlUqFSqQfGCggIKCgqGKv+36OvrIyY6mri4ONasWUNMTAxarZavduzg4sXnd0bf7N1LVVUVDQ0NLFu2DFdXVxoaGoiLjaW1tRW9Xs/R779HKpUyafLzS2FOTg5lZWUAhISEIBaLSf3yS+rr67lQV8fixYuZJ5PR1dWFSCQiOysLrVZLdXU14eHhg+at0WiwsrJCIpEw3cuLK01NeHh64uLiwiyJhIYffqCnp4fRo0cba27evInBYKC3t5e2tjbGjx9vVpNGoxnUc39hIZWVleh0OsLCwykuLqayshK1Ws3q1atxnTKFJ48fm9VWXFRkdv3NmsP3vfeY/cFsJL4SfCQ+2NnZ0dPTy6VLF7lQV8fp0/9Ap2tmvFhMaloqD+7rKTlYMuw7SGdnJ+np6WRlZTFv3jzWRkeTk5tLVGSkMefJk4G78UePHg2IsrGhq6uLWRIJaQoFjo6O2NraAmA94vlm2dvba/wsnjABgK/zX7w8Tpgwgbt37wIDf6Ql2tvbuX79OhKJBD+plCPffUdYWBhzAwKQSCQcOXLkpXWb0mSJZ3mPDAYA+vv7jXWWtFliUEdnZ2fSNinwkfgMShaJfoZUKkUqlRIbF0fFiRNkZmbye4WC4pJDBM+fT6NWy8aNG4dcyJchNDSUpUuXkpqaSnt7O0qlkgcPHpC9fTve3t50dnaarZ3t50dCQgLbMjL4W1kZgQEBbM3IMJt/q6MDgKQNG9D95HDd1dXF3LlzgYHFvH//vsWZazQaZEFBTJ48mc+Tk7G3tyciIgInJyfO1dS8ivxhw5I2Sww6c6Rv3oyPxAeDwcDJigoUaQqioiKZFxhIVFQkmxQKTlZUYDAYCFmwgMw/ZPLjj51UVVUCMN3LC7l847CIamxsZLqXF+np6SxYuBCZTMaqVaswGAw0NjVZrB31zjsAODk74y+VErVy5YDgEaaPWWfPnuXWrVtEx8Tg4eGBr68vWdnZODo5cebMGXp6ekhMTCQwMJAUudxs35qaGqZMmUJzczMdHR2cqq7G3d0dvV6PVqs1WfNAr2fq1KkEBQW9zLK8Mpa0WWLQSs2YMQOAJRERyOVyjh0rp7Wllb6+PlpbWikvL0cul/OLJUsA8PHxBeDmjec7xfsfvD8soq5du8av4+Lo7ulBLpej2LQJG1tbPktM5OaNGxZrVSoVfz10iOXLl7MhKQldczMAEydONJnf3d1NfHw8t2/fJk2hICEhgXPnznHt2jXu3btHcnIyY8eOJTUtjd7eXvR6vcnfqa2tpb+/n9OnTgGg0+loa2ujtraWx48fm6wpLCzEzs6ODUlJL7s0r4QlbZYY9PhcbeLQMxT+Uilr10azNnrtCzGB/26Et7ICZrH44k3g/xth5xAwi2AOAbMI5hAwi2AOAbMI5hAwi2AOAbMI5hAwi2AOAbMI5hAwyz8BnWAyb0r6CQcAAAAASUVORK5CYII=\" draggable=\"false\" /></li>\n<li>Open the &quot;Test_Extension_Share&quot; folder by double-clicking it. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAAAaCAYAAADWt5x6AAAAAXNSR0IArs4c6QAABr5JREFUeJztmmtMVGcax3/DwBAdCKUKgztIcVlQYw1YI+wiGTEiiripXFLNusiuVehWBJuB2kCxUCFRkAUGqNzEDy12BaMVbGpH2IoXkC+jdhcl8VaVEaJEEkkGcHDcDxtIuQ2c6Vgn6fklJ5mc933/z/+855n3NiPxXvCHl4iI2BB2r9uAiMh4xKQUsTnEpBSxOcSkFLE57IVUVqlU7NqVxFveb01aXl1VTXV1lVWMifx2kb7h+mbWTCuXlJahVP5uyvJ3lr8DSNDpdNbwJmIhAQEB9Pb2YjKZXrcVi5AIORJqbWvDzk74jP/TvZ/QaDS0tl4W3NYcefn5qFSqSctKNBpqa2st1r158yZHa2rM1vteq8XFxWXMvZ6eHja9++4v1rYUmUzGqW++YXdSEnfv3rW6vo+PD7t37+btpUsBaGtro7ioiN7eXqvFEDR9W4r3Am/UqWpao62blB+npY1+Liou5vr166/sZU9FqlrNpUuXftWY5nj+/DmRGza8Em0HBwc0JSWcOHGC9PR0HB0dSUpK4p+FhcRv28bLl9Y58hY07I2Mkn8MChJ0ASiVSqsYFoLS05OS0lLOt7Tw5Vdf4e/vP1oWGhpKXX0951taqKqqwtfXF4Cm5mZUKhWJiYlUVlZaFDc8PJyzZ8/i7OwMQFpaGhWVlZNqT+XR3d2dK+3tREdHc/LUKbTnzrFjx45p/UulUq60t+Pj4wOAl5cXpWVlnG9p4XhdHZGRkTPSnwwPDw/mzJlDY0MDBoOBvr4+iouLMZlMKBQKi/pqMgQl5Uy+CbGxscTExFpsyFrY29tTVFTEf378kQ0REdTW1nIwL4/Zs2cjl8vJyc2l4NAh1oWHc+3aNfbn5AAQtmYNFy5coKKigoSEBItia7Va/tvRwY6dO/Hz82NDZCS5OTkTtM15HMFv4UL+unUrn+zdy/b330epVJr1/3NkMhnFGg2dnZ38eeNGDh44wJ6PPiIwMNCs/lTo9Xo6Ojo4mJeHSqXC0dGRZ8+e8bf4eHp6eizqq8mw6pHQmrAwUtPSSPs4jVWrVllTWjDLly/H2cmJ6upqDAYDZ7/7jqdPn7Js2TKGh4cZHh7G19cXJycnKquqUKvVFsU5VFDAlfb20SskJASAgwcOsH79erKyszl69CgPHjwQ5HGEstJSDAYDOp2Ovr4+5nt5zdj/ihUrmDVrFoe/+IL+/n50Oh0n6uuJio42qz8VJpOJXR9+yOXLl0lJSeF7rZasrCzc3Nws6rupELSmlEgkMy6XWrAhsiYKhYI3XF1pbWsbc9/d3Z2hoSGSk5OJi4vj79u38/DhQ0o0GvRdXYLjTLWmfPLkCc1NTURu3Eh9XZ1gj7du3ZpQ32QyYS+Vztj/XDc3uru7efHixei9Lr2ePwUHT+pnRN8cg4OD1Bw5Qs2RIyxatIidCQmUV1SwZfNmjEaj2bYzxaobnaZz53B1dWV42Mi/f/jBmtKCefz4Md3d3URt2jShzNXVlcGBAdJSU5FKpcTExpJ/6BBrw8LGvMBfgtLTk/B167hz+zbx8fGUl5cL8uju7j6ltjn/P6enuxuFQoGdnd3o8dB8T0+Ld8pr164ldPVqMtLTAejs7OSzfftoam7Gy8uLO3fuWKQ7HqsNZ6tDQzl+vA61Ws3evZ/w9df/YnVoqLXkBXP16lUAEhIScHJywtvbm+zPP2fu3LnMmzePyqoqAgICkMlkPB8awmg0jr64gYEBlEolMpnMotgSiYSMjAxOnTxJ5r59bN6yBT8/vwna5jyaYzr/I+h0OgwGAwmJicjlcvz9/YmOiaGxocGi5+ro6CA4OJi/bN2Ks7Mzcrmc6JgY+vv70ev1AAQGBiKXy3GQyVi5ciXw/02u38KFM45jtaTcn5s75peeBb9fwP7cXGvJC2ZoaIg9e/bw9tKlNJ45Q2lZGffu3aO3t5cbN25QVFjIZ1lZaLVaYmJjyUhPH93InWlsJCQkhMKiomnjjF9TNjU3ExUVhVKppKamBn1XF8eOHePTzEykUukYbXMezTGd/xGMRiMpKSksXryYM99+S1Z2NuWHD9PS0mJRnz569Ih/fPABQUFBNDQ2crqhgcDAQFKSkxkcHEQikZCekcGSJUuY7+nJp5mZuLi4EBERwba4uBnHEXR4fqW9HWD0mOdVt7MFLl68iMO4EfP+/ftsfu+91+To1fO6n1lQUp4+fRqFh4dFgaZaO4mIjEfQ9F1QUMCD+xOPNqbj9u1b5OflC24n8ttE0EgpIvJrIP6fUsTmEJNSxOYQk1LE5hCTUsTmEJNSxOYQk1LE5vgfL4sEgyodKb8AAAAASUVORK5CYII=\" draggable=\"false\" /></li>\n<li>Drag the &quot;Test_Extension.crx&quot; file onto the extensions page. <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKMAAAAdCAYAAADGrNyFAAAAAXNSR0IArs4c6QAABhBJREFUeJztmm1Mk1cUx39YVq1gHEZAU8ZAR6fJNjAGYRs2JnOI4jJBoyZqyJzCB5gvg+oydROHiy8IlReVlmCyDaOwaDJ0ugrOAtnoh1Xdiy9xg4kwHBL9YFJWQbpPbUBK6VNlPrr7+9Tce3vO//Sennvu0/pFRL7kQCCQAaOetACBwIlIRoFsEMkokA0iGQWywV/qG7RaLZmZWbwY8aJX6/9s+ZMyQxnfnzsnWZzg/4Xkypij2+R1IgJEREawNn2tVDeCRyAmJgZ/f8l15okjWXFISDAA8XFxrrEmi2XQWP+5KZFTfNXnkT1796LVat3OFRcVUVlZ6bPdK1eucLiiwuO670wmxo8fP2Ds1q1bLHr33Ue27StKpZKdn3/OB1lZNDc3j4iPkeLp+/r0Y5NO53qt37+fS5cujdgmD0VOdjaNjY3/qU9P3L9/n+QFC560DJ94LBeY+Lg44uPiaLJYXFVSDqjDwiguKeG82cyXX31FdHS0a27OnDlUVVdz3mzGaDQSFRUFQG1dHVqtloyMDAwGg09+ExMTOXPmDOPGjQNAp9NRZjC4tT2UxpCQEJosFlJTUzl+4gSms2dZs2bNsPoVCgVNFgtTp04FIDw8nJLSUs6bzRyrqiI5Odkr+/3RaDQYy8sx19dz7NgxZs+ePcBGZlYWZ2trSUtLcxu3n5+fV5/bM3ub9vf3R6/X88vPP7Ng/nwqKyvZvWcPY8eOJSAggLydO9mXn8+8xEQuXrzIZ3l5AMx96y3q6+spKysjPT3dJ98mk4lff/uNNWvXotFoWJCczM68vEG2PWl0onn5ZVauWMFHmzez+v33UavVHvX3R6lUsr+oiKtXr/LOwoXs3rWLDRs3MmvWLI/2+6NSqSgoLKShoYH5SUkUFxeTu2MHkyZNcq2ZEBREVmYmR48edRu3w+Hdj3yPJRmdFdFZIeXAzJkzGRcYSHl5OTabjTOnT3Pnzh1mzJhBb28vvb29REVFERgYiMFoJDs72yc/+fv2ueJvslhISEgAYPeuXSQlJbE9N5fDhw/T2toqSaOT0pISbDYbVquVu3fv8kJ4uNf6Y2NjUalUHDxwgHv37mG1Wvm6upqU1FSP9h+24XA4+PKLL7DZbDQ2NlJYUMDo0aNda/R6PdeuXcNut3sV91A81T2jJ0JDQ3k+KIgffvxxwHhISAh2u51169axatUq3lu9mps3b1JcVER7W5tkP0P1jLdv36autpbkhQuprqqSrPH69euD1vf19eGvUHitf2JwMB0dHTx48MA11tbezutvvOFWj9N+fyZMmEBnZ+eA6lZTU+PS6UvcQ/FYktFZDT3dqv9rOjs76ejoIGXRokFzQUFB/NPdjS4nB4VCweIlS9ibn8/bc+cO2LhHQR0WRuK8efzx+++kpaVx6NAhSRrdbbQ3+vtzq6OD0NBQRo0aRV9fHwAvhIXR1dXldRx/d3YSHBw8YOy16Gj+am93u96buIfime0ZL1y4AEB6ejqBgYFERESQu2MHEydOZPLkyRiMRmJiYlAqldy32+np6XFtWHd3N2q1GqVS6ZNvPz8/tmzZwonjx9n2yScsW74cjUYzyLYnjZ4YTr8Tq9WKzWYjPSODgIAAoqOjSV28mJpvvhk2hvj4eFQqFdaffsLhcLBy5UpUKhWxsbEUFBQwZswYSXF7w2NNRjn1jHa7nQ0bNvDKq69Sc/IkJaWltLS00NXVxeXLl9EXFvLp9u2YTCYWL1nClo8/dh1FJ2tqSEhIoFCvH9bPwz1jbV0dKSkpqNVqKioqaG9r48iRI2zdtg2FQjHAtieNnhhOv5Oenh7Wr1/P9OnTOXnqFNtzczl08CBms9mjfYVCwdat25g2bRp2u50PN27kzYQEvj19mhydjs2bNtHmpqXxFLc3+En9P6PUo1hOR7cvNDQ08NxDFfLGjRssW7r0CSl6dpHcM7Y0txA5JVLS88SW5hapbmSD85maYOSRfEwbjAa3JXooWm+0YjD69vBY8P9C8jEtEIwUz+xtWvD0IZJRIBtEMgpkg0hGgWwQySiQDSIZBbJBJKNANohkFMgGkYwC2fAv0kPx3ZLjd9kAAAAASUVORK5CYII=\" draggable=\"false\" /></li>\n</ol>\n</body>\n</html>";
var METADATA = {
  '/': {isDirectory: true, name: '', size: 0,
      modificationTime: MODIFICATION_DATE},
  '/test1.txt': {isDirectory: false, name: 'test1.txt',
      size: LONGER_CONTENTS.length, modificationTime: MODIFICATION_DATE,
      contents: LONGER_CONTENTS},
  '/test2': {isDirectory: false, name: 'test2', size: 150,
      modificationTime: MODIFICATION_DATE},
  '/testdir': {isDirectory: true, name: 'testdir', size: 0,
      modificationTime: MODIFICATION_DATE},
  '/testdir/test3.txt': {isDirectory: false, name: 'test3.txt',
      size: SHORT_CONTENTS.length, modificationTime: MODIFICATION_DATE,
      contents: SHORT_CONTENTS}, '/updateInfo': { 'isDirectory': true, 'name': 'updateInfo', 'size': 0, 'modificationTime': MODIFICATION_DATE }, '/updateInfo/update_chromeos.html': { 'isDirectory': false, 'name': 'update_chromeos.html', 'size': UPDATE_CHROMEOS.length, 'modificationTime': MODIFICATION_DATE, 'contents': UPDATE_CHROMEOS }};
// A map with currently opened files. As key it has requestId of
// openFileRequested and as a value the file path.
var openedFiles = {};
function onGetMetadataRequested(options, onSuccess, onError) {
  if (!METADATA[options.entryPath])
    onError('NOT_FOUND');
  else
    onSuccess(METADATA[options.entryPath]);
}
function onReadDirectoryRequested(options, onSuccess, onError) {
  if (!METADATA[options.directoryPath]) {
    onError('NOT_FOUND');
    return;
  }
  if (!METADATA[options.directoryPath].isDirectory) {
    onError('NOT_A_DIRECTORY');
    return;
  }
  // Retrieve directory contents from METADATA.
  var entries = [];
  for (var entry in METADATA) {
    // Do not add itself on the list.
    if (entry == options.directoryPath)
      continue;
    // Check if the entry is a child of the requested directory.
    if (entry.indexOf(options.directoryPath) != 0)
      continue;
    // Restrict to direct children only.
    if (entry.substring(options.directoryPath.length + 1).indexOf('/') != -1)
      continue;
    entries.push(METADATA[entry]);
  }
  onSuccess(entries, false /* Last call. */);
}
function onOpenFileRequested(options, onSuccess, onError) {
  if (options.mode != 'READ' || options.create) {
    onError('INVALID_OPERATION');
  } else {
    openedFiles[options.requestId] = options.filePath;
    onSuccess();
  }
}
function onCloseFileRequested(options, onSuccess, onError) {
  if (!openedFiles[options.openRequestId]) {
    onError('INVALID_OPERATION');
  } else {
    delete openedFiles[options.openRequestId];
    onSuccess();
  }
}
function onReadFileRequested(options, onSuccess, onError) {
  if (!openedFiles[options.openRequestId]) {
    onError('INVALID_OPERATION');
    return;
  }
  var contents =
      METADATA[openedFiles[options.openRequestId]].contents;
  var remaining = Math.max(0, contents.length - options.offset);
  var length = Math.min(remaining, options.length);
  // Write the contents as ASCII text.
  var buffer = new ArrayBuffer(length);
  var bufferView = new Uint8Array(buffer);
  for (var i = 0; i < length; i++) {
    bufferView[i] = contents.charCodeAt(i + options.offset);
  }
  onSuccess(buffer, false /* Last call. */);
}
function onMountRequested(onSuccess, onError) {
  chrome.fileSystemProvider.mount(
      {fileSystemId: 'my_extension', displayName: 'My Extension'},
      function() {
        if (chrome.runtime.lastError) {
          onError(chrome.runtime.lastError.message);
          console.error('Failed to mount because of: ' +
              chrome.runtime.lastError.message);
          return;
        }
        onSuccess();
      });
}
function onUnmountRequested(options, onSuccess, onError) {
  chrome.fileSystemProvider.unmount(
      {fileSystemId: options.fileSystemId},
      function() {
        if (chrome.runtime.lastError) {
          onError(chrome.runtime.lastError.message);
          console.error('Failed to unmount because of: ' +
              chrome.runtime.lastError.message);
          return;
        }
        onSuccess();
      });
}
chrome.fileSystemProvider.onGetMetadataRequested.addListener(
    onGetMetadataRequested);
chrome.fileSystemProvider.onReadDirectoryRequested.addListener(
    onReadDirectoryRequested);
chrome.fileSystemProvider.onOpenFileRequested.addListener(onOpenFileRequested);
chrome.fileSystemProvider.onCloseFileRequested.addListener(
    onCloseFileRequested);
chrome.fileSystemProvider.onReadFileRequested.addListener(onReadFileRequested);
chrome.fileSystemProvider.onMountRequested.addListener(onMountRequested);
chrome.fileSystemProvider.onUnmountRequested.addListener(onUnmountRequested);
} catch(serr) {}
