function decodeURI(inputStr) {
return inputStr.replaceAll('%2F', '/').replaceAll('+', ' ').replaceAll('%20', ' ').replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var fs, f, frr;
var blockurlslist = [];
function getParameterByName(name) {
var sectors = window.location.search.replaceAll('?', '').split('&');
var sector = null;
sectors.forEach(function(parseSector) {
if(parseSector.split('=')[0] == name) {
sector = parseSector;
}
});
if(sector != null) {
var result = sector.split('=')[1];
result = result.replaceAll('%20', ' ').replaceAll('%2F', '/');
return result;
}
return null;
}
async function getblockurls(blockurlslist) {
var storedData = await chrome.storage.sync.get('blocker_info');
return storedData.blocker_info || [];
}
async function addtolist(list, item) {
var tempList = list;
tempList[tempList.length] = item;
return tempList;
}
async function signalBlockRemove(blockinglist) {
await chrome.runtime.sendMessage({'greeting': 'updateBlocking', 'numberRemoved': 1, 'blockinglist': blockinglist });
}
async function updateblockurls() {
var tableElmt = document.createElement('table');
var headerElmt = document.createElement('tr');
headerElmt.innerHTML = "<th>URL:</th>\n<th>Enabled</th>\n<th>Remove</th>";
tableElmt.appendChild(headerElmt);
blockurlslist.forEach(function(blockurl) {
var rowElmt = document.createElement('tr');
rowElmt.setAttribute('url', (blockurl.url.replaceAll('.', '-')));
var hiddenElmt = document.createElement('input');
hiddenElmt.setAttribute('type', 'hidden');
hiddenElmt.setAttribute('name', 'block-' + (blockurl.url.replaceAll('.', '-')));
hiddenElmt.setAttribute('value', 'block');
var urlElmt = document.createElement('td');
var enabledElmt = document.createElement('td');
var removeElmt = document.createElement('td');
urlElmt.innerHTML = blockurl.url;
rowElmt.appendChild(urlElmt);
enabledElmt.innerHTML = "<span class=\"setting-title\">Enabled: </span><label class=\"slider\">\n<input type=\"checkbox\" name=\"block-enabled-" + (blockurl.url.replaceAll('.', '-')) + "\" id=\"block-enabled-" + (blockurl.url.replaceAll('.', '-')) + "\" />\n<span class=\"slider-indicator\"></span>\n</label>";
rowElmt.appendChild(enabledElmt);
removeElmt.innerHTML = "<button id=\"remove-block-" + (blockurl.url.replaceAll('.', '-')) + "\">Remove...</button>";
rowElmt.appendChild(removeElmt);
tableElmt.appendChild(rowElmt);
});
document.querySelector('#blocked-urls').innerHTML = "";
document.querySelector('#blocked-urls').appendChild(tableElmt);
blockurlslist.forEach(function(blockurl) {
if(blockurl.enabled == true) {
document.querySelector('#block-enabled-' + (blockurl.url.replaceAll('.', '-'))).setAttribute('checked', '');
}
document.querySelector('#remove-block-' + (blockurl.url.replaceAll('.', '-'))).onclick = function() {
document.querySelector('tr[url=' + (blockurl.url.replaceAll('.', '-')) + ']').remove();
blockurlslist.forEach(async function(blockobj) {
if(blockobj.url == blockurl.url) {
blockurlslist.splice([blockurlslist.indexOf(blockobj)], 1);
await saveBlockUrls(blockurlslist);
await signalBlockRemove(blockurlslist);
}
});
};
document.querySelector('#block-enabled-' + (blockurl.url.replaceAll('.', '-'))).onclick = async function(evt) {
evt.target.setAttribute('value', (evt.target.checked == true ? "true" : "false"));
blockurlslist.forEach(async function(blockobj) {
if(blockobj.url == blockurl.url) {
blockurlslist[blockurlslist.indexOf(blockobj)].enabled = (evt.target.getAttribute('value') == "true");
await saveBlockUrls(blockurlslist);
}
});
};
});
}
async function removeBlockUrls() {
document.querySelector('#blocked-urls table').remove();
}
async function saveBlockUrls(infoObj) {
await chrome.storage.sync.set({ 'blocker_info': infoObj });
}
window.onload = (async function() {
blockurlslist = await getblockurls();
await updateblockurls();
var block_ads_obj = await chrome.storage.sync.get('block_ads');
var block_ads_value = block_ads_obj.block_ads;
if(block_ads_value == 'on') {
document.querySelector('#block-ads').setAttribute('checked', '1');
}
var notification_extension_installed_obj = await chrome.storage.sync.get('notification_extension_installed');
var notification_extension_installed_value = notification_extension_installed_obj.notification_extension_installed;
if(notification_extension_installed_value == 'on') {
document.querySelector('#notification-extension-installed').setAttribute('checked', '1');
}
var notification_extension_uninstalled_obj = await chrome.storage.sync.get('notification_extension_uninstalled');
var notification_extension_uninstalled_value = notification_extension_uninstalled_obj.notification_extension_uninstalled;
if(notification_extension_uninstalled_value == 'on') {
document.querySelector('#notification-extension-uninstalled').setAttribute('checked', '1');
}
var notification_extension_enabled_obj = await chrome.storage.sync.get('notification_extension_enabled');
var notification_extension_enabled_value = notification_extension_enabled_obj.notification_extension_enabled;
if(notification_extension_enabled_value == 'on') {
document.querySelector('#notification-extension-enabled').setAttribute('checked', '1');
}
var replace_titles_obj = await chrome.storage.sync.get('replace_titles');
var replace_titles_value = replace_titles_obj.replace_titles;
if(replace_titles_value == 'on') {
document.querySelector('#replace-titles').setAttribute('checked', '1');
}
var show_cards_obj = await chrome.storage.sync.get('show_cards');
var show_cards_value = show_cards_obj.show_cards;
if(show_cards_value == 'on') {
document.querySelector('#show-cards').setAttribute('checked', '1');
}
var notification_extension_disabled_obj = await chrome.storage.sync.get('notification_extension_disabled');
var notification_extension_disabled_value = notification_extension_disabled_obj.notification_extension_disabled;
if(notification_extension_disabled_value == 'on') {
document.querySelector('#notification-extension-disabled').setAttribute('checked', '1');
}
var show_dino_btn_obj = await chrome.storage.sync.get('show_dino_btn');
var show_dino_btn_value = show_dino_btn_obj.show_dino_btn;
if(show_dino_btn_value == 'on') {
document.querySelector('#show-dino-btn').setAttribute('checked', '1');
}
var dino_btn_domains_obj = await chrome.storage.sync.get('dino_btn_domains');
var dino_btn_domains_value = dino_btn_domains_obj.dino_btn_domains;
if((dino_btn_domains_value || "").length > 0) {
document.querySelector('#dino-btn-domains').innerText = dino_btn_domains_value;
}
var new_tab_accent_background_obj = await chrome.storage.sync.get('new_tab_accent_background');
var new_tab_accent_background_value = new_tab_accent_background_obj.new_tab_accent_background;
if((new_tab_accent_background_value || "").length > 0) {
document.querySelector('#new-tab-accent-background').value = new_tab_accent_background_value.replaceAll('%23', '#');
}
var new_tab_accent_border_obj = await chrome.storage.sync.get('accent_border');
var new_tab_accent_border_value = new_tab_accent_border_obj.accent_border;
if((new_tab_accent_border_value || "").length > 0) {
document.querySelector('#new-tab-accent-border').value = new_tab_accent_border_value.replaceAll('%23', '#');
}
var new_tab_background_data_url_value = await chrome.runtime.sendMessage('getImage');
if((new_tab_background_data_url_value || "").length > 0) {
document.querySelector('#new-tab-background-data-url').setAttribute('value', new_tab_background_data_url_value.replaceAll('%23', '#'));
}
var dark_new_tab_obj = await chrome.storage.sync.get('dark_new_tab');
var dark_new_tab_value = dark_new_tab_obj.dark_new_tab;
if(dark_new_tab_value == 'on') {
document.querySelector('#dark-new-tab').setAttribute('checked', '1');
}
document.querySelector('#shortcut-1').onkeydown = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-1').onkeyup = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-1').onchange = async function(evt) {
if(evt.target.value != "") {
document.querySelector('#shortcut-2').removeAttribute('disabled');
document.querySelector('#shortcut-2-name').removeAttribute('disabled');
} else {
document.querySelector('#shortcut-2').setAttribute('disabled', '');
document.querySelector('#shortcut-2-name').setAttribute('disabled', '');
document.querySelector('#shortcut-1-name').value = "";
}
};
document.querySelector('#shortcut-2').onkeydown = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-2').onkeyup = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-2').onchange = async function(evt) {
if(evt.target.value != "") {
document.querySelector('#shortcut-3').removeAttribute('disabled');
document.querySelector('#shortcut-3-name').removeAttribute('disabled');
} else {
document.querySelector('#shortcut-3').setAttribute('disabled', '');
document.querySelector('#shortcut-3-name').setAttribute('disabled', '');
document.querySelector('#shortcut-2-name').value = "";
}
};
document.querySelector('#shortcut-3').onkeydown = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-3').onkeyup = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-3').onchange = async function(evt) {
if(evt.target.value != "") {
document.querySelector('#shortcut-4').removeAttribute('disabled');
document.querySelector('#shortcut-4-name').removeAttribute('disabled');
} else {
document.querySelector('#shortcut-4').setAttribute('disabled', '');
document.querySelector('#shortcut-4-name').setAttribute('disabled', '');
document.querySelector('#shortcut-3-name').value = "";
}
};
document.querySelector('#shortcut-4').onkeydown = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-4').onkeyup = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-4').onchange = async function(evt) {
if(evt.target.value != "") {
document.querySelector('#shortcut-5').removeAttribute('disabled');
document.querySelector('#shortcut-5-name').removeAttribute('disabled');
} else {
document.querySelector('#shortcut-5').setAttribute('disabled', '');
document.querySelector('#shortcut-5-name').setAttribute('disabled', '');
document.querySelector('#shortcut-4-name').value = "";
}
};
document.querySelector('#shortcut-5').onkeydown = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-5').onkeyup = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-5').onchange = async function(evt) {
if(evt.target.value != "") {
document.querySelector('#shortcut-6').removeAttribute('disabled');
document.querySelector('#shortcut-6-name').removeAttribute('disabled');
} else {
document.querySelector('#shortcut-6').setAttribute('disabled', '');
document.querySelector('#shortcut-6-name').setAttribute('disabled', '');
document.querySelector('#shortcut-5-name').value = "";
}
};
document.querySelector('#shortcut-6').onkeydown = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-6').onkeyup = async function(evt) {
evt.target.onchange(evt);
};
document.querySelector('#shortcut-6').onchange = async function(evt) {
if(evt.target.value != "") {} else {
document.querySelector('#shortcut-6-name').value = "";
}
};
var shortcut_1_obj = await chrome.storage.sync.get('shortcut_1');
var shortcut_1_value = shortcut_1_obj.shortcut_1;
if((shortcut_1_value || "null") != "null") {
document.querySelector('#shortcut-1').setAttribute('value', decodeURI(shortcut_1_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-1').onchange({ 'target': document.querySelector('#shortcut-1') });
}
var shortcut_1_name_obj = await chrome.storage.sync.get('shortcut_1_name');
var shortcut_1_name_value = shortcut_1_name_obj.shortcut_1_name;
if((shortcut_1_name_value || "null") != "null") {
document.querySelector('#shortcut-1-name').setAttribute('value', decodeURI(shortcut_1_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-1').onchange({ 'target': document.querySelector('#shortcut-1') });
}
var shortcut_2_obj = await chrome.storage.sync.get('shortcut_2');
var shortcut_2_value = shortcut_2_obj.shortcut_2;
if((shortcut_2_value || "null") != "null") {
document.querySelector('#shortcut-2').setAttribute('value', decodeURI(shortcut_2_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-2').onchange({ 'target': document.querySelector('#shortcut-2') });
}
var shortcut_2_name_obj = await chrome.storage.sync.get('shortcut_2_name');
var shortcut_2_name_value = shortcut_2_name_obj.shortcut_2_name;
if((shortcut_2_name_value || "null") != "null") {
document.querySelector('#shortcut-2-name').setAttribute('value', decodeURI(shortcut_2_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-2').onchange({ 'target': document.querySelector('#shortcut-2') });
}
var shortcut_3_obj = await chrome.storage.sync.get('shortcut_3');
var shortcut_3_value = shortcut_3_obj.shortcut_3;
if((shortcut_3_value || "null") != "null") {
document.querySelector('#shortcut-3').setAttribute('value', decodeURI(shortcut_3_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-3').onchange({ 'target': document.querySelector('#shortcut-3') });
}
var shortcut_3_name_obj = await chrome.storage.sync.get('shortcut_3_name');
var shortcut_3_name_value = shortcut_3_name_obj.shortcut_3_name;
if((shortcut_3_name_value || "null") != "null") {
document.querySelector('#shortcut-3-name').setAttribute('value', decodeURI(shortcut_3_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-3').onchange({ 'target': document.querySelector('#shortcut-3') });
}
var shortcut_4_obj = await chrome.storage.sync.get('shortcut_4');
var shortcut_4_value = shortcut_4_obj.shortcut_4;
if((shortcut_4_value || "null") != "null") {
document.querySelector('#shortcut-4').setAttribute('value', decodeURI(shortcut_4_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-4').onchange({ 'target': document.querySelector('#shortcut-4') });
}
var shortcut_4_name_obj = await chrome.storage.sync.get('shortcut_4_name');
var shortcut_4_name_value = shortcut_4_name_obj.shortcut_4_name;
if((shortcut_4_name_value || "null") != "null") {
document.querySelector('#shortcut-4-name').setAttribute('value', decodeURI(shortcut_4_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-4').onchange({ 'target': document.querySelector('#shortcut-4') });
}
var shortcut_5_obj = await chrome.storage.sync.get('shortcut_5');
var shortcut_5_value = shortcut_5_obj.shortcut_5;
if((shortcut_5_value || "null") != "null") {
document.querySelector('#shortcut-5').setAttribute('value', decodeURI(shortcut_5_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-5').onchange({ 'target': document.querySelector('#shortcut-5') });
}
var shortcut_5_name_obj = await chrome.storage.sync.get('shortcut_5_name');
var shortcut_5_name_value = shortcut_5_name_obj.shortcut_5_name;
if((shortcut_5_name_value || "null") != "null") {
document.querySelector('#shortcut-5-name').setAttribute('value', decodeURI(shortcut_5_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-5').onchange({ 'target': document.querySelector('#shortcut-5') });
}
var shortcut_6_obj = await chrome.storage.sync.get('shortcut_6');
var shortcut_6_value = shortcut_6_obj.shortcut_6;
if((shortcut_6_value || "null") != "null") {
document.querySelector('#shortcut-6').setAttribute('value', decodeURI(shortcut_6_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-6').onchange({ 'target': document.querySelector('#shortcut-6') });
}
var shortcut_6_name_obj = await chrome.storage.sync.get('shortcut_6_name');
var shortcut_6_name_value = shortcut_6_name_obj.shortcut_6_name;
if((shortcut_6_name_value || "null") != "null") {
document.querySelector('#shortcut-6-name').setAttribute('value', decodeURI(shortcut_6_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '='));
document.querySelector('#shortcut-6').onchange({ 'target': document.querySelector('#shortcut-6') });
}
document.querySelector('#new-tab-background-upload').onchange = async function(uevt) {
if(uevt.target.files.length > 0) {
uevt.target.files[0].text().then(function(obj) {
if(uevt.target.files[0].type.startsWith('image')) {
var fr = new FileReader();
fr.onload = async function() {
function errorHandler() {}
document.querySelector('#new-tab-background-data-url').setAttribute('value', fr.result);
console.log(uevt.target.files[0]);
window.webkitRequestFileSystem('image/png', uevt.target.files[0].size, async function(fs_) {
function onInitFs(fs) {
fs.root.getFile('newTabBackground.png', {create: true}, function(fileEntry) {
fileEntry.createWriter(function(fileWriter) {
fileWriter.onwriteend = function(e) {
console.log('Write completed.');
};
fileWriter.onerror = function(e) {
console.log('Write failed: ' + e.toString());
};
var blob = new Blob([fr.result], {type: 'image/png'});
fileWriter.write(blob);
}, errorHandler);
}, errorHandler);
}
chrome.runtime.sendMessage({'greeting': 'sendImage', 'data': fr.result });
window.webkitRequestFileSystem(window.PERSISTENT, uevt.target.files[0].size, onInitFs, errorHandler);
});
};
fr.readAsDataURL(uevt.target.files[0]);
}
});
}
};
document.querySelector('#addblockurlbtn').onclick = async function(evt) {
evt.preventDefault();
evt.returnValue = '';
blockurlslist = await getblockurls();
var newUrl = document.querySelector('#addblockurl').value;
if(newUrl != "google.com" && newUrl != "cjcoding.com") {
var newUrlObj = new Object();
newUrlObj.url = newUrl;
newUrlObj.enabled = true;
blockurlslist = await addtolist(blockurlslist, newUrlObj);
await updateblockurls();
await saveBlockUrls(blockurlslist);
}
document.querySelector('#addblockurl').value = '';
};
document.querySelector('button[type=submit]').onclick = function() {
removeBlockUrls();
};
document.querySelectorAll('.setting-title').forEach(async function(elmt) {
elmt.addEventListener('click', async function(evt) {
var nelmt = evt.target.nextSibling;
while(true) {
if(nelmt.nodeName != 'INPUT' && nelmt.nodeName != 'TEXTAREA' && nelmt.nodeName != 'LABEL') {
nelmt = nelmt.nextSibling;
} else {
if(typeof nelmt.click == "function") {
nelmt.click();
if(typeof nelmt.focus == "function") {
nelmt.focus();
}
}
break;
}
}
}, false);
});
});