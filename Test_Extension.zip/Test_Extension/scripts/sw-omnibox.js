import './utils.js';
console.log('sw-omnibox.js');
chrome.runtime.onInstalled.addListener(({ reason }) => {
if (reason === 'install' || reason === 'update') {
console.log("Install Init.");
chrome.storage.local.set({
apiSuggestions: ['tabs', 'storage', 'scripting']
});
}
});
const URL_SEARCH_PREFIX = 'https://www.cjcoding.com/search_results.php?q=';
const URL_SEARCH_MID = '#gsc.tab=0&gsc.q=';
const URL_SEARCH_SUFFIX = '&gsc.page=1';
const NUMBER_OF_PREVIOUS_SEARCHES = 4;
chrome.omnibox.onInputChanged.addListener(async (input, suggest) => {
await chrome.omnibox.setDefaultSuggestion({
description: 'Search cjCoding'
});
const { apiSuggestions } = await chrome.storage.local.get('apiSuggestions');
const suggestions = apiSuggestions.map((api) => {
return { content: api, description: `Search cjCoding for ${api}` };
});
suggest(suggestions);
});
chrome.omnibox.onInputEntered.addListener((input) => {
chrome.tabs.create({ url: URL_SEARCH_PREFIX + input + URL_SEARCH_MID + input + URL_SEARCH_SUFFIX });
updateHistory(input);
});
async function updateHistory(input) {
const { apiSuggestions } = await chrome.storage.local.get('apiSuggestions');
apiSuggestions.unshift(input);
apiSuggestions.splice(NUMBER_OF_PREVIOUS_SEARCHES);
return chrome.storage.local.set({ apiSuggestions });
}
