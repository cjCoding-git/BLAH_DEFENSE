async function sayWithNoLimit(text) {
chrome.tts.speak(text, {
'onEvent': async function(event) {
console.log(event);
if(event.type == 'error') {
sayWithNoLimit(text.substring(event.charIndex, text.length));
}
},
'pitch': choosenPitch, 'rate': choosenSpeed, 'voiceName': choosenVoice.voiceName, 'volume': 1.0
});
}
var voices = null;
var choosenVoice = null;
var choosenVoiceIndex = 0;
var choosenSpeedMin = 0.1;
var choosenSpeedMax = 10.0
var choosenSpeed = 1.0;
var choosenPitchMin = 0.0;
var choosenPitchMax = 2.0;
var choosenPitch = 1.0;
var sliderStep = 0.1
window.onload = async function() {
window.onclick = async function() {
document.documentElement.requestFullscreen();
};
document.querySelector('#openSpeechPopup').onclick = async function(evt) {
document.querySelector('#speechPopup').setAttribute('style', 'display: block;');
};
document.querySelector('#closeSpeechPopup').onclick = async function(evt) {
document.querySelector('#speechPopup').setAttribute('style', 'display: none;');
};
voices = await chrome.tts.getVoices();
document.querySelector('#chooseVoice').onchange = async function(evt) {
choosenVoiceIndex = parseInt(evt.target.value);
choosenVoice = voices[choosenVoiceIndex];
};
document.querySelector('#chooseSpeed').onchange = async function(evt) {
choosenSpeed = parseFloat(evt.target.value);
document.querySelector('#speedValue').innerHTML = choosenSpeed;
};
document.querySelector('#chooseSpeed').onmousemove = async function(evt) {
document.querySelector('#speedValue').innerHTML = evt.target.value;
};
document.querySelector('#choosePitch').onchange = async function(evt) {
choosenPitch = parseFloat(evt.target.value);
document.querySelector('#pitchValue').innerHTML = choosenPitch;
};
document.querySelector('#choosePitch').onmousemove = async function(evt) {
document.querySelector('#pitchValue').innerHTML = evt.target.value;
};
document.querySelector('#speedValue').innerHTML = choosenSpeed;
document.querySelector('#pitchValue').innerHTML = choosenPitch;
document.querySelector('#chooseSpeed').setAttribute('min', choosenSpeedMin.toString());
document.querySelector('#chooseSpeed').setAttribute('max', choosenSpeedMax.toString());
document.querySelector('#chooseSpeed').setAttribute('step', sliderStep.toString());
document.querySelector('#choosePitch').setAttribute('min', choosenPitchMin.toString());
document.querySelector('#choosePitch').setAttribute('max', choosenPitchMax.toString());
document.querySelector('#choosePitch').setAttribute('step', sliderStep.toString());
choosenVoice = voices[0];
voices.forEach(async function(voice) {
var voiceIndex = voices.indexOf(voice);
var voiceElmt = document.createElement('option');
if(voiceIndex == 0) {
voiceElmt.setAttribute('default', '1');
}
voiceElmt.setAttribute('value', voiceIndex.toString());
voiceElmt.innerHTML = voice.voiceName;
document.querySelector('#chooseVoice').appendChild(voiceElmt);
});
document.querySelector('#stopbtn').onclick = async function() {
chrome.tts.stop();
};
function censor(text) {
var words = text.split(' ');
words.forEach(function(word) {
censorWords.forEach(function(censorWord) {
var skipWord = false;
whiteList.forEach(function(wword) {
if(word.toLowerCase() == wword && word.toLowerCase().substring(0, wword.length) == wword) {
skipWord = true;
}
});
if(word.toLowerCase().indexOf(censorWord.toLowerCase()) != -1 && !skipWord) {
var insults = ["I am not saying that you dirty-minded little freak!", "Hey! You kiss your mother with that mouth?!?", "BLEEP! YOU LITTLE DIRTY FREAK!", "juddensf you", "uioftartsshfgpiuuuu"];
var num = Math.floor(Math.random() * insults.length);
words[words.indexOf(word)] = insults[num];
}
});
});
return words.join(' ');
}
document.querySelector('#talkbtn').onclick = async function() {
chrome.tts.stop();
sayWithNoLimit(censor(document.querySelector('#talkbox').value));
};
document.querySelector('#rottenEggs').onclick = async function() {
chrome.runtime.sendMessage('rantAboutEggs');
};
var side = true;
var talkStrs = { 'Histh': 'thist, histh, is, this, crayfish, talking, about, random, stuff, that, is, annoying, and, makes, no, sense.', 'Insanity': 'this is a bunch of nonsense stuff that is very crazy and this computer is going insanelly crazy craay like a buch bunch of nosense crayfish in a tank that is tooo smaall and are going completely and utterly insanelly crazy crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish crayfish.', 'Nonsense': 'hello! this is a computer talking. i would like to talk about nonsense! now talking about nonsense. talking about nonsense what? what? what? what? what? what? what? what? what? what? vBlahBlahBlah vBlahBlahBlah vBlahBlahBlah vBlahBlahBlah vBlahBlahBlah vBlahBlahBlah vBlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah WHATWHATWHAT WHATWHATWHAT. WHATW WHATWHATWHAT. WHATWHATWHAT. WHATWHATWHAT. WHATWHATWHAT WHATW, YTGGFTs YGUKGTDRTYFUs GFYRFTFDRTFYUTFR. YGHUYGTFGHUYGTF RYUHNTFRIOYUFTRTSRWs AEWSDRTFYUIUYITRESWAS. ERFTGYTFREFYUHGTRDESTDY? Y-USE! FGHTFDRJHBKVFDSERDTFYGUs. HJGTFRTWs HATWHATWHs. ATWHATWHATWHATs. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. BlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. vBlahBlahBlah. hello! this is your computer talking. i would like to talk about nonsense! now talking about nonsense. talking about nonsense what? hello! this is your computer talking. i would like to talk about nonsense! now talking about nonsense. talking about nonsense what? what? GFGHJGFHJGFTHRGHJGTFGHJBTFRDT FGHBJGVFTHBJGVUFTDRYGH BJKGFVUYCGVYUTFGHVYUBHGVU FYCDGVUFYCGFVUCYGHJBTYGYUTGYU VHGVYUTFBHGVYUHNJIB GYUVFVGHBJFCGVHY DTRXFGHVYDTRFGHBJGVU DCYRHBKJGFVUYGFV DRYUYGIBUDCRTYGVUD CRTYFGDRYTGHDTRFGFCRD TCFYGVHBJFVDTXCYG VYCGVHBVF YCBHJGFVYHBJNB JCFYGBHJN BG VFHN <BKHGVJUFH BNVGF BNBVN<BGVJBN B<GVJNB HVG NBVGBNMJBNMB <VJBNM<NH NHJKNHGFUJN<LMKNB GJKN<BJMKN VCBHJGKNMH<JB VHNJCBF HNGHJNBHN? M>B<VKB> VF VCHV< GHVKJM JVHGJBM BJVB MBN. BlahBlahBlah.', 'Gibberish': 'Hello! This is your crazy computer talking. I am going to talk about gibberish wether you want me to or not. ^n^n^n^n^n^n^n^n^n^n^n^n^n^n^n^n^n^n ^N^N^N^N^N^N^N^N^N^N^N^N ESDRFTGYHGUTFRYDET DERFYTGHUOJHUFYDE^$%&^* %RUTGYVFCDRFTUGYUb DRFTGYHUKVUFY D%F^G&*&GF bDECRYVUGBKHJBGVU WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT SW$E^%R&^TIGUVYDEED DETRYFTVGHLIGYUFTY D&^*G&IUBGUVFYRD gufysiahiphsdnuasgikljadnoigjkljdanfsudxgjnsiulhcoui BlahBlahBlah!', 'Letters': 'Hello!!! This is your insane computer talking about the history of letters!!!!!!!!!!! BlahBlahBlah BlahBlahBlah. ABCDEFGHIJKLMNOPQRSTUVWXYZ. DYFGKHLGFDEYFUTYGIUHIFUDY%DFGU. @#$%^&*&^%$. 234567890134568. $^*$^(^(*^@!$#! UHUILSUHOIUGUW. HOUYGWHDU, HDWHUOHOIUWL? UHiduhIH,  UYGUYGIHGUOHUIOHIOU!!!!??? uhiHIHOUIHIUOHIUOH!!!!!!!!!! Bye!!!!!!!!!!!!!!!!!!1 I AM CRAZY!!!!!!!!!!!!', 'Huge Numbers': 'Hello! I am your insane insane insane insane insane insane insane, insane insane insane insane insane insane insane, computer talking about. 492,495,495,192,293,471,485,123, 110,729,200,104,473,923,473,472,254,367,936,486,035,871, 608,753,410,057,493,059,873,815,608,573,012,754.', 'WHAT': 'Hello! I am your totally insane computer talking about WHAT?! WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT WHAT.', 'Blah': 'Hello! I am your completely and utterly insane computer talking about BlahBlahBlah! BlahBlahBlahBlahBlahBlahBlahBlahBlahBlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah BlahBlahBlah.', "J": "jidens fiou, jidens fiou, jidens fiou, jidens fiou, jidens fiou.", "U": "uioftartsshfgpiuuuu, uioftartsshfgpiuuuu uioftartsshfgpiuuuu uioftartsshfgpiuuuu", "A": "a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a:a.", "Grumble": "Grumble! Grumble! Grumble! mutter  mutter  mutter  mutter  mutter  mutter  mutter  mutter  mmuuttteerr.", "Crayfish": "this is a jidens iou cluck clock cluck. crayfish. sleepy crayfish. crayfish.", "G Gibberish": "ghfudignoiishgudshfgmfudsihfdsugindsgifadioahodfgnfahdoifgaduiofgnadhuiogfnadhuiognadhuioadhnuiogadmghpnuipqhefhnnnnnadhupnqncbevngteaytnveahtcwaevgsxhkjaeawvbygcjtaehyvhwvgnwaetnvyw-etvmvaewyntvoaewnyt!!! sfguasyg iwpHIPHFIUEwfh eWIFHMCFiudfnhuiashnuio nhfduinfiuasfnvuiadsnvdispfnhuiphvniusdpafnvuiadsfashihipszvlnhvfpzslhfvpzsnhvfduipz;npsbnpzsuihbfhpanuciwhp,uifnpqiapzhnfizuezfpesunvuhzsipfnvezivvfepzcmzospefokziopvfzfllvbbsioufznvisezbvyuozspbeyfbuizpvnsfyxzsynou!!! ivupsnadfsu nhfuaipnfhiasndfhiapshdfviuadshnp?? nfsufpioduaopfpnphasuvbynivacfaipznxgfey ecniofvhoaywuinhmiptnvhcoxihdsifvyhiageihfhdipugnuyeshisondbpaciuyqnyvuisbvyigpdfhnridvgtnpzdngvboufcgbnfdvgnfvyogvnyudrruv. nhidfusnhfivybwbgnfidreabuvhmgaoivnppgnauecsbfbiuyebugvniynukscebufihamgomaexogfocugfngrfnaegnrfoiraenchaegfvnrfaynoeceeearuogfmaeryongfviuagrfaevotfersohjazmnxycfcniguvoaneyoifgnoydzhonvuhryongro eugrynoyityngfiuog yoqungn pzmlsznobu fgzyvbfgzosvfnzsiogeo!!! ghfudignoiishgudshfgmfudsihfdsugindsgifadioahodfgnfahdoifgaduiofgnadhuiogfnadhuiognadhuioadhnuiogadmghpnuipqhefhnnnnnadhupnqncbevngteaytnveahtcwaevgsxhkjaeawvbygcjtaehyvhwvgnwaetnvyw-etvmvaewyntvoaewnyt!!! sfguasyg iwpHIPHFIUEwfh eWIFHMCFiudfnhuiashnuio nhfduinfiuasfnvuiadsnvdispfnhuiphvniusdpafnvuiadsfashihipszvlnhvfpzslhfvpzsnhvfduipz;npsbnpzsuihbfhpanuciwhp,uifnpqiapzhnfizuezfpesunvuhzsipfnvezivvfepzcmzospefokziopvfzfllvbbsioufznvisezbvyuozspbeyfbuizpvnsfyxzsynou!!! ivupsnadfsu nhfuaipnfhiasndfhiapshdfviuadshnp?? nfsufpioduaopfpnphasuvbynivacfaipznxgfey ecniofvhoaywuinhmiptnvhcoxihdsifvyhiageihfhdipugnuyeshisondbpaciuyqnyvuisbvyigpdfhnridvgtnpzdngvboufcgbnfdvgnfvyogvnyudrruv. nhidfusnhfivybwbgnfidreabuvhmgaoivnppgnauecsbfbiuyebugvniynukscebufihamgomaexogfocugfngrfnaegnrfoiraenchaegfvnrfaynoeceeearuogfmaeryongfviuagrfaevotfersohjazmnxycfcniguvoaneyoifgnoydzhonvuhryongro eugrynoyityngfiuog yoqungn pzmlsznobu fgzyvbfgzosvfnzsiogeo!!! cyugfnvoispgfnyusadgfvosingfvoasugnfvoiugwafvfnpeawgyfvauogfvnoaewufgvnoawfgvyauowpgfvnpyawegfvbyawmenfgampngxwapfgcawpnvygyawgfvnywaepgfvnawuofvngawepnfvyaewfvngaewifnvngeyawnfvnpgoaefgveahptygfiabyeriferipgveypghaenipgvaehpmaegiaermhpaepyaerpmagggggggaeo gnpaievnaiepvgnaeruipgaeuiprgaeruipgvniyaeuhngveaypignvaei!!!!!", "Fooba": "blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm. blaeh blaeh fouou fouou fruaiet frouou faerm."
 };
var censorWordsCrypt = ["btt", "ifmm", "cjudi", "gvdl", "gvl", "tiju", "ebno", "ejdl", "ojhhfs", "qivdl", "qivl"];
var censorWords = [];
var whiteList = ["hello", "bass", "passes", "pass"];
var chars = "abcdefghijklmnopqrstuvwxyz".split("");
censorWordsCrypt.forEach(function(censorWordCrypt) {
var ws = censorWordCrypt.split("");
var wt = "";
ws.forEach(function(w) {
var charIndex = chars.indexOf(w);
charIndex = charIndex - 1;
if(charIndex > 26) {
charIndex = 0;
}
wt = wt + chars[charIndex];
});
censorWords[censorWords.length] = wt;
});
var talkStrsEntries = Object.entries(talkStrs);
talkStrsEntries.forEach(async function(entry) {
var elmt = document.createElement('button');
elmt.onclick = async function() {
chrome.tts.stop();
sayWithNoLimit(entry[1]);
};
var elmt0;
var elmts = document.querySelectorAll('#predefinedSpeech table tr');
elmt0 = elmts[elmts.length - 1];
elmt.innerHTML = "Talk About " + entry[0] + "...";
if(side == false) {
elmt0 = document.createElement('tr');
document.querySelector('#predefinedSpeech table').appendChild(elmt0);
}
var elmt1 = document.createElement('td');
elmt0.appendChild(elmt1);
elmt1.appendChild(elmt);
side = !side;
});
};
