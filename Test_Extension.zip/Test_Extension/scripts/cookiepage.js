import './utils.js';
window.onload = function() {
function filterTable() {
popupcookies(filterSettings);
}
var cookiescheck;
var storeIdFilter = document.querySelector('#storeIdFilter');
var nameFilter = document.querySelector('#nameFilter');
var domainFilter = document.querySelector('#domainFilter');
var expirationDateFilter = document.querySelector('#expirationDateFilter');
var valueFilter = document.querySelector('#valueFilter');
var filters = [storeIdFilter, nameFilter, domainFilter, expirationDateFilter, valueFilter];
filters.forEach(function(filter) {
filter.onkeydown = function(evt) {
filter.onchange(evt);
};
filter.onchange = function(evt) {
if(evt.target.value != '') {
evt.target.setAttribute('active', 'active');
} else {
evt.target.setAttribute('active', 'inactive');
}
};
filter.setAttribute('active', 'inactive');
});
var filterSettings = new Object();
filterSettings.storeId = null;
filterSettings.name = null;
filterSettings.domain = null;
filterSettings.expirationDate = null;
filterSettings.value = null;
var filterBtn = document.querySelector('#submitfilter');
filterBtn.onclick = function(evt) {
if(storeIdFilter.getAttribute('active') == 'active') {
filterSettings.storeId = storeIdFilter.value;
} else {
filterSettings.storeId = null;
}
if(nameFilter.getAttribute('active') == 'active') {
filterSettings.name = nameFilter.value;
} else {
filterSettings.name = null;
}
if(domainFilter.getAttribute('active') == 'active') {
filterSettings.domain = domainFilter.value;
} else {
filterSettings.domain = null;
}
if(expirationDateFilter.getAttribute('active') == 'active') {
filterSettings.expirationDate = expirationDateFilter.value;
} else {
filterSettings.expirationDate = null;
}
if(valueFilter.getAttribute('active') == 'active') {
filterSettings.value = valueFilter.value;
} else {
filterSettings.value = null;
}
filterTable();
};
if(window.location.search.replace('?', '').split('&')[0].split('=')[1] != null) {
const action = window.location.search.replace('?', '').split('&')[0].split('=')[1];
if(action == 'delete') {
document.querySelector('#deletepopup').setAttribute('style', 'background-color: #00000099;position: fixed;left: 0;top: 0;display: block;width: 100%;height: 100%;');
document.querySelector('#deletepopup .responsego').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
deleteCookie(window.location.search.replace('?', '').split('&')[1].split('=')[1], window.location.search.replace('?', '').split('&')[2].split('=')[1].replaceAll('%2F', '/'), window.location.search.replace('?', '').split('&')[3].split('=')[1]);
};
document.querySelector('#deletepopup .responseno').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
reloadCookiePage();
};
} else if(action == 'open') {
openCookie(window.location.search.replace('?', '').split('&')[1].split('=')[1], window.location.search.replace('?', '').split('&')[2].split('=')[1].replaceAll('%2F', '/'), window.location.search.replace('?', '').split('&')[3].split('=')[1]);
}
}
var cookiediv = document.createElement('div');
cookiediv.setAttribute('id', 'cookieInfo');
document.querySelector('#content').appendChild(cookiediv);
popupcookies();
chrome.cookies.onChanged.addListener(popupcookies);
chrome.storage.onChanged.addListener(popupcookies);
async function popupcookies(filter=filterSettings) {
var highlight = false;
var elmt = document.createElement('table');
elmt.innerHTML = "<tr>\n<th></th>\n<th>ID</th>\n<th>Name</th>\n<th>Domain</th>\n<th>Expiration Date</th>\n<th>Value</th>\n<th>Actions</th>\n</tr>\n";
chrome.cookies.getAll(
new Object(),
async function(_cookies) {
var cookiesTemp = _cookies;
var _syncStorage = await chrome.storage.sync.get();
var _localStorage = await chrome.storage.local.get();
var _sessionStorage = await chrome.storage.session.get();
var _managedStorage = await chrome.storage.managed.get();
if(_syncStorage != {} && _syncStorage != undefined && _syncStorage != null) {
((Object.entries(_syncStorage)) || []).forEach(function(item) {
var tempObj = new Object();
tempObj.enableactions = false;
tempObj.name = item[0];
tempObj.value = item[1];
tempObj.domain = "Sync";
tempObj.storeId = "-";
cookiesTemp[cookiesTemp.length] = tempObj;
});
}
if(_localStorage != {} && _localStorage != undefined && _localStorage != null) {
((Object.entries(_localStorage)) || []).forEach(function(item) {
var tempObj = new Object();
tempObj.enableactions = false;
tempObj.name = item[0];
tempObj.value = item[1];
tempObj.domain = "Local";
tempObj.storeId = "-";
cookiesTemp[cookiesTemp.length] = tempObj;
});
}
if(_sessionStorage != {} && _sessionStorage != undefined && _sessionStorage != null) {
((Object.entries(_sessionStorage)) || []).forEach(function(item) {
var tempObj = new Object();
tempObj.enableactions = false;
tempObj.name = item[0];
tempObj.value = item[1];
tempObj.domain = "Session";
tempObj.storeId = "-";
cookiesTemp[cookiesTemp.length] = tempObj;
});
}
if(_managedStorage != {} && _managedStorage != undefined && _managedStorage != null) {
((Object.entries(_managedStorage)) || []).forEach(function(item) {
var tempObj = new Object();
tempObj.enableactions = false;
tempObj.name = item[0];
tempObj.value = item[1];
tempObj.domain = "Managed";
tempObj.storeId = "-";
cookiesTemp[cookiesTemp.length] = tempObj;
});
}
var cookies = cookiesTemp;
setTimeout(async function() {
if(cookies != null && document.querySelector('#removebtn').getAttribute('style') == 'display: none;') {
cookies.forEach(function(cookie) {
if(filter != null) {
if(cookie.storeId.toString().indexOf(filter.storeId == null ? "" : filter.storeId) != -1 && cookie.name.toString().indexOf(filter.name == null ? "" : filter.name) != -1 && cookie.domain.toString().indexOf(filter.domain == null ? "" : filter.domain) != -1 && (cookie.value || "").toString().indexOf(filter.value == null ? "" : filter.value) != -1) {
var tempdomain = cookie.domain;
if(tempdomain.substring(0, 1) == '.') {
tempdomain = tempdomain.substring(1, tempdomain.length);
}
var celmt = document.createElement('tr');
celmt.innerHTML = "<td>" + (cookie.enableactions != false ? "<input type=\"checkbox\" class=\"cookiecheck\" cookiedomain=\"" + tempdomain + "\" cookiepath=\"" + cookie.path + "\" cookiename=\"" + cookie.name + "\" />" : "<div style=\"height: 20px;\"></div>") + "</td>\n<td>" + cookie.storeId + "</td>\n<td>" + cookie.name + "</td>\n<td>" + cookie.domain + "</td>\n<td>" + cookie.expirationDate + "</td>\n<td>" + ((cookie.value || "").length > 100 ? ((cookie.value || "").substring(0, 100) + "...") : (cookie.value)) + "</td>\n";
var cdelmt = document.createElement('td');
if(cookie.enableactions != false) {
var cda1elmt = document.createElement('a');
cda1elmt.setAttribute('href', '#');
cda1elmt.onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
setPageQueryOpen(cookie.name, cookie.path, cookie.domain);
};
cda1elmt.innerHTML = "Open Cookie Site...";
var cda2elmt = document.createElement('a');
cda2elmt.setAttribute('href', '#'); 
cda2elmt.onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
setPageQueryDelete(cookie.name, cookie.path, cookie.domain);
};
cda2elmt.innerHTML = "Delete...";
}
elmt.appendChild(celmt);
if(highlight == true) {
celmt.setAttribute('class', 'highlight');
}
celmt.appendChild(cdelmt);
if(cookie.enableactions != false) {
cdelmt.appendChild(cda1elmt);
var selmt = document.createElement('p');
selmt.innerHTML = "    ";
cdelmt.appendChild(selmt);
cdelmt.appendChild(cda2elmt);
}
highlight = !highlight;
}
} else {
var tempdomain = cookie.domain;
if(tempdomain.substring(0, 1) == '.') {
tempdomain = tempdomain.substring(1, tempdomain.length);
}
var celmt = document.createElement('tr');
celmt.innerHTML = "<td>" + (cookie.enableactions != false ? "<input type=\"checkbox\" class=\"cookiecheck\" cookiedomain=\"" + tempdomain + "\" cookiepath=\"" + cookie.path + "\" cookiename=\"" + cookie.name + "\" />" : "") + "</td>\n<td>" + cookie.storeId + "</td>\n<td>" + cookie.name + "</td>\n<td>" + cookie.domain + "</td>\n<td>" + cookie.expirationDate + "</td>\n<td>" + (cookie.value.length > 100 ? (cookie.value.substring(0, 100) + "...") : (cookie.value)) + "</td>\n";
var cdelmt = document.createElement('td');
if(cookie.enableactions != false) {
var cda1elmt = document.createElement('a');
cda1elmt.setAttribute('href', '#');
cda1elmt.onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
setPageQueryOpen(cookie.name, cookie.path, cookie.domain);
};
cda1elmt.innerHTML = "Open Cookie Site...";
var cda2elmt = document.createElement('a');
cda2elmt.setAttribute('href', '#'); 
cda2elmt.onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
setPageQueryDelete(cookie.name, cookie.path, cookie.domain);
};
cda2elmt.innerHTML = "Delete...";
}
elmt.appendChild(celmt);
if(highlight == true) {
celmt.setAttribute('class', 'highlight');
}
celmt.appendChild(cdelmt);
if(cookie.enableactions != false) {
cdelmt.appendChild(cda1elmt);
var selmt = document.createElement('p');
selmt.innerHTML = "    ";
cdelmt.appendChild(selmt);
cdelmt.appendChild(cda2elmt);
}
highlight = !highlight;
}
});
}
if(document.querySelector('#removebtn').getAttribute('style') == 'display: none;') {
cookiediv.innerHTML = "";
cookiediv.appendChild(elmt);
cookiescheck = [];
var checks = document.querySelectorAll('.cookiecheck');
checks.forEach(function(check) {
check.addEventListener('click', function(evt) {
if(check.checked == true) {
var cookieinfoobj = new Object();
cookieinfoobj.domain = check.getAttribute('cookiedomain');
cookieinfoobj.path = check.getAttribute('cookiepath');
cookieinfoobj.name = check.getAttribute('cookiename');
check.setAttribute('listid', cookiescheck.length.toString());
cookiescheck[cookiescheck.length] = cookieinfoobj;
} else {
cookiescheck.splice(check.getAttribute('listid'), 1);
}
if(cookiescheck.length > 0) {
document.querySelector('#removebtn').setAttribute('style', 'display: block;');
} else {
document.querySelector('#removebtn').setAttribute('style', 'display: none;');
}
}, false);
});
}
}, 1000);
});
}
document.querySelector('#removebtn').onclick = async function(evt) {
var tempLocation = chrome.runtime.getURL('/html/bulkdelete.html?cookies=');
cookiescheck.forEach(function(cookie) {
tempLocation = tempLocation + (('{' + cookie.domain + ',' + cookie.path + ',' + cookie.name + '};').replaceAll(' ', '%20').replaceAll('/', '%2F'));
});
tempLocation = tempLocation.substring(0, tempLocation.length - 1);
window.location.href = tempLocation;
};
};
async function setPageQueryOpen(cookiename, cookiepath, cookiedomain) {
const queryinfo = { 'active': true };
const tabs = chrome.tabs.query(queryinfo);
const tab = tabs[0];
window.location.href = chrome.runtime.getURL('/html/cookiepage.html?action=open&name=' + cookiename + '&path=' + cookiepath.replaceAll('/', '%2F') + '&domain=' + cookiedomain);
}
async function setPageQueryDelete(cookiename, cookiepath, cookiedomain) {
const queryinfo = { 'active': true };
const tabs = chrome.tabs.query(queryinfo);
const tab = tabs[0];
window.location.href = chrome.runtime.getURL('/html/cookiepage.html?action=delete&name=' + cookiename + '&path=' + cookiepath.replaceAll('/', '%2F') + '&domain=' + cookiedomain);
}
async function reloadCookiePage() {
const queryinfo = { 'active': true };
const tabs = chrome.tabs.query(queryinfo);
const tab = tabs[0];
window.location.href = chrome.runtime.getURL('/html/cookiepage.html');
}
async function deleteCookie(cookiename, path, domain) {
var urltemp = domain;
if(urltemp.substring(0, 1) == ".") {
urltemp = urltemp.substring(1, urltemp.length);
}
urltemp = "https://" + urltemp;
urltemp = urltemp + path;
chrome.cookies.remove({ name: cookiename, url: urltemp });
reloadCookiePage();
}
async function openCookie(cookiename, url, domain) {
const urlprefix = chrome.runtime.getURL("/html/redirect.html?name=Cookie%20Source&url=");
var urltemp = domain;
if(urltemp.substring(0, 1) == ".") {
urltemp = urltemp.substring(1, urltemp.length);
}
urltemp = "https://" + urltemp;
urltemp = urltemp + url;
urltemp = urltemp.replaceAll('/', '%2F');
const tab = await chrome.tabs.create({ 'url': urlprefix + urltemp });
const tabId = tab.id;
const windowId = tab.windowId;
chrome.tabs.update(tab.id, { 'active': true });
chrome.windows.update(windowId, { 'focused': true });
reloadCookiePage();
}
