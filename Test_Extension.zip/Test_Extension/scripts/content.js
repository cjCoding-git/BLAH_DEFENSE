async function injectDinoGame() {
var dinoUrl = chrome.runtime.getURL('/images/dino.png');
var gameUrl = chrome.runtime.getURL('/html/dinogame.html');
var buttonElmt = document.createElement('button');
async function dinoGameBtnClick() {
chrome.runtime.sendMessage({ 'greeting': 'setBadgeText', 'data': { 'text': '1' } });
document.documentElement.innerHTML = "<iframe src='" + gameUrl + "' style='padding: 0;position: fixed;top: 0;left: 0;width: 100%;height: 100%;margin: 0;border: 0;'></iframe>";
document.documentElement.setAttribute('style', 'margin: 0;padding: 0;border: 0;');
var exitBtnElmt = document.createElement('button');
exitBtnElmt.setAttribute('title', 'Exit Dino Game');
exitBtnElmt.onclick = async function() {
chrome.runtime.sendMessage({ 'greeting': 'setBadgeText', 'data': { 'text': '0' } });
window.history.go(0);
};
exitBtnElmt.setAttribute('type', 'button');
exitBtnElmt.setAttribute('id', 'dino-game-exit-btn');
exitBtnElmt.setAttribute('style', "background-size: contain;position: fixed;right: 15px;top: 15px;border-radius: 50%;width: 16px;height: 16px;background-image: url('" + chrome.runtime.getURL('/images/close.png') + "');border: 1px solid white;cursor: pointer;z-index: 999999999999;background-color: white;");
document.documentElement.appendChild(exitBtnElmt);
var gameStyleElmt = document.createElement('style');
gameStyleElmt.setAttribute('type', 'text/css');
gameStyleElmt.innerHTML = "#dino-game-play-btn:hover { box-shadow: inset -1px -2px 3px #9c9c9c;border: 1px solid #0044dd!important; }\n#dino-game-hide-btn:hover { box-shadow: inset -1px -1px 2px #9c9c9c;border: 1px solid #0044dd!important; }\n#dino-game-exit-btn:hover { box-shadow: inset -1px -2px 3px #9c9c9c;border: 1px solid #0044dd!important; }";
document.documentElement.appendChild(gameStyleElmt);
}
buttonElmt.setAttribute('type', 'button');
buttonElmt.setAttribute('style', "border-radius: 50%;background-image: url(\"" + dinoUrl + "\");position: fixed;cursor: pointer;bottom: 15px;left: 15px;width: 64px;height: 64px;z-index: 999999999999;border: 1px solid white;background-size: contain;");
buttonElmt.setAttribute('id', 'dino-game-play-btn');
buttonElmt.setAttribute('title', 'Play The Dino Game');
buttonElmt.onclick = dinoGameBtnClick;
document.body.appendChild(buttonElmt);
var hideBtnElmt = document.createElement('button');
hideBtnElmt.setAttribute('id', 'dino-game-hide-btn');
hideBtnElmt.onclick = async function() {
document.querySelector('#dino-game-hide-btn').remove();
document.querySelector('#dino-game-play-btn').remove();
};
hideBtnElmt.setAttribute('type', 'button');
hideBtnElmt.setAttribute('title', 'Hide Dino Game Button');
hideBtnElmt.setAttribute('style', "cursor: pointer;z-index: 999999999999999999;position: fixed;left: 63px;bottom: 63px;background-image: url('" + chrome.runtime.getURL('/images/close.png') + "');border-radius: 50%;border: 1px solid #555555;width: 16px;height: 16px;background-color: white;background-size: contain;");
document.body.appendChild(hideBtnElmt);
var styleElmt = document.createElement('style');
styleElmt.setAttribute('type', 'text/css');
styleElmt.innerHTML = "#close-btn-overlay:hover { background-color: #a0a0b025; }#dino-game-play-btn:hover { box-shadow: inset -1px -2px 3px #9c9c9c;border: 1px solid #0044dd!important; }\n#dino-game-hide-btn:hover { box-shadow: inset -1px -1px 2px #9c9c9c;border: 1px solid #0044dd!important; }\n#dino-game-exit-btn:hover { box-shadow: inset -1px -2px 3px #9c9c9c;border: 1px solid #0044dd!important; }";
document.documentElement.appendChild(styleElmt);
}
window.onload = async function() {};
(async function() {
var show_dino_btn_obj = await chrome.storage.sync.get('show_dino_btn');
var show_dino_btn_value = show_dino_btn_obj.show_dino_btn;
if(show_dino_btn_value == 'on') {
if(window.location.host.split('.')[1] != 'cjcoding' && window.location.host.split('.')[2] || 'com' != 'com' && window.location.host.split('.')[0] != 'cjcoding') {
var dino_show_domain = false;
var dino_btn_domains_obj = await chrome.storage.sync.get('dino_btn_domains');
var dino_btn_domains_value = dino_btn_domains_obj.dino_btn_domains || "";
var dino_btn_domains_list = dino_btn_domains_value.split(',');
var location_sectors = window.location.host.split('.');
if(dino_btn_domains_list.length > 0 && dino_btn_domains_value != "") {
dino_btn_domains_list.forEach(function(dino_btn_domain) {
var dino_btn_domain_sectors = dino_btn_domain.split('.');
var dino_btn_domain_name = dino_btn_domain_sectors[dino_btn_domain_sectors.length-2];
var dino_btn_domain_top = dino_btn_domain_sectors[dino_btn_domain_sectors.length-1];
var location_sector_name = location_sectors[location_sectors.length-2];
var location_sector_top = location_sectors[location_sectors.length-1];
if(dino_btn_domain_top == location_sector_top && dino_btn_domain_name == location_sector_name) {
dino_show_domain = true;
}
});
} else {
dino_show_domain = true;
}
if(dino_show_domain == true) {
injectDinoGame();
}
}
}
var replaceGradesObj = await chrome.storage.sync.get('replace_titles');
var replaceGrades = replaceGradesObj.replace_titles || false;
if(window.location.host == 'schoology.stillwaterschools.org' && replaceGrades) {
async function content(selector, text) {
var elmt = document.querySelector(selector);
if(elmt) {
elmt.innerHTML = text;
}
}
var re1 = document.querySelector('.view-info');
if(re1) {
re1.setAttribute('original-title', 'View Stupid Stuff');
}
var replaceElmts = [['.received-grade', 'Stoopid'], ['.grade-title', 'Stupid Stuff: '], ['.assessment-status-wrapper .infotip-content', 'This assessment is currently accepting stupid stuff'], ['#header>header>nav>ul>li>button', "Stupid Stuff\n<svg viewBox=\"0 0 15 10\" class=\"_3U8Br util-caret-icon-modern-1iz99 _3ESp2 dlCBz _1I3mg fjQuT uQOmx\"><use xlink:href=\"#icon-caret-v2-2f65r\"></use></svg>"], ['#header>header>nav>ul>li>ul>a', 'Stoopid Report'], ['#menu-s-main>.menu>li>div.menu-747>a', '<span></span>\nStupid Stuff'], ['#content-wrapper>div>div>div>div>div>main>div>div>h4', 'Stoopid Stuff'], ['#center-top .page-title', 'Stupid Stuff']];
replaceElmts.forEach(async function(re) {
content(re[0], re[1]);
});
document.querySelectorAll('.course-grade-text').forEach(async function(e) {
e.innerHTML = 'Stupid Stuff: ';
});
document.querySelector('#header>header>nav>ul>li>button').addEventListener('click', async function() {
setTimeout(async function() {
content('#header>header>nav>ul>li>ul>a', 'Stoopid Report');
}, 250);
});
}
async function handleAppFinderNTP() {
var elmt = document.createElement('div');
elmt.setAttribute('style', "position: fixed;top: 8px;right:5px;width:48px;height:50px;z-index:99999999999999999999999999;cursor:pointer;border-radius: 50%;");
elmt.setAttribute('id', 'close-btn-overlay');
elmt.innerHTML = "<svg xmlns=\"https://www.w3.org/2000/svg\" width=\"24px\" height=\"24px\" viewBox=\"0 0 24 24\" class=\"jUCDMc\" style=\"margin-top: 13px;margin-left: 12px;\"><path d=\"M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z\"></path><path d=\"M0 0h24v24H0z\" fill=\"none\"></path></svg>"
elmt.onclick = async function() {
window.location.href = 'https://www.google.com';
}
document.body.appendChild(elmt);
}
if((window.location.href.indexOf('https://workspace.google.com/u/0/marketplace/appfinder') != -1) && (window.location.href.substring(window.location.href.length, window.location.href.length - ('charlie'.length)) == 'charlie')) {
handleAppFinderNTP();
window.addEventListener('click', async function() {
setTimeout(async function() {
handleAppFinderNTP();
}, 1750);
}, false);
}
if(window.location.href.indexOf('&voiceSearch') != -1) {
setTimeout(function() {
document.querySelector('.goxjub').parentElement.click();
var intId = setInterval(function() {
if(document.querySelector('.spch-dlg').getAttribute('open') == null) {
console.log("Dialog Closed.");
clearInterval(intId);
var tabId = parseInt(((window.location.href.substring((window.location.href.indexOf('&tabId=') + '&tabId='.length), window.location.href.length))));
console.log(tabId);
setTimeout(function() {
chrome.runtime.sendMessage({ 'greeting': 'goToNewTab', 'data': tabId });
}, 750);
}
}, 500);
}, 500);
}
})();
