window.onload = function() {
var blinkIntervalId = null;
var text = "";
var currentCursorPos = 0;
document.querySelector('#editor').onclick = function(evt) {
if(blinkIntervalId != null) {
clearInterval(blinkIntervalId);
}
console.log(evt);
currentCursorPos = (evt.pageX - 16) / 4.15;
if(currentCursorPos > text.length) {
currentCursorPos = text.length;
}
if(currentCursorPos < 0) {
currentCursorPos = 0;
}
updateText(currentCursorPos);
blinkIntervalId = setInterval(function() {
document.querySelector('#caret').setAttribute('style', 'display: inline-flex;');
setTimeout(function() {
document.querySelector('#caret').setAttribute('style', 'display: none;');
}, 500);
}, 1000);
};
document.body.onclick = function(evt) {
if(evt.target.getAttribute('id') != 'editor' && (evt.target.parentElement || 'null' != 'null' && evt.target.parentElement.getAttribute('id') != 'editor')) {
clearInterval(blinkIntervalId);
blinkIntervalId = null;
}
};
function updateText(cursorPos=null) {
if(cursorPos == null) {
if(document.querySelector('#replaceHtmlCheck').checked) {
document.querySelector('#editor').innerHTML = "<div id=\"caret\" style=\"display: none;\"></div>";
var elmt = document.createElement('span');
elmt.innerText = text.replaceAll('<br />', "\n");
document.querySelector('#editor').appendChild(elmt);
} else {
document.querySelector('#editor').innerHTML = "<div id=\"caret\" style=\"display: none;\"></div>" + text;
}
currentCursorPos = 0;
} else {
if(document.querySelector('#replaceHtmlCheck').checked) {
document.querySelector('#editor').innerHTML = "";
var elmt1 = document.createElement('span');
elmt1.innerText = text.substring(0, cursorPos).replaceAll('<br />', "\n");
document.querySelector('#editor').appendChild(elmt1);
var elmt2 = document.createElement('div');
elmt2.setAttribute('id', 'caret');
elmt2.setAttribute('style', 'display: none;');
document.querySelector('#editor').appendChild(elmt2);
var elmt3 = document.createElement('span');
elmt3.innerText = text.substring(cursorPos, text.length).replaceAll('<br />', "\n");
document.querySelector('#editor').appendChild(elmt3);
} else {
document.querySelector('#editor').innerHTML = text.substring(0, cursorPos) + "<div id=\"caret\" style=\"display: none;\"></div>" + text.substring(cursorPos, text.length);
}
currentCursorPos = cursorPos;
}
}
async function loadFile(evt) {
if(evt.target.files.length > 0) {
var file = evt.target.files[0];
var filetext = await file.text();
text = filetext;
updateText();
}
}
document.querySelector('#loadButton').onclick = function() {
var elmt = document.createElement('input');
elmt.setAttribute('type', 'file');
elmt.onchange = function(evt) {
loadFile(evt);
};
elmt.click();
};
function textToUrl(text) {
return btoa(text);
}
document.querySelector('#saveButton').onclick = function() {
var filename = prompt("Enter Filename: ") || null;
if(filename != null) {
var elmt = document.createElement('a');
elmt.setAttribute('href', textToUrl(text));
elmt.setAttribute('download', filename);
elmt.click();
} else {
alert("Try Again. You Did Not Enter A Filename.");
}
};
document.body.onkeydown = function(evt) {
if(blinkIntervalId != null) {
if(evt.keyCode == 8 && currentCursorPos > 0) {
var tempText = text.substring(0, currentCursorPos - 1);
tempText = tempText + text.substring(currentCursorPos, text.length);
text = tempText;
updateText(currentCursorPos - 1);
} else if(evt.key == "Delete" && currentCursorPos < text.length) {
var tempText = text.substring(0, currentCursorPos + 1);
tempText = tempText + text.substring(currentCursorPos, text.length);
text = tempText;
updateText(currentCursorPos - 1);
} else if(evt.key == "ArrowLeft" && currentCursorPos > 0) {
updateText(currentCursorPos - 1);
} else if(evt.key == "ArrowRight" && currentCursorPos < text.length) {
updateText(currentCursorPos + 1);
} else if(evt.key == "Enter") {
text = text.substring(0, currentCursorPos) + "<br />" + text.substring(currentCursorPos, text.length);
updateText(currentCursorPos + 6);
} else if(evt.key == "Tab") {
text = text.substring(0, currentCursorPos) + "    " + text.substring(currentCursorPos, text.length);
updateText(currentCursorPos + 4);
} else if(evt.key != "Shift" && evt.key != "Control" && evt.key != "Alt" && evt.key != "Delete" && evt.key != "ArrowLeft" && evt.key != "ArrowRight" && evt.key != "ArrowUp" && evt.key != "ArrowDown" && evt.key != "Backspace" && evt.key != "Enter" && evt.key != "CapsLock" && evt.key != "Tab") {
text = text.substring(0, currentCursorPos) + evt.key + text.substring(currentCursorPos, text.length);
updateText(currentCursorPos + 1);
}
}
};
};