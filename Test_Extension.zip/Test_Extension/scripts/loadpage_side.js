window.onload  = async function() {
var targeturl = window.location.search.substring(5, window.location.search.length).replaceAll('%3A', ':').replaceAll('%2F', '/').replaceAll('%3F', '?').replaceAll('%23', '#').replaceAll('%26', '&').replaceAll('%3D', '=').replaceAll('%25', '%').replaceAll('%21', '!').replaceAll('%40', '@');
console.log("Target URL: " + targeturl + ".");
document.querySelector('#urlgo').innerText = targeturl;
document.querySelector('#nobtn').onclick = async function() {
window.location.href = './side-panel_all.html';
};
document.querySelector('#gobtn').onclick = async function(evt) {
document.querySelector('#response').remove();
document.querySelector('#loadingtext').innerText = 'Loading...';
var status = 0;
var messages = [[25, 'Preparing...'], [37, 'Locating...'], [50, 'Please Wait...'], [60, 'Finializing...'], [75, 'Finishing...']];
async function loadPageNow() {
document.querySelector('#loadingstatus').setAttribute('style', 'display: block');
document.querySelector('#loadingmessage').setAttribute('style', 'display: block;');
var loadInt = setInterval(async function() {
status = status + 1;
var decimalPercent = "0." + status.toString();
if(status < 10) {
decimalPercent = "0.0" + status.toString();
} else if(status >= 100) {
decimalPercent = "1.0";
}
document.querySelector('#loadingprogress').setAttribute('value', decimalPercent.toString());
var messageElmt = document.querySelector('#loadingmessage');
if(status >= messages[4][0]) {
messageElmt.innerText = messages[4][1];
} else if(status >= messages[3][0]) {
messageElmt.innerText = messages[3][1];
} else if(status >= messages[2][0]) {
messageElmt.innerText = messages[2][1];
} else if(status >= messages[1][0]) {
messageElmt.innerText = messages[1][1];
} else if(status >= messages[0][0]) {
messageElmt.innerText = messages[0][1];
}
document.querySelector('#loadingstatus').innerText = status.toString() + '%';
if(status >= 100) {
clearInterval(loadInt);
document.querySelector('#loadingmessage').setAttribute('style', 'display: none;');
document.querySelector('#loadingstatus').setAttribute('style', 'display: none;');
openTab();
}
}, 175);
async function openTab() {
setTimeout(async function() {
chrome.tabs.create({ 'url': targeturl });
setTimeout(async function() {
window.location.href = './side-panel_all.html';
}, 500);
}, 5750);
}
}
setTimeout(loadPageNow, 1750);
};
};
