var cookies = null;
window.onload = function() {
if(window.location.search != "?cookies") {
cookies = [];
var tempSearch = window.location.search.replace('?', '').replaceAll('%20', ' ').replaceAll('%2F', '/').split('=')[1].split(';');
tempSearch.forEach(function(part) {
var tempPart = part.replaceAll('{', '').replaceAll('}', '').split(',');
var domainPart = tempPart[0];
var pathPart = tempPart[1];
var namePart = tempPart[2];
var cookie = new Object();
cookie.domain = domainPart;
cookie.path = pathPart;
cookie.name = namePart;
cookies[cookies.length] = cookie;
});
var telmt = document.createElement('table');
document.querySelector('#cookietable').innerHTML = "";
telmt.innerHTML = "<tr>\n<th>Name</th>\n<th>Domain</th>\n<th>Path</th>\n</tr>";
document.querySelector('#cookietable').appendChild(telmt);
cookies.forEach(function(cookie) {
var elmt = document.createElement('tr');
elmt.innerHTML = "<td>" + cookie.name + "</td>\n<td>" + cookie.domain + "</td>\n<td>" + cookie.path + "</td>";
telmt.appendChild(elmt);
});
document.querySelector('#responseno').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
window.location.href = chrome.runtime.getURL('/html/cookiepage.html');
};
function removeDone() {
document.querySelector('#cookietable').innerHTML = "";
document.querySelector('#response').innerHTML = "<p style=\"color: green;font-size: x-large;\">Done!</p>";
setTimeout(function() {
window.location.href = chrome.runtime.getURL('/html/cookiepage.html');
}, 2750);
}
function removeCookies() {
cookies.forEach(function(cookie) {
removeCookie(cookie);
});
removeDone();
}
function removeCookie(cookie) {
var urltemp = cookie.domain;
urltemp = "https://" + urltemp;
urltemp = urltemp + cookie.path;
chrome.cookies.remove({ name: cookie.name, url: urltemp });
}
document.querySelector('#responsego').onclick = function(evt) {
evt.preventDefault();
evt.returnValue = '';
removeCookies();
};
} else {
window.location.href = chrome.runtime.getURL('/html/cookiepage.html');
}
};
