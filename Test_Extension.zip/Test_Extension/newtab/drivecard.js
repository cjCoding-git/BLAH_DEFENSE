async function getDriveFiles() {
var dr = await fetch('https://drive.google.com/drive/recent?ifhs=2');
if(dr.status == 200) {
var dd = new TextDecoder();
var db = dr.body;
var de = await db.getReader();
var da = await de.read();
var dy = da.value;
var dt = dd.decode(dy);
}
}
