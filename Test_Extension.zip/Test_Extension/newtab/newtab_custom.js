// Query Suggestion URL: https://www.google.com/complete/search?q=(Text Typed In Here)&cp=2&client=gws-wiz&xssi=t&gs_pcrt=undefined&hl=en&authuser=0&psi=H0OTZZjqDsHl0PEPpqyEkAk.1704149809791&dpr=1
// Get Searches In History: Execute "await chrome.history.search({ 'text': 'https://www.google.com/search?' });".
var noShortcuts = false;
async function padZero(str, len) {
len = len || 2;
var zeros = new Array(len).join('0');
return (zeros + str).slice(-len);
}
async function invertColor(hex, bw) {
if (hex.indexOf('#') === 0) {
hex = hex.slice(1);
}
if (hex.length === 3) {
hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
}
if (hex.length !== 6) {
return new Error('Invalid HEX color.');
}
var r = parseInt(hex.slice(0, 2), 16), g = parseInt(hex.slice(2, 4), 16), b = parseInt(hex.slice(4, 6), 16);
if (bw) {
return (r * 0.299 + g * 0.587 + b * 0.114) > 186 ? '#000000' : '#FFFFFF';
}
r = (255 - r).toString(16);
g = (255 - g).toString(16);
b = (255 - b).toString(16);
return "#" + (await padZero(r)) + (await padZero(g)) + (await padZero(b));
}
var doodles = [
{
"imagePath": chrome.runtime.getURL('/images/doodle-holidays.gif'),
"startTime": {
"day": 1,
"month": 12
},
"endTime": {
"day": 31,
"month": 12
},
"onclick": async function(evt) {},
"customStyle": "cursor: default;width: 50%;height: 25%;border-radius: 10px;padding-top: 10px;background-color: white;",
"useImage": true
},
{
"imagePath": "",
"startTime": {
"day": 1,
"month": 11,
},
"endTime": {
"day": 11,
"month": 11
},
"onclick": async function() {
document.querySelectorAll('#googleLogo img').forEach(async function(elmt) {
elmt.setAttribute('src', chrome.runtime.getURL('/images/lawson_' + elmt.getAttribute('src').substring(elmt.getAttribute('src').lastIndexOf('/') + 1, elmt.getAttribute('src').length)));
});
},
"customStyle": "width: 100%;height: 200%;margin-left: 25%;",
"replacementId": "lawson_doodle_replacement",
"useImage": false
}
];
var td = new TextDecoder();
var allJsCode = "";
window.onload = async function() {
var userInfo = await chrome.identity.getProfileUserInfo();
var hasEmail = userInfo.email != '';
var hasUserId = userInfo.id != '';
var hasInternet = navigator.onLine;
var canLogin = hasEmail && hasUserId && hasInternet;
document.querySelectorAll('.googleloadcircle').forEach(function(obj) {
obj.innerHTML = "<svg class=\"spinner\" viewBox=\"0 0 30 30\">\n<circle class=\"path\" cx=\"15\" cy=\"15\" r=\"11\" fill=\"none\" stroke-width=\"4\"></circle>\n</svg>";
});
$('#loadingText').fadeIn(500);
var new_tab_background_data_url_value = (await chrome.runtime.sendMessage('getImage')) || chrome.runtime.getURL("/newTabBackground.png");
if((new_tab_background_data_url_value || "").length > 0) {
var imgElmt = document.createElement('img');
imgElmt.setAttribute('src', new_tab_background_data_url_value);
imgElmt.setAttribute('id', 'backgroundImage');
imgElmt.setAttribute('style', 'display: none;');
document.querySelector('#background').appendChild(imgElmt);
imgElmt.onload = function() {
$('#backgroundImage').fadeIn(500);
};
} else {
document.querySelector('#background').setAttribute('style', 'display: none;');
}
$('#loadingStatus').text('Initalizing Background');
var new_tab_accent_background_obj = await chrome.storage.sync.get('new_tab_accent_background');
var new_tab_accent_background_value = new_tab_accent_background_obj.new_tab_accent_background;
var styleRule = "background-color: " + (new_tab_accent_background_value.replaceAll('%23', '#') || "#ffffff") + ";";
document.querySelector('#background').setAttribute('style', styleRule);
document.documentElement.setAttribute('style', 'background-color: ' + new_tab_accent_background_value.replaceAll('%23', '#') + ';');
if((new_tab_background_data_url_value || "").length > 0) {
} else {
$('#background').fadeIn(500);
}
document.querySelector('#show_apps').onclick = function() {
setTimeout(function() {
var oldclick = document.body.onclick;
document.body.onclick = function(evt) {
var elmt = evt.target;
while(true) {
if(elmt == document.querySelector('#appsdiv')) {
break;
} else if (elmt.parentElement || "null" != "null") {
elmt = elmt.parentElement;
} else if(elmt.parentElement || "null" == "null") {
document.body.onclick = oldclick;
document.querySelector('#appsdiv').setAttribute('style', 'display: none;');
document.querySelector('#googleBar').setAttribute('style', '');
break;
}
}
};
}, 500);
document.querySelector('#appsdiv').setAttribute('style', 'display: block;');
document.querySelector('#googleBar').setAttribute('style', '');
};
$('#loadingStatus').text('Initalizing Search Bar');
document.querySelector('#APjFqb').onkeydown = async function(evt) {
if(evt.key == 'Enter') {
evt.preventDefault();
evt.returnValue = '';
var querySearch = evt.target.value;
var queryUrl = "";
if(querySearch.indexOf('://') == -1 && !((querySearch.indexOf('://') < querySearch.indexOf('.')))) {
queryUrl = 'https://www.google.com/search?q=' + querySearch.replaceAll(' ', '+');
} else if(querySearch.indexOf('chrome://') == -1 && querySearch.indexOf('chrome-untrusted://') == -1) {
if(querySearch.indexOf('://') != -1) {
queryUrl = querySearch;
} else {
queryUrl = "http://" + querySearch;
}
} else {
queryUrl = "";
var currentTab = await chrome.tabs.getCurrent();
var currentTabId = currentTab.Id;
chrome.tabs.update(currentTabId, { 'url': querySearch });
if(querySearch.indexOf('chrome-untrusted://') != -1) {
alert("Invalid Page!");
evt.target.value = "";
}
}
if(queryUrl || "" != "") {
window.location.href = queryUrl;
}
}
};
document.querySelector('.QCzoEc.z1asCe.MZy1Rb').addEventListener('click', async function(evt) {
var inptValue = document.querySelector('#APjFqb').value;
if(inptValue || "" != "") {
document.querySelector('#APjFqb').onkeydown({ 'preventDefault': function() {}, 'returnValue': '', 'key': 'Enter', 'target': document.querySelector('#APjFqb') });
}
}, false);
document.querySelector('#APjFqb').onkeyup = async function(evt) {
if(evt.key != 'Enter') {
updateSearchList(evt.target.value);
}
var inptValue = document.querySelector('#APjFqb').value;
if(inptValue || "" != "") {
document.querySelector('.QCzoEc.z1asCe.MZy1Rb').setAttribute('style', 'height:20px;line-height:20px;width:20px;cursor: pointer;');
} else {
document.querySelector('.QCzoEc.z1asCe.MZy1Rb').setAttribute('style', 'height:20px;line-height:20px;width:20px;cursor: default;');
}
};
$('#loadingStatus').text('Initalizing Account Button');
document.querySelector('#showAccountInfo').onclick = async function(evt) {
setTimeout(async function() {
var oldclick = document.body.onclick;
document.body.onclick = async function(evt) {
var elmt = evt.target;
while(true) {
if(elmt == document.querySelector('#accountInfo')) {
break;
} else if (elmt.parentElement || "null" != "null") {
elmt = elmt.parentElement;
} else if(elmt.parentElement || "null" == "null") {
document.body.onclick = oldclick;
document.querySelector('#accountInfo').setAttribute('class', 'fade-in');
document.querySelector('#googleBar').setAttribute('style', '');
break;
}
}
};
}, 500);
document.querySelector('#accountInfo').setAttribute('class', 'fade-in show-visibility');
evt.preventDefault();
evt.returnValue = '';
document.querySelector('#googleBar').setAttribute('style', '');
};
if(canLogin == true) {
try {
while(!document.querySelector('#accountInfoAppend div')) {
var td = new TextDecoder();
var accountHtml = td.decode((await (await fetch('https://ogs.google.com/u/0/widget/account')).body.getReader().read()).value);
document.querySelector('#accountInfoAppend').innerHTML = accountHtml;
var selmts = document.querySelectorAll('#accountInfoAppend script');
selmts.forEach(async function(selmt) {
if(selmt.getAttributeNames().indexOf('src') == -1) {
var jsCode = selmt.innerHTML;
allJsCode += jsCode;
}
});
window.onload = async function() {};
document.querySelector('#showAccountInfo').click();
setTimeout(async function() {
document.body.click();
}, 525);
}
document.querySelector('#showAccountInfo img').setAttribute('src', document.querySelector("#accountInfoAppend img[alt='Profile image']").getAttribute('src'));
setTimeout(function() {
document.querySelector('.xjE3jd').remove();
}, 1000);
setTimeout(function() {
document.querySelector("div[jscontroller='hJpE8']").remove();
}, 1000);
setTimeout(function() {
document.querySelector('.XS2qof.Q3BXBb').onclick = async function() {
$('.googleloadbar').fadeIn(250);
$('.googleloadbarmodalbackground').fadeIn(250);
document.body.click();
setTimeout(async function() {
document.querySelector('.googleloadbar').setAttribute('style', 'display: none;');
document.querySelector('.googleloadbarmodalbackground').setAttribute('style', 'display: none;');
var win = await chrome.windows.create({ 'state': 'maximized', 'type': 'popup' });
var tab = await chrome.tabs.create({ 'url': 'https://myaccount.google.com/profile-picture?startPath=profile-picture&hostId=ogb&origin=chrome-untrusted%3A%2F%2Fnew-tab-page', 'windowId': win.id });
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
if(tabId == tab.id && (changeInfo.url || "").indexOf('https://www.google.com') != -1) {
chrome.windows.remove(win.id);
history.go(0);
}
});
}, 5000);
};
}, 1000);
setTimeout(function() {
document.querySelector('.Pzuhxc').onclick = function() {
document.body.click();
};
}, 1000);
setTimeout(function() {
document.querySelector('.MCcOAc.IqBfM.ecJEib.EWZcud .VUoKZ').remove();
}, 1000);
} catch(aerr) {}
}
$('#loadingStatus').text('Initalizing Light/Dark Mode');
var dark_new_tab = false;
var dark_new_tab_obj = await chrome.storage.sync.get('dark_new_tab');
var dark_new_tab_value = dark_new_tab_obj.dark_new_tab;
if(dark_new_tab_value == 'on') {
dark_new_tab = true;
}
if(dark_new_tab == true) {
document.documentElement.setAttribute('class', 'dark-mode');
document.querySelector('link[rel="icon"]').setAttribute('href', chrome.runtime.getURL('/images/new_tab_favicon_dark.png'));
}
$('#loadingStatus').text('Initalizing Shortcuts');
var shortcut_1 = null;
var shortcut_1_obj = await chrome.storage.sync.get('shortcut_1');
var shortcut_1_value = shortcut_1_obj.shortcut_1;
if((shortcut_1_value || "") != "") {
shortcut_1 = decodeURI(shortcut_1_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_1_name = null;
var shortcut_1_name_obj = await chrome.storage.sync.get('shortcut_1_name');
var shortcut_1_name_value = shortcut_1_name_obj.shortcut_1_name;
if((shortcut_1_name_value || "") != "") {
shortcut_1_name = decodeURI(shortcut_1_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_2 = null;
var shortcut_2_obj = await chrome.storage.sync.get('shortcut_2');
var shortcut_2_value = shortcut_2_obj.shortcut_2;
if((shortcut_2_value || "") != "") {
shortcut_2 = decodeURI(shortcut_2_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_2_name = null;
var shortcut_2_name_obj = await chrome.storage.sync.get('shortcut_2_name');
var shortcut_2_name_value = shortcut_2_name_obj.shortcut_2_name;
if((shortcut_2_name_value || "") != "") {
shortcut_2_name = decodeURI(shortcut_2_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_3 = null;
var shortcut_3_obj = await chrome.storage.sync.get('shortcut_3');
var shortcut_3_value = shortcut_3_obj.shortcut_3;
if((shortcut_3_value || "") != "") {
shortcut_3 = decodeURI(shortcut_3_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_3_name = null;
var shortcut_3_name_obj = await chrome.storage.sync.get('shortcut_3_name');
var shortcut_3_name_value = shortcut_3_name_obj.shortcut_3_name;
if((shortcut_3_name_value || "") != "") {
shortcut_3_name = decodeURI(shortcut_3_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_4 = null;
var shortcut_4_obj = await chrome.storage.sync.get('shortcut_4');
var shortcut_4_value = shortcut_4_obj.shortcut_4;
if((shortcut_4_value || "") != "") {
shortcut_4 = decodeURI(shortcut_4_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_4_name = null;
var shortcut_4_name_obj = await chrome.storage.sync.get('shortcut_4_name');
var shortcut_4_name_value = shortcut_4_name_obj.shortcut_4_name;
if((shortcut_4_name_value || "") != "") {
shortcut_4_name = decodeURI(shortcut_4_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_5 = null;
var shortcut_5_obj = await chrome.storage.sync.get('shortcut_5');
var shortcut_5_value = shortcut_5_obj.shortcut_5;
if((shortcut_5_value || "") != "") {
shortcut_5 = decodeURI(shortcut_5_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_5_name = null;
var shortcut_5_name_obj = await chrome.storage.sync.get('shortcut_5_name');
var shortcut_5_name_value = shortcut_5_name_obj.shortcut_5_name;
if((shortcut_5_name_value || "") != "") {
shortcut_5_name = decodeURI(shortcut_5_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_6 = null;
var shortcut_6_obj = await chrome.storage.sync.get('shortcut_6');
var shortcut_6_value = shortcut_6_obj.shortcut_6;
if((shortcut_6_value || "") != "") {
shortcut_6 = decodeURI(shortcut_6_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
var shortcut_6_name = null;
var shortcut_6_name_obj = await chrome.storage.sync.get('shortcut_6_name');
var shortcut_6_name_value = shortcut_6_name_obj.shortcut_6_name;
if((shortcut_6_name_value || "") != "") {
shortcut_6_name = decodeURI(shortcut_6_name_value).replaceAll('%3A', ':').replaceAll('%3F', '?').replaceAll('%3D', '=');
}
if(shortcut_1 || "null" == "null") {
noShortcuts = true;
}
if(shortcut_1 || "null" != "null") {
var useIcon = false;
var sf, sfb, sa, st;
try {
sf = await fetch(shortcut_1);
sfb = sf.body;
sa = await sfb.getReader().read();
st = td.decode(sa.value);
useIcon = st.indexOf('icon') != -1;
st = st.substring(st.indexOf('icon'), st.length - 1);
useIcon = useIcon && st.indexOf('href=') != -1;
st = st.substring(st.indexOf('href=') + 6, st.length - 1);
st = st.substring(0, st.indexOf('"'));
if(st.indexOf('//') == -1 || (st.indexOf('//') != 5 && st.indexOf('//') != 6 && st.indexOf('//') != 0)) {
var spt = shortcut_1.split("://");
var sp = spt[0] + '://' + spt[1].split('/')[0] + '/';
st = sp + st;
}
} catch(ierr) {}
var selmt = document.createElement('div');
var saelmt = document.createElement('a');
var sielmt = document.createElement('img');
var spelmt = document.createElement('p');
var sdelmt = document.createElement('div');
selmt.setAttribute('class', 'shortcut shortcut-top');
selmt.setAttribute('id', 'shortcut-1');
selmt.setAttribute('draggable', 'false');
saelmt.setAttribute('class', 'shortcut-link');
saelmt.setAttribute('draggable', 'false');
sielmt.setAttribute('class', 'shortcut-icon');
sielmt.setAttribute('draggable', 'false');
sdelmt.setAttribute('class', 'shortcut-icon-container');
sdelmt.setAttribute('draggable', 'false');
spelmt.setAttribute('class', 'shortcut-text');
spelmt.setAttribute('draggable', 'false');
spelmt.innerText = shortcut_1_name || shortcut_1;
saelmt.setAttribute('href', shortcut_1);
sielmt.setAttribute('src', (useIcon ? st : chrome.runtime.getURL('/images/shortcut-icon.png')));
selmt.appendChild(saelmt);
saelmt.appendChild(sdelmt);
sdelmt.appendChild(sielmt);
saelmt.appendChild(spelmt);
document.querySelector('#shortcuts').appendChild(selmt);
if(shortcut_2 || "null" != "null") {
var useIcon = false;
var sf, sfb, sa, st;
try {
sf = await fetch(shortcut_2);
sfb = sf.body;
sa = await sfb.getReader().read();
st = td.decode(sa.value);
useIcon = st.indexOf('icon') != -1;
st = st.substring(st.indexOf('icon'), st.length - 1);
useIcon = useIcon && st.indexOf('href=') != -1;
st = st.substring(st.indexOf('href=') + 6, st.length - 1);
st = st.substring(0, st.indexOf('"'));
if(st.indexOf('//') == -1 || (st.indexOf('//') != 5 && st.indexOf('//') != 6 && st.indexOf('//') != 0)) {
var spt = shortcut_2.split("://");
var sp = spt[0] + '://' + spt[1].split('/')[0] + '/';
st = sp + st;
}
} catch(ierr) {}
var selmt = document.createElement('div');
var saelmt = document.createElement('a');
var sielmt = document.createElement('img');
var spelmt = document.createElement('p');
var sdelmt = document.createElement('div');
selmt.setAttribute('class', 'shortcut shortcut-top');
selmt.setAttribute('id', 'shortcut-2');
selmt.setAttribute('draggable', 'false');
saelmt.setAttribute('class', 'shortcut-link');
saelmt.setAttribute('draggable', 'false');
sielmt.setAttribute('class', 'shortcut-icon');
sielmt.setAttribute('draggable', 'false');
sdelmt.setAttribute('class', 'shortcut-icon-container');
sdelmt.setAttribute('draggable', 'false');
spelmt.setAttribute('class', 'shortcut-text');
spelmt.setAttribute('draggable', 'false');
spelmt.innerText = shortcut_2_name || shortcut_2;
saelmt.setAttribute('href', shortcut_2);
sielmt.setAttribute('src', (useIcon ? st : chrome.runtime.getURL('/images/shortcut-icon.png')));
selmt.appendChild(saelmt);
saelmt.appendChild(sdelmt);
sdelmt.appendChild(sielmt);
saelmt.appendChild(spelmt);
document.querySelector('#shortcuts').appendChild(selmt);
if(shortcut_3 || "null" != "null") {
var useIcon = false;
var sf, sfb, sa, st;
try {
sf = await fetch(shortcut_3);
sfb = sf.body;
sa = await sfb.getReader().read();
st = td.decode(sa.value);
useIcon = st.indexOf('icon') != -1;
st = st.substring(st.indexOf('icon'), st.length - 1);
useIcon = useIcon && st.indexOf('href=') != -1;
st = st.substring(st.indexOf('href=') + 6, st.length - 1);
st = st.substring(0, st.indexOf('"'));
if(st.indexOf('//') == -1 || (st.indexOf('//') != 5 && st.indexOf('//') != 6 && st.indexOf('//') != 0)) {
var spt = shortcut_3.split("://");
var sp = spt[0] + '://' + spt[1].split('/')[0] + '/';
st = sp + st;
}
} catch(ierr) {}
var selmt = document.createElement('div');
var saelmt = document.createElement('a');
var sielmt = document.createElement('img');
var spelmt = document.createElement('p');
var sdelmt = document.createElement('div');
selmt.setAttribute('class', 'shortcut shortcut-top');
selmt.setAttribute('id', 'shortcut-3');
selmt.setAttribute('draggable', 'false');
saelmt.setAttribute('class', 'shortcut-link');
saelmt.setAttribute('draggable', 'false');
sielmt.setAttribute('class', 'shortcut-icon');
sielmt.setAttribute('draggable', 'false');
sdelmt.setAttribute('class', 'shortcut-icon-container');
sdelmt.setAttribute('draggable', 'false');
spelmt.setAttribute('class', 'shortcut-text');
spelmt.setAttribute('draggable', 'false');
spelmt.innerText = shortcut_3_name || shortcut_3;
saelmt.setAttribute('href', shortcut_3);
sielmt.setAttribute('src', (useIcon ? st : chrome.runtime.getURL('/images/shortcut-icon.png')));
selmt.appendChild(saelmt);
saelmt.appendChild(sdelmt);
sdelmt.appendChild(sielmt);
saelmt.appendChild(spelmt);
document.querySelector('#shortcuts').appendChild(selmt);
if(shortcut_4 || "null" != "null") {
var useIcon = false;
var sf, sfb, sa, st;
try {
sf = await fetch(shortcut_4);
sfb = sf.body;
sa = await sfb.getReader().read();
st = td.decode(sa.value);
useIcon = st.indexOf('icon') != -1;
st = st.substring(st.indexOf('icon'), st.length - 1);
useIcon = useIcon && st.indexOf('href=') != -1;
st = st.substring(st.indexOf('href=') + 6, st.length - 1);
st = st.substring(0, st.indexOf('"'));
if(st.indexOf('//') == -1 || (st.indexOf('//') != 5 && st.indexOf('//') != 6 && st.indexOf('//') != 0)) {
var spt = shortcut_4.split("://");
var sp = spt[0] + '://' + spt[1].split('/')[0] + '/';
st = sp + st;
}
} catch(ierr) {}
var selmt = document.createElement('div');
var saelmt = document.createElement('a');
var sielmt = document.createElement('img');
var spelmt = document.createElement('p');
var sdelmt = document.createElement('div');
selmt.setAttribute('class', 'shortcut shortcut-bottom');
selmt.setAttribute('id', 'shortcut-4');
selmt.setAttribute('draggable', 'false');
saelmt.setAttribute('class', 'shortcut-link');
saelmt.setAttribute('draggable', 'false');
sielmt.setAttribute('class', 'shortcut-icon');
sielmt.setAttribute('draggable', 'false');
sdelmt.setAttribute('class', 'shortcut-icon-container');
sdelmt.setAttribute('draggable', 'false');
spelmt.setAttribute('class', 'shortcut-text');
spelmt.setAttribute('draggable', 'false');
spelmt.innerText = shortcut_4_name || shortcut_4;
saelmt.setAttribute('href', shortcut_4);
sielmt.setAttribute('src', (useIcon ? st : chrome.runtime.getURL('/images/shortcut-icon.png')));
selmt.appendChild(saelmt);
saelmt.appendChild(sdelmt);
sdelmt.appendChild(sielmt);
saelmt.appendChild(spelmt);
document.querySelector('#shortcuts').appendChild(selmt);
if(shortcut_5 || "null" != "null") {
var useIcon = false;
var sf, sfb, sa, st;
try {
sf = await fetch(shortcut_5);
sfb = sf.body;
sa = await sfb.getReader().read();
st = td.decode(sa.value);
useIcon = st.indexOf('icon') != -1;
st = st.substring(st.indexOf('icon'), st.length - 1);
useIcon = useIcon && st.indexOf('href=') != -1;
st = st.substring(st.indexOf('href=') + 6, st.length - 1);
st = st.substring(0, st.indexOf('"'));
if(st.indexOf('//') == -1 || (st.indexOf('//') != 5 && st.indexOf('//') != 6 && st.indexOf('//') != 0)) {
var spt = shortcut_5.split("://");
var sp = spt[0] + '://' + spt[1].split('/')[0] + '/';
st = sp + st;
}
} catch(ierr) {}
var selmt = document.createElement('div');
var saelmt = document.createElement('a');
var sielmt = document.createElement('img');
var spelmt = document.createElement('p');
var sdelmt = document.createElement('div');
selmt.setAttribute('class', 'shortcut shortcut-bottom');
selmt.setAttribute('id', 'shortcut-5');
selmt.setAttribute('draggable', 'false');
saelmt.setAttribute('class', 'shortcut-link');
saelmt.setAttribute('draggable', 'false');
sielmt.setAttribute('class', 'shortcut-icon');
sielmt.setAttribute('draggable', 'false');
sdelmt.setAttribute('class', 'shortcut-icon-container');
sdelmt.setAttribute('draggable', 'false');
spelmt.setAttribute('class', 'shortcut-text');
spelmt.setAttribute('draggable', 'false');
spelmt.innerText = shortcut_5_name || shortcut_5;
saelmt.setAttribute('href', shortcut_5);
sielmt.setAttribute('src', (useIcon ? st : chrome.runtime.getURL('/images/shortcut-icon.png')));
selmt.appendChild(saelmt);
saelmt.appendChild(sdelmt);
sdelmt.appendChild(sielmt);
saelmt.appendChild(spelmt);
document.querySelector('#shortcuts').appendChild(selmt);
if(shortcut_6 || "null" != "null") {
var useIcon = false;
var sf, sfb, sa, st;
try {
sf = await fetch(shortcut_6);
sfb = sf.body;
sa = await sfb.getReader().read();
st = td.decode(sa.value);
useIcon = st.indexOf('icon') != -1;
st = st.substring(st.indexOf('icon'), st.length - 1);
useIcon = useIcon && st.indexOf('href=') != -1;
st = st.substring(st.indexOf('href=') + 6, st.length - 1);
st = st.substring(0, st.indexOf('"'));
if(st.indexOf('//') == -1 || (st.indexOf('//') != 5 && st.indexOf('//') != 6 && st.indexOf('//') != 0)) {
var spt = shortcut_6.split("://");
var sp = spt[0] + '://' + spt[1].split('/')[0] + '/';
st = sp + st;
}
} catch(ierr) {}
var selmt = document.createElement('div');
var saelmt = document.createElement('a');
var sielmt = document.createElement('img');
var spelmt = document.createElement('p');
var sdelmt = document.createElement('div');
selmt.setAttribute('class', 'shortcut shortcut-bottom');
selmt.setAttribute('id', 'shortcut-6');
selmt.setAttribute('draggable', 'false');
saelmt.setAttribute('class', 'shortcut-link');
saelmt.setAttribute('draggable', 'false');
sielmt.setAttribute('class', 'shortcut-icon');
sielmt.setAttribute('draggable', 'false');
sdelmt.setAttribute('class', 'shortcut-icon-container');
sdelmt.setAttribute('draggable', 'false');
spelmt.setAttribute('class', 'shortcut-text');
spelmt.setAttribute('draggable', 'false');
spelmt.innerText = shortcut_6_name || shortcut_6;
saelmt.setAttribute('href', shortcut_6);
sielmt.setAttribute('src', (useIcon ? st : chrome.runtime.getURL('/images/shortcut-icon.png')));
selmt.appendChild(saelmt);
saelmt.appendChild(sdelmt);
sdelmt.appendChild(sielmt);
saelmt.appendChild(spelmt);
document.querySelector('#shortcuts').appendChild(selmt);
}
}
}
}
}
}
$('#loadingStatus').text('Disabling Dragging');
document.querySelectorAll('.shortcut-icon').forEach(async function(elmt) {
elmt.setAttribute('src', elmt.getAttribute('src').replaceAll('../', chrome.runtime.getURL('/')));
});
document.querySelectorAll('.shortcut-icon-container').forEach(async function(elmt) {
elmt.setAttribute('style', 'background-color: ' + new_tab_accent_background_value.replaceAll('%23', '#') + "cc;");
});
document.querySelectorAll('a, p, img').forEach(async function(elmt) {
elmt.setAttribute('draggable', 'false');
});
$('#loadingStatus').text('Initalizing Doodles');
var currentDate = new Date();
var currentDay = currentDate.getDate();
var currentYear = currentDate.getFullYear();
var currentMonth = currentDate.getMonth() + 1;
doodles.forEach(async function(doodle) {
var isMonth = (currentMonth >= doodle.startTime.month && currentMonth <= doodle.endTime.month);
var isDay = (currentDay >= doodle.startTime.day && currentDay <= doodle.endTime.day);
var isOn = (isDay && isMonth);
if(isOn) {
if(doodle.useImage) {
document.querySelector('#googleLogo').setAttribute('src', doodle.imagePath);
document.querySelector('#googleLogo').onclick = doodle.onclick;
document.querySelector('#googleLogo').setAttribute('style', 'margin-left: 25%;' + doodle.customStyle);
} else {
var elmt = document.createElement('div');
elmt.setAttribute('id', 'googleLogo');
elmt.setAttribute('style', 'margin-left: 25%;' + doodle.customStyle);
var replaceContainer = document.querySelector('#' + doodle.replacementId);
var replaceText = replaceContainer.innerHTML.substring(5, replaceContainer.innerHTML.length - 4);
elmt.innerHTML = replaceText;
document.querySelector('#googleLogo').replaceWith(elmt);
replaceContainer.click();
doodle.onclick();
}
}
});
$('#loadingStatus').text('Initalizing Custom Borders');
var accent_border_obj = await chrome.storage.sync.get('accent_border');
var accent_border_value = (accent_border_obj.accent_border.replaceAll('%23', '#')) || "#ffffff";
document.querySelectorAll('.card').forEach(async function(card) {
card.setAttribute('style', 'background-color: ' + accent_border_value + ';');
});
var styleRuleAccent = { "selectorText": "body", "style": "--accent-border: " + (accent_border_value + "50") + ";accent-border-inverted: " + ((await invertColor(accent_border_value, false)) + 50) + ";" };
document.styleSheets[0].addRule(styleRuleAccent.selectorText, styleRuleAccent.style);
$('#loadingStatus').text('Fetching Search Sugestions');
async function updateSearchList(query) {
try {
var ssr;
if(query == null) {
ssr = await fetch('https://www.google.com/complete/search?q&cp=0&client=gws-wiz&xssi=t&gs_pcrt=2&hl=en&authuser=0&psi=GuGRZYuOH5eHptQPy5ms2Ao.1704059180034&dpr=1');
} else {
ssr = await fetch('https://www.google.com/complete/search?q=' + query + '&cp=0&client=gws-wiz&xssi=t&gs_pcrt=2&hl=en&authuser=0&psi=GuGRZYuOH5eHptQPy5ms2Ao.1704059180034&dpr=1');
}
var ssrs = ssr.body.getReader();
var ssat = await ssrs.read();
var ssa = ssat.value;
var sst = td.decode(ssa);
sst = sst.substring(5, sst.length);
var dsst = JSON.parse(sst);
if(query == "") {
query = null;
}
document.querySelector('#suggestions').innerHTML = "<hr style=\"display: block;position: relative;left: -35px;color: grey;top: -15px;width: 177%;\" />";
dsst[0].forEach(async function(dss) {
var hasTrendingSearches = ((dss[3] || { 'du': 'null' }).du || "null") == "null";
if(query != null) {
hasTrendingSearches = true;
}
document.querySelector('#suggestions').innerHTML = document.querySelector('#suggestions').innerHTML + "<div class=\"suggestion\"><div style=\"width: 20px;\" class=\"suggestion-icon" + (query != null ? " typed" : "") + (query == null && hasTrendingSearches ? " trending" : "") + "\"></div><a style=\"width: 85%\" href=\"https://www.google.com/search?q=" + dss[0] + "\" target=\"_self\" draggable=\"false\" class=\"suggestion-link\"><p style=\"width: 95%;text-wrap: nowrap;display: block;overflow: hidden;\">" + dss[0] + "</p></a>" + (hasTrendingSearches == false ? "<a target=\"_self\" draggable=\"false\" class=\"suggestion-delete\" href=\"https://www.google.com" + dss[3].du + "\">X</a>" : "") + "</div>\n";
});
} catch(sserr) {
console.error(sserr);
}
}
updateSearchList(null);
document.querySelector('.gLFyf').onfocus = async function() {
document.querySelector('.Aye1k').setAttribute('style', 'display: none;');
document.querySelector('#suggestions').setAttribute('style', 'display: block;padding-bottom: 45px;');
document.querySelector('#shortcuts').setAttribute('style', 'display: none;');
document.querySelector('#cards').setAttribute('style', 'display: none;');
document.querySelector('.dRYYxd').setAttribute('style', 'display: none;');
var oldclick = document.body.onclick;
document.body.onclick = async function(evt) {
if(evt.target.getAttribute('class') == 'suggestion-delete') {
evt.preventDefault();
evt.returnValue = '';
fetch(evt.target.getAttribute('href'));
evt.target.parentElement.remove();
updateSearchList(null);
document.body.click();
updateSearchList(null);
}
if(evt.target.getAttribute('class') != 'suggestion' && evt.target.parentElement.getAttribute('class') != 'suggestion' && evt.target.getAttribute('class') != 'gLFyf') {
document.querySelector('#suggestions').setAttribute('style', 'display: none;');
document.querySelector('#shortcuts').setAttribute('style', 'display: block;');
document.querySelector('#cards').setAttribute('style', 'display: block;');
document.querySelector('.dRYYxd').setAttribute('style', '');
document.body.onclick = oldclick;
}
if(evt.target.getAttribute('class') != 'Aye1k' && evt.target.parentElement.getAttribute('class') != 'Aye1k' && evt.target.getAttribute('class') != 'gLFyf') {
endImageSearch(oldclick);
}
};
};
var devices = await chrome.sessions.getDevices();
devices.forEach(async function(device) {
var delmt = document.createElement('li');
delmt.innerText = device.deviceName;
document.querySelector('#devicesList').appendChild(delmt);
});
document.querySelector('#allowDriveAccess').onclick = async function(evt) {
if(evt.target.parentElement.getAttribute('id') != 'allowDriveAccess') {
evt.target.remove();
} else {
evt.target.parentElement.remove();
}
$('.googleloadcirclecontainer').fadeIn(250);
setTimeout(function() {
$('.googleloadcirclecontainer').fadeOut(250);
setTimeout(function() {
$('.cjcodingloadcontainer').fadeIn(250);
setTimeout(function() {
$('.cjcodingloadcontainer').fadeOut(250);
setTimeout(function() {
var accessToken = chrome.runtime.sendMessage({ 'greeting': 'obtainAccessToken', 'data': 'https://www.googleapis.com/auth/drive.readonly%20https://www.googleapis.com/auth/drive.activity.readonly' });
chrome.runtime.onMessage.addListener(async function(message, sender, sendResponse) {
if(message.greeting == 'sendAccessToken' && message.data != null) {
chrome.storage.local.set({ 'newtabDriveAccessTokenReadOnly': message.data });
history.go(0);
} else if(message.greeting == 'sendAccessToken' && message.data == null) {
alert("Window Was Closed!");
history.go(0);
}
});
}, 500);
}, 20000);
}, 500);
}, 10000);
};
if((await chrome.storage.local.get('newtabDriveAccessTokenReadOnly')).newtabDriveAccessTokenReadOnly || "null" != "null") {
try {
var accessToken = (await chrome.storage.local.get('newtabDriveAccessTokenReadOnly')).newtabDriveAccessTokenReadOnly;
var data = await fetch('https://www.cjcoding.com/oauth2-google/get_drive_recent_files.php?token=' + accessToken);
var datab = data.body;
var databr = datab.getReader();
var databrr = await databr.read();
var datatd = new TextDecoder();
var datat = datatd.decode(databrr.value);
if(datat != "NEW TOKEN") {
document.querySelector('#allowDriveAccess').remove();
var elmt = document.createElement('div');
elmt.innerHTML = datat;
document.querySelector('#driveCard').appendChild(elmt);
}
} catch(ferr) {
console.error(ferr);
}
}
document.querySelector('#revokeDriveAccess').onclick = async function() {
$('.googleloadbar').fadeIn(250);
$('.googleloadbarmodalbackground').fadeIn(250);
setTimeout(async function() {
document.querySelector('.googleloadbarmodalbackground').setAttribute('style', 'display: none;');
document.querySelector('.googleloadbar').setAttribute('style', 'display: none;');
var win = await chrome.windows.create({ 'state': 'maximized', 'type': 'popup' });
var tab = await chrome.tabs.create({ 'url': 'https://myaccount.google.com/connections?continue=https%3A%2F%2Fwww.google.com%2F&revokeWindow', 'windowId': win.id });
chrome.storage.local.remove('newtabDriveAccessTokenReadOnly');
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
if(tabId == tab.id && (changeInfo.url || "").indexOf('https://www.google.com') != -1) {
chrome.windows.remove(win.id);
history.go(0);
}
});
}, 5000);
};
document.querySelector('#settings-button').onclick = async function(evt) {
var settingsTabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/settings.html')
]
});
if(settingsTabs[0] != null) {
var tab = settingsTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
} else {
chrome.tabs.create({'url': chrome.runtime.getURL('/html/settings.html')}, function(tab) {});
settingsTabs = await chrome.tabs.query({
url: [
chrome.runtime.getURL('/html/settings.html')
]
});
var tab = settingsTabs[0];
await chrome.tabs.update(tab.id, { active: true });
await chrome.windows.update(tab.windowId, { focused: true });
}
};
var show_cards_obj = await chrome.storage.sync.get('show_cards');
var show_cards_value = show_cards_obj.show_cards;
if(show_cards_value != 'on') {
$('#cards').fadeOut(0);
}
$('#loadingStatus').html('Initalizing Installed Apps');
if(canLogin == true) {
var scriptFinished = false;
var scriptUrl = null;
while(scriptFinished != true) {
try {
var appsData = { 'request': (await fetch('https://ogs.google.com/u/0/widget/app?awwd=1&gm3=1&origin=chrome-untrusted%3A%2F%2Fnew-tab-page&origin=chrome%3A%2F%2Fnew-tab-page&cn=app&pid=1&spid=243&hl=en')), 'td': (new TextDecoder()), 'body': null, 'reader': null, 'readerResp': null, 'readerValue': null, 'text': null };
appsData.body = appsData.request.body;
appsData.reader = appsData.body.getReader();
appsData.readerResp = await appsData.reader.read();
appsData.readerValue = appsData.readerResp.value;
appsData.text = await appsData.td.decode(appsData.readerValue);
var scripts = appsData.text.split('<script');
var script = scripts[15];
script = script.substring(script.indexOf('>'), script.indexOf('</script>'));
var scriptIndex = script.indexOf('https://www.googleapis.com/appsmarket/v2/installedApps/') + 'https://www.googleapis.com/appsmarket/v2/installedApps/'.length;
var scriptSector1 = script.substring(scriptIndex, script.length);
var scriptSector2 = scriptSector1.substring(0, scriptSector1.indexOf("\""));
scriptUrl = 'https://www.googleapis.com/appsmarket/v2/installedApps/' + scriptSector2;
console.log(scriptUrl);
scriptFinished = true;
} catch(err) {
console.error(err);
}
}
scriptFinished = false;
var appsJson = null;
while(scriptFinished != true) {
try {
var appsData = { 'request': (await fetch(scriptUrl)), 'td': (new TextDecoder()), 'body': null, 'reader': null, 'readerResp': null, 'readerValue': null, 'text': null };
appsData.body = appsData.request.body;
appsData.reader = appsData.body.getReader();
appsData.readerResp = await appsData.reader.read();
appsData.readerValue = appsData.readerResp.value;
appsData.text = await appsData.td.decode(appsData.readerValue);
appsJson = JSON.parse(appsData.text);
console.log(appsJson);
scriptFinished = true;
} catch(err) {
console.error(err);
}
}
var elmtItemTemplate = "<li class=\"j1ei8c\" jscontroller=\"lKZxSd\" jsaction=\"rcuQ6b:npT2md; keydown:I481le;qUuEUd:rfjeo;j9grLe:Z8TOLc;HUObcd:Hp74Ud;\" style=\"\"><a class=\"tX9u1b\" href=\"(url)\" target=\"_top\" data-pid=\"260\" jslog=\"46976; 1:260; track:click; index:1\" jsname=\"hSRGPd\" aria-grabbed=\"false\" draggable=\"false\"><div class=\"pPUwub\" aria-hidden=\"true\"></div><div class=\"dKVyP\" aria-hidden=\"true\"></div><div class=\"ajYF5e\" aria-hidden=\"true\"></div><div class=\"NcWGte\" aria-hidden=\"true\"></div><div class=\"CgwTDb\"><span class=\"MrEfLc\" style=\"background-size: 48px;background-repeat: no-repeat;background-image: url('(image)');\"></span></div><span jsname=\"V67aGc\" data-text=\"(name)\" class=\"Rq5Gcb\">(name)</span></a></li>";
var elmtItems = "";
var elmt = document.createElement('div');
elmt.setAttribute('class', 'LVal7b ');
appsJson.installedApps.forEach(function(app) {
var tempStr = elmtItemTemplate;
tempStr = tempStr.replaceAll('(image)', app.iconUrl48x48);
tempStr = tempStr.replaceAll('(url)', app.url);
tempStr = tempStr.replaceAll('(name)', app.name);
elmtItems = elmtItems + tempStr;
});
elmt.innerHTML = "<p style=\"text-align: center;font-size: 10pt;font-family: Roboto, sans-serif;\">" + (appsJson.domainName == "gmail.com" ? "Your" : appsJson.domainName) + " Apps</p>\n<ul jsname=\"k77Iif\" class=\"ngVsM u4RcUd\">" + elmtItems + "</ul>\n<div class=\"WwFbJd\"><a href=\"https://about.google/products/\" class=\"NQV3m\" jsname=\"TiWzT\" data-app-widget-link-name=\"jcJzye\" draggable=\"false\" target=\"_blank\" jslog=\"51957; track:click;\">More from Google</a></div>";
document.querySelector('.o83JEf').appendChild(elmt);
elmt = document.createElement('div');
elmt.setAttribute('class', 'WwFbJd');
elmt.innerHTML = "<a href=\"https://workspace.google.com/u/0/marketplace/appfinder?origin=https%3A%2F%2Fdocs.google.com&extension_type=&pann=docs_addon_widget&xpc=%7B%22cn%22%3A%22DDpNHPAtAM%22%2C%22tp%22%3A1%2C%22osh%22%3Atrue%2C%22ppu%22%3A%22https%3A%2F%2Fdocs.google.com%2Frobots.txt%22%2C%22lpu%22%3A%22https%3A%2F%2Fworkspace.google.com%2Frobots.txt%22%7D&hl=charlie\" style=\"margin-top: 22px;margin-bottom: 16px;\" class=\"NQV3m workspace\" jsname=\"TiWzT\" data-app-widget-link-name=\"Liojr\" target=\"_blank\" jslog=\"52853; track:click;\">More from Google Workspace Marketplace</a>";
document.querySelector('.o83JEf').appendChild(elmt);
document.querySelector('.NQV3m.workspace').onclick = async function(evt) {
evt.preventDefault();
evt.returnValue = '';
var pageUrl = evt.target.getAttribute('href');
document.body.click();
var win = await chrome.windows.create({ 'state': 'maximized', 'type': 'popup' });
var tab = await chrome.tabs.create({ 'url': pageUrl, 'windowId': win.id });
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
if(tabId == tab.id && (changeInfo.url || "").indexOf('https://www.google.com') != -1) {
chrome.windows.remove(win.id);
history.go(0);
}
});
};
} else {
var elmt = document.createElement('div');
elmt.innerHTML = "<div class=\"WwFbJd\"><a href=\"https://about.google/products/\" class=\"NQV3m\" jsname=\"TiWzT\" data-app-widget-link-name=\"jcJzye\" draggable=\"false\" target=\"_blank\" jslog=\"51957; track:click;\">More from Google</a></div>";
elmt.setAttribute('class', 'LVal7b ');
document.querySelector('.o83JEf').appendChild(elmt);
}
if(noShortcuts == true) {
var show_cards_obj = await chrome.storage.sync.get('show_cards');
var show_cards_value = show_cards_obj.show_cards;
var showCardsDisplayValue = 'none';
if(show_cards_value == 'on') {
showCardsDisplayValue = 'block';
}
var prevStyle = 'display: ' + showCardsDisplayValue + ';';
document.querySelector('#cards').setAttribute('style', prevStyle + 'top: 96.5%;');
}
document.querySelector('.XDyW0e').onclick = async function(evt) {
var tab = await chrome.tabs.getCurrent();
var tabId = tab.id;
window.location.href = 'https://www.google.com/webhp?pli=1&voiceSearch&tabId=' + tabId;
};
document.querySelector('.nDcEnd').onclick = async function(evt) {
document.querySelector('.Aye1k').setAttribute('style', 'display: block;margin-left: 13.5%;width: 74%;');
document.querySelector('#suggestions').setAttribute('style', 'display: none;');
setTimeout(async function() {
var oldclick = document.body.onclick;
document.body.onclick = async function(evt) {
if(evt.target.getAttribute('class') != 'Aye1k' && evt.target.parentElement.getAttribute('class') != 'Aye1k' && evt.target.getAttribute('class') != 'DV7the' && evt.target.parentElement.getAttribute('class') != 'DV7the' && evt.target.getAttribute('class') != 'RaoUUe' && evt.target.parentElement.getAttribute('class') != 'RaoUUe' && evt.target.getAttribute('class') != 'p4pvTd' && evt.target.parentElement.getAttribute('class') != 'p4pvTd' && evt.target.getAttribute('class') != 'KoWHpd' && evt.target.parentElement.getAttribute('class') != 'KoWHpd' && evt.target.getAttribute('class') != 'ea0Lbe' && evt.target.parentElement.getAttribute('class') != 'ea0Lbe' && evt.target.getAttribute('class') != 'BH9rn' && evt.target.parentElement.getAttribute('class') != 'BH9rn' && evt.target.getAttribute('class') != 'f6GA0' && evt.target.parentElement.getAttribute('class') != 'f6GA0') {
endImageSearch(oldclick);
}
};
}, 250);
};
async function endImageSearch(oldclick) {
document.body.onclick = oldclick;
document.querySelector('.Aye1k').setAttribute('style', 'display: none;');
document.body.click();
document.body.click();
document.body.click();
}
var imageFileUpload = document.createElement('input');
imageFileUpload.setAttribute('type', 'file');
imageFileUpload.onchange = async function(evt) {
var w = 0;
var h = 0;
var files = evt.target.files;
var file = files[0];
console.log(file);
var fr = new FileReader();
fr.onload = async function(evt) {
var image = new Image();
image.src = fr.result;
image.onload = async function() {
w = this.width;
h = this.height;
fr.onload = async function(evt) {
var result = fr.result;
console.log(result);
var form = document.createElement('form');
form.setAttribute('action', 'https://lens.google.com/v3/upload?hl=en&re=df&st=1711550954491&vpw=' + w + '&vph=' + h + '&ep=gsbubb');
form.setAttribute('method', 'POST');
imageFileUpload.setAttribute('name', 'encoded_image');
var elmt = document.createElement('input');
elmt.setAttribute('type', 'hidden');
elmt.setAttribute('name', 'processed_image_dimensions');
elmt.setAttribute('value', w + ',' + h);
form.appendChild(elmt);
elmt = document.createElement('input');
elmt.setAttribute('type', 'hidden');
elmt.setAttribute('name', 'encoded_image');
elmt.value = fr.result;
form.appendChild(imageFileUpload);
elmt = document.createElement('button');
elmt.setAttribute('type', 'submit');
form.appendChild(elmt);
form.setAttribute('style', 'display: none;');
document.body.appendChild(form);
form.setAttribute('enctype', 'multipart/form-data');
elmt.click();
};
fr.readAsArrayBuffer(file);
};
};
fr.readAsDataURL(file);
};
document.querySelector('.DV7the').onclick = async function(evt) {
imageFileUpload.click();
}
$('#loadingStatus').html('Done!<br />Please Wait');
setTimeout(async function() {
$('#loadingText').fadeOut(500);
setTimeout(async function() {
$('#background').fadeIn(500);
$('#container').fadeIn(500);
document.querySelector('#googleloadbar').setAttribute('style', 'display: none;');
}, 500);
}, 500);
};
