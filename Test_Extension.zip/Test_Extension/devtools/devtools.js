console.log("DevTools.js Started");
const getCurrentElement = "function() { function css(element, property) {return window.getComputedStyle(element, null).getPropertyValue(property);}var elmt = $0;var fontFamily = css(elmt, 'font-family');var fontSize = css(elmt, 'font-size');var fontWeight = css(elmt, 'font-weight');var fontStyle = css(elmt, 'font-style');return \"<style type=\\\"text/css\\\">\\\nbody {\\\nfont-family: sans-serif;\\\n}\\\n</style>\\\n<h2>Font Properties</h2>\\\n<br />\\\n<p>Font Family: <span id=\\\"fontFamilyDisplay\\\">\" + fontFamily + \"</span>.</p>\\\n<p>Font Size: <span id=\\\"fontSizeDisplay\\\">\" + fontSize + \"</span>.</p>\\\n<p>Font Weight: <span id=\\\"fontWeightDisplay\\\">\" + fontWeight + \"</span>.</p>\\\n<p>Font Style: <span id=\\\"fontStyleDisplay\\\">\" + fontStyle + \"</span>.</p>\"; }";
chrome.devtools.panels.create("Font Picker", "/devtools/FontPickerDevToolsIcon.png", "/devtools/FontPickerPanel.html",  function(panel) {});
chrome.devtools.panels.elements.createSidebarPane("Font Properties", function(sidebar) {
sidebar.setPage("/devtools/FontPickerSidebar.html");
sidebar.setHeight("8ex");
sidebar.onShown.addListener(async function(sidebarwin) {
async function updateElementProperties() {
sidebar.setExpression('(' + getCurrentElement + ')();');
}
updateElementProperties();
chrome.devtools.panels.elements.onSelectionChanged.addListener(updateElementProperties);
});
});
